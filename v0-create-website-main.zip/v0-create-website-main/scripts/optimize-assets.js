// This script demonstrates how to combine and minify CSS and JS files
// You would need to install these packages:
// npm install --save-dev terser clean-css glob fs-extra

const fs = require("fs-extra")
const glob = require("glob")
const { minify } = require("terser")
const CleanCSS = require("clean-css")

// Combine and minify JavaScript files
async function optimizeJS() {
  console.log("Optimizing JavaScript files...")

  // Get all JS files
  const jsFiles = glob.sync("./public/js/**/*.js")
  let combinedJS = ""

  // Read and combine all JS files
  for (const file of jsFiles) {
    const content = fs.readFileSync(file, "utf8")
    combinedJS += content + "\n"
  }

  // Minify the combined JS
  const minified = await minify(combinedJS)

  // Write the minified JS to a new file
  fs.outputFileSync("./public/js/bundle.min.js", minified.code)

  console.log("JavaScript optimization complete!")
}

// Combine and minify CSS files
function optimizeCSS() {
  console.log("Optimizing CSS files...")

  // Get all CSS files
  const cssFiles = glob.sync("./public/css/**/*.css")
  let combinedCSS = ""

  // Read and combine all CSS files
  for (const file of cssFiles) {
    const content = fs.readFileSync(file, "utf8")
    combinedCSS += content + "\n"
  }

  // Minify the combined CSS
  const minified = new CleanCSS().minify(combinedCSS)

  // Write the minified CSS to a new file
  fs.outputFileSync("./public/css/bundle.min.css", minified.styles)

  console.log("CSS optimization complete!")
}

// Optimize images
function optimizeImages() {
  console.log("To optimize images, consider using:")
  console.log("1. next-image-optimization (built into Next.js)")
  console.log("2. Sharp for Node.js image processing")
  console.log("3. WebP format for better compression")
  console.log('4. Lazy loading with loading="lazy" attribute')
  console.log("5. Proper image sizing with srcset for responsive images")
}

// Run optimizations
async function runOptimizations() {
  try {
    await optimizeJS()
    optimizeCSS()
    optimizeImages()
    console.log("All optimizations complete!")
  } catch (error) {
    console.error("Optimization failed:", error)
  }
}

runOptimizations()
