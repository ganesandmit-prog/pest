"use client"

import Link from "next/link"

import { Star } from "lucide-react"
import { motion } from "framer-motion"
import { AnimatedSection, StaggeredContainer } from "./framer-animations"

interface TestimonialProps {
  quote: string
  author: string
  location: string
  rating: number
}

const Testimonial = ({ quote, author, location, rating }: TestimonialProps) => (
  <motion.div
    className="bg-dark-brown text-white p-6 rounded-lg shadow-lg h-full flex flex-col"
    whileHover={{ y: -10 }}
  >
    <div className="flex mb-4">
      {Array.from({ length: rating }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.1 * i }}
        >
          <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
        </motion.div>
      ))}
    </div>
    <h3 className="text-xl font-bold mb-4">"{quote}"</h3>
    <div className="mt-auto">
      <p className="font-semibold">{author}</p>
      <p className="text-sm text-gray-300">{location}</p>
    </div>
  </motion.div>
)

export const TestimonialsSection = () => {
  const testimonials = [
    {
      quote:
        "No.1 Quality Pest Control Chennai completely eliminated our cockroaches problem. Their pest control service was eco-friendly and perfect for our home with small children.",
      author: "Priya Sharma",
      location: "Anna Nagar, Chennai",
      rating: 5,
    },
    {
      quote:
        "Professional, punctual, and effective termite control! They got rid of termites that were damaging our wooden furniture. Best pest control services Chennai!",
      author: "Rajesh Kumar",
      location: "T. Nagar, Chennai",
      rating: 5,
    },
    {
      quote:
        "We've been using their monthly commercial pest control service for our restaurant for over a year. Excellent control services at competitive price.",
      author: "Vijay Menon",
      location: "Nungambakkam, Chennai",
      rating: 5,
    },
    {
      quote:
        "The pest control experts were knowledgeable and took time to explain the treatment process. Our bed bug problem was solved in just one visit! Affordable price for quality service.",
      author: "Lakshmi Narayan",
      location: "Adyar, Chennai",
      rating: 5,
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">What Our Chennai Pest Control Customers Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it. Here's what our satisfied customers have to say about our pest control
              services Chennai.
            </p>
          </div>
        </AnimatedSection>

        <StaggeredContainer staggerDelay={0.1} animation="slideUp">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((testimonial, index) => (
              <Testimonial key={index} {...testimonial} />
            ))}
          </div>
        </StaggeredContainer>

        <AnimatedSection animation="fadeIn" delay={0.5}>
          <div className="mt-12 text-center">
            <Link href="/reviews">
              <motion.button className="btn-outline" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                Read More Chennai Pest Control Reviews
              </motion.button>
            </Link>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

export default TestimonialsSection
