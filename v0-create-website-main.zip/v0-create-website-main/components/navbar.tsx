"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, ChevronDown } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet"
import { motion } from "framer-motion"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Update the areasWeServe array to include all areas in Chennai

const areasWeServe = [
  { name: "Adambakkam", href: "/service-areas/adambakkam" },
  { name: "Adyar", href: "/service-areas/adyar" },
  { name: "Alandur", href: "/service-areas/alandur" },
  { name: "Alapakkam", href: "/service-areas/alapakkam" },
  { name: "Alwarpet", href: "/service-areas/alwarpet" },
  { name: "Alwarthirunagar", href: "/service-areas/alwarthirunagar" },
  { name: "Ambattur", href: "/service-areas/ambattur" },
  { name: "Aminjikarai", href: "/service-areas/aminjikarai" },
  { name: "Anna Nagar", href: "/service-areas/anna-nagar" },
  { name: "Annanur", href: "/service-areas/annanur" },
  { name: "Arumbakkam", href: "/service-areas/arumbakkam" },
  { name: "Ashok Nagar", href: "/service-areas/ashok-nagar" },
  { name: "Avadi", href: "/service-areas/avadi" },
  { name: "Ayanavaram", href: "/service-areas/ayanavaram" },
  { name: "Basin Bridge", href: "/service-areas/basin-bridge" },
  { name: "Beemannapettai", href: "/service-areas/beemannapettai" },
  { name: "Besant Nagar", href: "/service-areas/besant-nagar" },
  { name: "Chepauk", href: "/service-areas/chepauk" },
  { name: "Chetput", href: "/service-areas/chetput" },
  { name: "Chintadripet", href: "/service-areas/chintadripet" },
  { name: "Chitlapakkam", href: "/service-areas/chitlapakkam" },
  { name: "Choolai", href: "/service-areas/choolai" },
  { name: "Choolaimedu", href: "/service-areas/choolaimedu" },
  { name: "Chrompet", href: "/service-areas/chrompet" },
  { name: "Egmore", href: "/service-areas/egmore" },
  { name: "Ekkaduthangal", href: "/service-areas/ekkaduthangal" },
  { name: "Ennore", href: "/service-areas/ennore" },
  { name: "Foreshore Estate", href: "/service-areas/foreshore-estate" },
  { name: "Fort St. George", href: "/service-areas/fort-st-george" },
  { name: "George Town", href: "/service-areas/george-town" },
  { name: "Gopalapuram", href: "/service-areas/gopalapuram" },
  { name: "Government Estate", href: "/service-areas/government-estate" },
  { name: "Guindy", href: "/service-areas/guindy" },
  { name: "Guduvancheri", href: "/service-areas/guduvancheri" },
  { name: "Injambakkam", href: "/service-areas/injambakkam" },
  { name: "Iyyapanthangal", href: "/service-areas/iyyapanthangal" },
  { name: "Jafferkhanpet", href: "/service-areas/jafferkhanpet" },
  { name: "Kadambathur", href: "/service-areas/kadambathur" },
  { name: "Karapakkam", href: "/service-areas/karapakkam" },
  { name: "Kattivakkam", href: "/service-areas/kattivakkam" },
  { name: "Kattupakkam", href: "/service-areas/kattupakkam" },
  { name: "Kazhipattur", href: "/service-areas/kazhipattur" },
  { name: "K.K. Nagar", href: "/service-areas/kk-nagar" },
  { name: "Keelkattalai", href: "/service-areas/keelkattalai" },
  { name: "Kilpauk", href: "/service-areas/kilpauk" },
  { name: "Kodambakkam", href: "/service-areas/kodambakkam" },
  { name: "Kodungaiyur", href: "/service-areas/kodungaiyur" },
  { name: "Kolathur", href: "/service-areas/kolathur" },
  { name: "Korattur", href: "/service-areas/korattur" },
  { name: "Korukkupet", href: "/service-areas/korukkupet" },
  { name: "Kottivakkam", href: "/service-areas/kottivakkam" },
  { name: "Kotturpuram", href: "/service-areas/kotturpuram" },
  { name: "Kottur", href: "/service-areas/kottur" },
  { name: "Kovur", href: "/service-areas/kovur" },
  { name: "Koyambedu", href: "/service-areas/koyambedu" },
  { name: "Kundrathur", href: "/service-areas/kundrathur" },
  { name: "Madhavaram", href: "/service-areas/madhavaram" },
  { name: "Madhavaram Milk Colony", href: "/service-areas/madhavaram-milk-colony" },
  { name: "Madipakkam", href: "/service-areas/madipakkam" },
  { name: "Madambakkam", href: "/service-areas/madambakkam" },
  { name: "Maduravoyal", href: "/service-areas/maduravoyal" },
  { name: "Manali", href: "/service-areas/manali" },
  { name: "Manali New Town", href: "/service-areas/manali-new-town" },
  { name: "Manapakkam", href: "/service-areas/manapakkam" },
  { name: "Mandaveli", href: "/service-areas/mandaveli" },
  { name: "Mangadu", href: "/service-areas/mangadu" },
  { name: "Mannadi", href: "/service-areas/mannadi" },
  { name: "Mathur", href: "/service-areas/mathur" },
  { name: "Medavakkam", href: "/service-areas/medavakkam" },
  { name: "Meenambakkam", href: "/service-areas/meenambakkam" },
  { name: "MGR Nagar", href: "/service-areas/mgr-nagar" },
  { name: "Minjur", href: "/service-areas/minjur" },
  { name: "Mogappair", href: "/service-areas/mogappair" },
  { name: "MKB Nagar", href: "/service-areas/mkb-nagar" },
  { name: "Mount Road", href: "/service-areas/mount-road" },
  { name: "Moolakadai", href: "/service-areas/moolakadai" },
  { name: "Moulivakkam", href: "/service-areas/moulivakkam" },
  { name: "Mugalivakkam", href: "/service-areas/mugalivakkam" },
  { name: "Mudichur", href: "/service-areas/mudichur" },
  { name: "Mylapore", href: "/service-areas/mylapore" },
  { name: "Nandanam", href: "/service-areas/nandanam" },
  { name: "Nanganallur", href: "/service-areas/nanganallur" },
  { name: "Nanmangalam", href: "/service-areas/nanmangalam" },
  { name: "Neelankarai", href: "/service-areas/neelankarai" },
  { name: "Nemilichery", href: "/service-areas/nemilichery" },
  { name: "Nesapakkam", href: "/service-areas/nesapakkam" },
  { name: "Nolambur", href: "/service-areas/nolambur" },
  { name: "Noombal", href: "/service-areas/noombal" },
  { name: "Nungambakkam", href: "/service-areas/nungambakkam" },
  { name: "Otteri", href: "/service-areas/otteri" },
  { name: "Padi", href: "/service-areas/padi" },
  { name: "Pakkam", href: "/service-areas/pakkam" },
  { name: "Palavakkam", href: "/service-areas/palavakkam" },
  { name: "Pallavaram", href: "/service-areas/pallavaram" },
  { name: "Pallikaranai", href: "/service-areas/pallikaranai" },
  { name: "Pammal", href: "/service-areas/pammal" },
  { name: "Park Town", href: "/service-areas/park-town" },
  { name: "Parry's Corner", href: "/service-areas/parrys-corner" },
  { name: "Pattabiram", href: "/service-areas/pattabiram" },
  { name: "Pattaravakkam", href: "/service-areas/pattaravakkam" },
  { name: "Pazhavanthangal", href: "/service-areas/pazhavanthangal" },
  { name: "Peerkankaranai", href: "/service-areas/peerkankaranai" },
  { name: "Perambur", href: "/service-areas/perambur" },
  { name: "Peravallur", href: "/service-areas/peravallur" },
  { name: "Perumbakkam", href: "/service-areas/perumbakkam" },
  { name: "Perungalathur", href: "/service-areas/perungalathur" },
  { name: "Perungudi", href: "/service-areas/perungudi" },
  { name: "Pozhichalur", href: "/service-areas/pozhichalur" },
  { name: "Poonamallee", href: "/service-areas/poonamallee" },
  { name: "Porur", href: "/service-areas/porur" },
  { name: "Pudupet", href: "/service-areas/pudupet" },
  { name: "Pulianthope", href: "/service-areas/pulianthope" },
  { name: "Purasaiwalkam", href: "/service-areas/purasaiwalkam" },
  { name: "Puthagaram", href: "/service-areas/puthagaram" },
  { name: "Puzhal", href: "/service-areas/puzhal" },
  { name: "Puzhuthivakkam - Ullagaram", href: "/service-areas/puzhuthivakkam-ullagaram" },
  { name: "Raj Bhavan", href: "/service-areas/raj-bhavan" },
  { name: "Ramavaram", href: "/service-areas/ramavaram" },
  { name: "Red Hills", href: "/service-areas/red-hills" },
  { name: "Royapettah", href: "/service-areas/royapettah" },
  { name: "Royapuram", href: "/service-areas/royapuram" },
  { name: "Saidapet", href: "/service-areas/saidapet" },
  { name: "Saligramam", href: "/service-areas/saligramam" },
  { name: "Santhome", href: "/service-areas/santhome" },
  { name: "Sembakkam", href: "/service-areas/sembakkam" },
  { name: "Selaiyur", href: "/service-areas/selaiyur" },
  { name: "Shenoy Nagar", href: "/service-areas/shenoy-nagar" },
  { name: "Sholavaram", href: "/service-areas/sholavaram" },
  { name: "Sholinganallur", href: "/service-areas/sholinganallur" },
  { name: "Sikkarayapuram", href: "/service-areas/sikkarayapuram" },
  { name: "Sowcarpet", href: "/service-areas/sowcarpet" },
  { name: "St.Thomas Mount", href: "/service-areas/st-thomas-mount" },
  { name: "Surapet", href: "/service-areas/surapet" },
  { name: "Tambaram", href: "/service-areas/tambaram" },
  { name: "Teynampet", href: "/service-areas/teynampet" },
  { name: "Tharamani", href: "/service-areas/tharamani" },
  { name: "T. Nagar", href: "/service-areas/t-nagar" },
  { name: "Thirumangalam", href: "/service-areas/thirumangalam" },
  { name: "Thirumullaivoyal", href: "/service-areas/thirumullaivoyal" },
  { name: "Thiruneermalai", href: "/service-areas/thiruneermalai" },
  { name: "Thiruninravur", href: "/service-areas/thiruninravur" },
  { name: "Thiruvanmiyur", href: "/service-areas/thiruvanmiyur" },
  { name: "Thiruvallur", href: "/service-areas/thiruvallur" },
  { name: "Tiruverkadu", href: "/service-areas/tiruverkadu" },
  { name: "Thiruvotriyur", href: "/service-areas/thiruvotriyur" },
  { name: "Thuraipakkam", href: "/service-areas/thuraipakkam" },
  { name: "Tirusulam", href: "/service-areas/tirusulam" },
  { name: "Tiruvallikeni", href: "/service-areas/tiruvallikeni" },
  { name: "Tondiarpet", href: "/service-areas/tondiarpet" },
  { name: "United India Colony", href: "/service-areas/united-india-colony" },
  { name: "Vandalur", href: "/service-areas/vandalur" },
  { name: "Vadapalani", href: "/service-areas/vadapalani" },
  { name: "Valasaravakkam", href: "/service-areas/valasaravakkam" },
  { name: "Vallalar Nagar", href: "/service-areas/vallalar-nagar" },
  { name: "Vanagaram", href: "/service-areas/vanagaram" },
  { name: "Velachery", href: "/service-areas/velachery" },
  { name: "Velappanchavadi", href: "/service-areas/velappanchavadi" },
  { name: "Villivakkam", href: "/service-areas/villivakkam" },
  { name: "Virugambakkam", href: "/service-areas/virugambakkam" },
  { name: "Vyasarpadi", href: "/service-areas/vyasarpadi" },
  { name: "Washermanpet", href: "/service-areas/washermanpet" },
  { name: "West Mambalam", href: "/service-areas/west-mambalam" },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      <motion.header
        className={`bg-white py-4 shadow-sm sticky top-0 z-40 ${scrolled ? "shadow-md" : ""}`}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="container mx-auto flex justify-between items-center px-4">
          <Link href="/" className="flex items-center">
            <motion.div className="flex items-center" whileHover={{ scale: 1.05 }}>
              <Image
                src="/images/logo.png"
                alt="No.1 Quality Pest Control"
                width={200}
                height={70}
                className="w-auto h-16 md:h-20"
              />
            </motion.div>
          </Link>

          <nav className="hidden lg:flex items-center space-x-6">
            <motion.div whileHover={{ y: -2 }}>
              <Link href="/" className="text-gray-800 hover:text-light-green font-medium">
                Home
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center text-gray-800 hover:text-light-green font-medium">
                  Pest Control <ChevronDown className="h-4 w-4 ml-1" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>
                    <Link href="/pest-control-in-chennai" className="w-full">
                      Pest Control in Chennai
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/pest-control-services-in-chennai" className="w-full">
                      Pest Control Services
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/pest-control-in-chennai-price-list" className="w-full">
                      Pest Control Price List
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/termite-control-in-chennai" className="w-full">
                      Termite Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/rodent-control-in-chennai" className="w-full">
                      Rodent Control
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <Link href="/about-us" className="text-gray-800 hover:text-light-green font-medium">
                About Us
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <Link href="/residential" className="text-gray-800 hover:text-light-green font-medium">
                Residential
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <Link href="/commercial" className="text-gray-800 hover:text-light-green font-medium">
                Commercial
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center text-gray-800 hover:text-light-green font-medium">
                  Our Services <ChevronDown className="h-4 w-4 ml-1" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>
                    <Link href="/services/mosquito-control" className="w-full">
                      Mosquito Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/cockroach-control" className="w-full">
                      Cockroach Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/bed-bug-control" className="w-full">
                      Bed Bug Treatment
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/termite-control" className="w-full">
                      Termite Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/rodent-control" className="w-full">
                      Rodent Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/snake-control" className="w-full">
                      Snake Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/spider-control" className="w-full">
                      Spider Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/fly-control" className="w-full">
                      Fly Control
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/services/termite-piping" className="w-full">
                      Termite Piping Control
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center text-gray-800 hover:text-light-green font-medium">
                  Areas We Serve <ChevronDown className="h-4 w-4 ml-1" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {areasWeServe.map((area) => (
                    <DropdownMenuItem key={area.name}>
                      <Link href={area.href} className="w-full">
                        Pest Control in {area.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </motion.div>
            <motion.div whileHover={{ y: -2 }}>
              <Link href="/contact-us" className="text-gray-800 hover:text-light-green font-medium">
                Contact Us
              </Link>
            </motion.div>
          </nav>

          <div className="flex items-center lg:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <motion.button
                  className="text-gray-800 hover:text-light-green"
                  aria-label="Menu"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Menu className="h-6 w-6" />
                </motion.button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold">Menu</h2>
                </div>
                <nav className="flex flex-col gap-4">
                  <SheetClose asChild>
                    <Link href="/" className="text-xl font-medium hover:text-light-green">
                      Home
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/pest-control-in-chennai" className="text-xl font-medium hover:text-light-green">
                      Pest Control in Chennai
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link
                      href="/pest-control-services-in-chennai"
                      className="text-xl font-medium hover:text-light-green"
                    >
                      Pest Control Services in Chennai
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link
                      href="/pest-control-in-chennai-price-list"
                      className="text-xl font-medium hover:text-light-green"
                    >
                      Pest Control Price List
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/termite-control-in-chennai" className="text-xl font-medium hover:text-light-green">
                      Termite Control in Chennai
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/rodent-control-in-chennai" className="text-xl font-medium hover:text-light-green">
                      Rodent Control in Chennai
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/about-us" className="text-xl font-medium hover:text-light-green">
                      About Us
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/residential" className="text-xl font-medium hover:text-light-green">
                      Residential
                    </Link>
                  </SheetClose>
                  <SheetClose asChild>
                    <Link href="/commercial" className="text-xl font-medium hover:text-light-green">
                      Commercial
                    </Link>
                  </SheetClose>
                  <div className="text-xl font-medium">
                    Our Services
                    <div className="ml-4 mt-2 flex flex-col gap-2">
                      <SheetClose asChild>
                        <Link href="/services/mosquito-control" className="text-lg hover:text-light-green">
                          Mosquito Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/cockroach-control" className="text-lg hover:text-light-green">
                          Cockroach Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/bed-bug-control" className="text-lg hover:text-light-green">
                          Bed Bug Treatment
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/termite-control" className="text-lg hover:text-light-green">
                          Termite Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/rodent-control" className="text-lg hover:text-light-green">
                          Rodent Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/snake-control" className="text-lg hover:text-light-green">
                          Snake Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/spider-control" className="text-lg hover:text-light-green">
                          Spider Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/fly-control" className="text-lg hover:text-light-green">
                          Fly Control
                        </Link>
                      </SheetClose>
                      <SheetClose asChild>
                        <Link href="/services/termite-piping" className="text-lg hover:text-light-green">
                          Termite Piping Control
                        </Link>
                      </SheetClose>
                    </div>
                  </div>
                  <div className="text-xl font-medium">
                    Areas We Serve
                    <div className="ml-4 mt-2 flex flex-col gap-2">
                      {areasWeServe.map((area) => (
                        <SheetClose asChild key={area.name}>
                          <Link href={area.href} className="text-lg hover:text-light-green">
                            Pest Control in {area.name}
                          </Link>
                        </SheetClose>
                      ))}
                    </div>
                  </div>
                  <SheetClose asChild>
                    <Link href="/contact-us" className="text-xl font-medium hover:text-light-green">
                      Contact Us
                    </Link>
                  </SheetClose>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </motion.header>
    </>
  )
}
