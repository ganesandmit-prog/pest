"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { AnimatedSection, StaggeredContainer } from "./framer-animations"

// Service type definition
interface ServiceType {
  name: string
  description: string
  image: string
  slug: string
}

export default function ServicesSection() {
  // Services
  const services: ServiceType[] = [
    {
      name: "Termite Control",
      description: "Protect your property from structural damage with our advanced termite control solutions.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-waanzPZrDnVZ2Xjkstuv5im8xH3oOi.png",
      slug: "termite-control",
    },
    {
      name: "Cockroach Control",
      description: "Eliminate disease-carrying cockroaches with our effective treatment methods.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-L5hASvrQm1wqMDdVr0v2zJqJoLHITk.png",
      slug: "cockroach-control",
    },
    {
      name: "Bed Bug Control",
      description: "Get rid of bed bugs completely with our specialized treatment protocols.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pg04NtTuPrvAmJ2pJF7TGw0BOgdcGC.png",
      slug: "bed-bug-control",
    },
    {
      name: "Mosquito Control",
      description: "Protect your family from mosquito-borne diseases with our effective control methods.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzopu2w4caDDze0eTucWBnPgk5eQde.png",
      slug: "mosquito-control",
    },
    {
      name: "Rodent Control",
      description: "Comprehensive solutions to eliminate rats, mice and prevent re-infestation.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg",
      slug: "rodent-control",
    },
    {
      name: "Ant Control",
      description: "Effective treatments to eliminate ant colonies and prevent their return.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-6lrD4kBfAovJAmZhpzAfdnGzcSUyvn.png",
      slug: "ant-control",
    },
    {
      name: "Spider Control",
      description: "Safe removal of spiders and web prevention treatments for your home.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VhEzIq24sp1W9R6w5zc3sSHRLynXuk.png",
      slug: "spider-control",
    },
    {
      name: "Fly Control",
      description: "Effective solutions to eliminate flies and prevent their breeding.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.44_705f83cb.jpg-6KTtzvkByZQZIMhRkvZ5JUH2dXEsGa.jpeg",
      slug: "fly-control",
    },
    {
      name: "Snake Control",
      description: "Professional removal and prevention of snakes from your property.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.07_95330c8b.jpg-B10Tm1BVj30SHkr83wW0gOaEAebAXw.jpeg",
      slug: "snake-control",
    },
    {
      name: "Wasp Control",
      description: "Safe removal of wasp nests and prevention treatments.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.16_5f166834.jpg-pUBa1DBY77fvkQrjSW3TNhOlnIZmau.jpeg",
      slug: "wasp-control",
    },
    {
      name: "Wood Borer Control",
      description: "Protect your wooden structures from destructive wood borers.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-iu93Xig2qSzLZ98eDeztMvqCnY4oHN.png",
      slug: "wood-borer-control",
    },
    {
      name: "Pipe Pest Control",
      description: "Specialized treatments for pests in plumbing and drainage systems.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.58_2e4e345f.jpg-lwb7nh9Iv04pJrAxIyHJa8J3a55yYD.jpeg",
      slug: "pipe-pest-control",
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Our Professional Pest Control Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              No.1 Quality Pest Control offers comprehensive, eco-friendly pest management solutions for homes and
              businesses in Chennai.
            </p>
          </div>
        </AnimatedSection>

        <StaggeredContainer staggerDelay={0.1} animation="fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.slug}
                className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                whileHover={{ y: -10 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="relative h-64">
                  <Image src={service.image || "/placeholder.svg"} alt={service.name} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-6">
                      <h3 className="text-2xl font-bold text-white">{service.name}</h3>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-4">{service.description}</p>
                  <Link href={`/services/${service.slug}`}>
                    <motion.button
                      className="bg-dark-green text-white px-4 py-2 rounded-md w-full"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Learn More
                    </motion.button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </StaggeredContainer>

        <AnimatedSection animation="fadeIn" delay={0.5}>
          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold mb-6">Need Professional Pest Control Services?</h3>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                <motion.button
                  className="btn-primary px-8 py-3"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  WhatsApp Now
                </motion.button>
              </a>
              <Link href="/contact-us">
                <motion.button className="btn-dark px-8 py-3" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
