"use client"

export const ServicesList = () => {
  return (
    <section className="mb-12">
      <h2 className="text-3xl font-bold mb-6 text-center">Our Pest Control Services</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Termite Control</h3>
          <p className="mb-4">
            Protect your property from destructive termites with our comprehensive termite control solutions.
          </p>
          <a href="/services/termite-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Cockroach Control</h3>
          <p className="mb-4">
            Eliminate cockroach infestations with our effective and long-lasting cockroach control treatments.
          </p>
          <a href="/services/cockroach-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Bed Bug Control</h3>
          <p className="mb-4">Get rid of bed bugs completely with our specialized bed bug extermination services.</p>
          <a href="/services/bed-bug-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Rodent Control</h3>
          <p className="mb-4">
            Keep rats and mice away from your property with our effective rodent control solutions.
          </p>
          <a href="/services/rodent-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Mosquito Control</h3>
          <p className="mb-4">Protect your family from mosquito-borne diseases with our mosquito control treatments.</p>
          <a href="/services/mosquito-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Spider Control</h3>
          <p className="mb-4">
            Eliminate spiders and prevent their return with our professional spider control services.
          </p>
          <a href="/services/spider-control" className="text-primary font-medium hover:underline">
            View Details →
          </a>
        </div>
      </div>
    </section>
  )
}

export default ServicesList
