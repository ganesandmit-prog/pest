"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { AnimatedSection } from "./framer-animations"
import { ChevronLeft, ChevronRight } from "lucide-react"

const priceCards = [
  { name: "Mosquito Control", image: "/images/price-mosquito.png" },
  { name: "Cockroach Control", image: "/images/price-cockroach.png" },
  { name: "Termite Control", image: "/images/price-termite.png" },
  { name: "Bed Bug Treatment", image: "/images/price-bedbug.png" },
  { name: "Rodent Control", image: "/images/price-rodent.png" },
  { name: "Termite Piping Control", image: "/images/price-termite-piping.png" },
  { name: "Spider Control", image: "/images/price-spider.png" },
  { name: "Fly Control", image: "/images/price-fly.png" },
]

export default function PriceListSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % priceCards.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + priceCards.length) % priceCards.length)
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
    setAutoplay(false)
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }
    // Resume autoplay after 5 seconds of inactivity
    setTimeout(() => setAutoplay(true), 5000)
  }

  useEffect(() => {
    if (autoplay) {
      timerRef.current = setInterval(() => {
        nextSlide()
      }, 4000) // Slow animation - 4 seconds per slide
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [autoplay])

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Service Pricing</h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            Transparent and affordable pricing for all your pest control needs. We offer competitive rates with no
            hidden charges.
          </p>
        </AnimatedSection>

        <div className="relative max-w-md mx-auto">
          <div className="overflow-hidden rounded-lg">
            <motion.div
              className="flex"
              initial={{ x: 0 }}
              animate={{ x: `-${currentIndex * 100}%` }}
              transition={{ duration: 0.7, ease: "easeInOut" }}
            >
              {priceCards.map((card, index) => (
                <div key={index} className="min-w-full">
                  <div className="flex justify-center">
                    <Image
                      src={card.image || "/placeholder.svg"}
                      alt={card.name}
                      width={300}
                      height={300}
                      className="rounded-lg shadow-md"
                    />
                  </div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Navigation buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white p-2 rounded-full shadow-md z-10"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-6 w-6 text-gray-700" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 bg-white p-2 rounded-full shadow-md z-10"
            aria-label="Next slide"
          >
            <ChevronRight className="h-6 w-6 text-gray-700" />
          </button>

          {/* Indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            {priceCards.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full ${currentIndex === index ? "bg-dark-green" : "bg-gray-300"}`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        <AnimatedSection animation="fadeIn" delay={0.4}>
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Contact us for customized pricing based on your specific needs.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-dark"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <motion.a
                href="https://wa.me/917558108600"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📲 WhatsApp Us
              </motion.a>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
