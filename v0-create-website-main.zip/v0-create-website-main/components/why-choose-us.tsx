"use client"

import { Clock, Heart, Award, DollarSign, Shield, Leaf } from "lucide-react"
import { motion } from "framer-motion"
import { AnimatedSection, StaggeredContainer } from "./framer-animations"

export default function WhyChooseUs() {
  return (
    <section className="bg-dark-green text-white py-16">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose No.1 Quality Pest Control?</h2>
        </AnimatedSection>

        <StaggeredContainer staggerDelay={0.1} animation="slideUp">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <Clock className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Over 45+ Years of Experience</h3>
              <p className="text-sm">Trusted by thousands of customers across Chennai</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <Heart className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Customer Care Focused</h3>
              <p className="text-sm">Personalized service with attention to detail</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <Award className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Locally Owned & Operated</h3>
              <p className="text-sm">Understanding Chennai's unique pest challenges</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <DollarSign className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Effective & Affordable</h3>
              <p className="text-sm">Quality service at competitive prices</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <Shield className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Safe for Family & Pets</h3>
              <p className="text-sm">Using products that protect your loved ones</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.div className="bg-white rounded-full p-4 mb-4" whileHover={{ scale: 1.1, rotate: 10 }}>
                <Leaf className="h-8 w-8 text-dark-green" />
              </motion.div>
              <h3 className="text-lg font-semibold mb-2">Eco-Friendly Solutions</h3>
              <p className="text-sm">Environmentally responsible pest control</p>
            </div>
          </div>
        </StaggeredContainer>

        <AnimatedSection animation="fadeIn" delay={0.5}>
          <div className="mt-12 text-center">
            <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
              <motion.button
                className="btn-primary px-8 py-3 text-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Contact Us on WhatsApp
              </motion.button>
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
