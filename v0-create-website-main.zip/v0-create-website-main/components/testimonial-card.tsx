"use client"

import { Star } from "lucide-react"
import { motion } from "framer-motion"

interface TestimonialCardProps {
  quote: string
  author: string
  rating?: number
  fullText?: string
}

export default function TestimonialCard({ quote, author, rating = 5, fullText }: TestimonialCardProps) {
  return (
    <motion.div
      className="testimonial-card h-full flex flex-col"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex mb-2">
        {Array.from({ length: rating }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.1 * i }}
          >
            <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
          </motion.div>
        ))}
      </div>

      <h3 className="text-lg font-bold mb-4">"{quote}"</h3>

      {fullText && <p className="text-sm mb-4 flex-grow">{fullText}</p>}

      <p className="text-sm mt-auto">- {author}</p>

      {fullText && (
        <motion.button
          className="mt-4 border border-white text-white px-4 py-2 rounded-md text-sm hover:bg-white hover:text-dark-brown transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Read More
        </motion.button>
      )}
    </motion.div>
  )
}
