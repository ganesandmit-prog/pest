"use client"

import Link from "next/link"

import type React from "react"

import { motion } from "framer-motion"
import { AnimatedSection } from "./framer-animations"
import { Search, Sprout, Shield, Calendar } from "lucide-react"

interface ProcessStepProps {
  icon: React.ReactNode
  title: string
  description: string
  step: number
}

const ProcessStep = ({ icon, title, description, step }: ProcessStepProps) => (
  <div className="relative">
    <motion.div
      className="bg-white p-6 rounded-lg shadow-md relative z-10"
      whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
    >
      <div className="absolute -top-5 -left-5 w-12 h-12 rounded-full bg-dark-green text-white flex items-center justify-center text-xl font-bold">
        {step}
      </div>
      <div className="text-dark-green mb-4 mt-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
    {step < 4 && <div className="hidden md:block absolute top-1/2 -right-8 w-16 h-2 bg-light-green z-0"></div>}
  </div>
)

interface ProcessSectionProps {
  title?: string
  steps?: {
    icon: React.ReactNode
    title: string
    description: string
  }[]
}

export function ProcessSection({ title = "Our Pest Control Process", steps }: ProcessSectionProps) {
  const defaultSteps = [
    {
      icon: <Search className="w-10 h-10" />,
      title: "Inspection & Assessment",
      description: "Our experts thoroughly inspect your property to identify pest issues and entry points.",
    },
    {
      icon: <Sprout className="w-10 h-10" />,
      title: "Customized Treatment Plan",
      description: "We develop a tailored pest control plan specific to your property and pest problems.",
    },
    {
      icon: <Shield className="w-10 h-10" />,
      title: "Eco-Friendly Treatment",
      description: "We implement safe, effective treatments using environmentally responsible products.",
    },
    {
      icon: <Calendar className="w-10 h-10" />,
      title: "Follow-up & Prevention",
      description: "Regular follow-ups ensure long-term protection and prevent future infestations.",
    },
  ]

  const stepsToRender = steps || defaultSteps

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">{title}</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We follow a systematic approach to ensure effective and long-lasting pest control results.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {stepsToRender.map((step, index) => (
            <AnimatedSection key={index} animation="fadeIn" delay={index * 0.2}>
              <ProcessStep {...step} step={index + 1} />
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection animation="fadeIn" delay={0.8}>
          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold mb-6">Ready to Get Started?</h3>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/919444420367" target="_blank" rel="noopener noreferrer">
                <motion.button
                  className="btn-primary px-8 py-3"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  WhatsApp Now
                </motion.button>
              </a>
              <Link href="/contact-us">
                <motion.button className="btn-dark px-8 py-3" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Schedule Inspection
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

export default ProcessSection
