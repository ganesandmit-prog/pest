"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { AnimatedSection } from "./framer-animations"

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    service: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setErrorMessage("")

    try {
      // Simulate form submission with a delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a production environment, you would use EmailJS with your service ID, template ID, and user ID
      // const result = await emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', e.target as HTMLFormElement, 'YOUR_USER_ID');

      setIsSuccess(true)
      setFormData({
        name: "",
        email: "",
        phone: "",
        address: "",
        service: "",
        message: "",
      })
    } catch (error) {
      console.error("Error submitting form:", error)
      setErrorMessage("There was an error submitting your request. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AnimatedSection animation="fadeIn">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control Services Chennai</h2>
        <p className="text-center mb-6">
          Fill out the form below to request a free pest control quote or schedule a pest inspection in Chennai. We
          offer termite control, cockroaches control, and commercial pest control at affordable price.
        </p>

        {isSuccess ? (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <p>
              Thank you for contacting No.1 Quality Pest Control Chennai! Our pest control team will get back to you
              shortly to discuss our pest control services Chennai including termite control, cockroaches control, and
              commercial pest control.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Name *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
                  placeholder="Your Email"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
                  placeholder="Your Phone Number"
                />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                  Address in Chennai *
                </label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
                  placeholder="Your Address in Chennai"
                />
              </div>
            </div>

            <div className="mb-4">
              <label htmlFor="service" className="block text-sm font-medium text-gray-700 mb-1">
                Pest Control Service Required *
              </label>
              <select
                id="service"
                name="service"
                value={formData.service}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
              >
                <option value="">Select Pest Control Service</option>
                <option value="Termite Control">Termite Control Chennai</option>
                <option value="Cockroach Control">Cockroaches Control Chennai</option>
                <option value="Bed Bug Control">Bed Bug Control Chennai</option>
                <option value="Mosquito Control">Mosquito Control Chennai</option>
                <option value="Rodent Control">Rodent Control Chennai</option>
                <option value="Commercial Pest Control">Commercial Pest Control Chennai</option>
                <option value="Other">Other Pest Control Services Chennai</option>
              </select>
            </div>

            <div className="mb-4">
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-light-green"
                placeholder="Tell us about your pest control needs in Chennai"
              ></textarea>
            </div>

            {errorMessage && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <p>{errorMessage}</p>
              </div>
            )}

            <div className="text-center">
              <motion.button
                type="submit"
                className="bg-dark-green text-white px-6 py-3 rounded-md font-medium"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Submitting..." : "Submit Pest Control Inquiry Chennai"}
              </motion.button>
            </div>
          </form>
        )}

        <div className="mt-8 text-center">
          <p className="text-gray-600">Or call us directly for immediate pest control service in Chennai:</p>
          <a href="tel:+917558108600" className="text-xl font-bold text-dark-green hover:underline">
            +91 7558108600
          </a>
          <p className="text-gray-600 mt-2">
            Best price for termite control, cockroaches control, and commercial pest control services Chennai.
          </p>
        </div>
      </div>
    </AnimatedSection>
  )
}

export default ContactForm
