"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { useIsMobile } from "@/hooks/use-mobile"

const images = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpLHKJ.jpeg", // Mosquito
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.59_ca633715.jpg-KwzRWzbglYoAXHoH4Ck0S8RZPv7NxQ.jpeg", // Cockroach
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.16_5f166834.jpg-pUBa1DBY77fvkQrjSW3TNhOlnIZmau.jpeg", // Bed Bug
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg", // Rodent
]

const slideContent = [
  {
    // Mosquito content
    title: "Say Goodbye to Mosquitoes in Chennai!",
    description:
      "Tired of itchy bites and mosquito-borne diseases? Our expert mosquito control service provides long-lasting relief, ensuring a safe and mosquito-free home.",
  },
  {
    // Cockroach content
    title: "Cockroach-Free Living Starts Here!",
    description:
      "Cockroaches spread germs and damage your kitchen. Our cockroach removal service eliminates infestations at the source, keeping your home safe and hygienic.",
  },
  {
    // Bed Bug content
    title: "Sleep Peacefully Without Bed Bugs!",
    description:
      "Don't let bed bugs ruin your sleep! Our bed bug extermination service ensures complete removal, giving you a clean and comfortable environment.",
  },
  {
    // Rodent content
    title: "Stop Rodents from Invading Your Space!",
    description:
      "Rats and mice cause property damage and spread diseases. Our rodent control service ensures complete rodent elimination with safe and effective methods.",
  },
]

export default function HeroSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const isMobile = useIsMobile()

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative h-[600px] overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0"
        >
          <Image
            src={images[currentIndex] || "/placeholder.svg"}
            alt="Pest control professional"
            fill
            className="object-cover brightness-75"
            priority
          />
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 container mx-auto px-4 h-full flex flex-col justify-center items-center text-white text-center">
        {/* Add padding-top for mobile to prevent overlap with logo */}
        <motion.div
          className={`${isMobile ? "pt-16" : ""} flex flex-col items-center`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <motion.h1
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Best Pest Control Services in Chennai – No.1 Quality Pest Control
          </motion.h1>
          <motion.p
            className="text-xl mb-8 max-w-3xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Safe, Effective & Affordable Pest Management for Homes & Businesses.
          </motion.p>

          <motion.div
            className="text-lg mb-8 max-w-3xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <h3 className="text-2xl font-bold mb-4">{slideContent[currentIndex].title}</h3>
            <p className="mb-4">{slideContent[currentIndex].description}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="flex gap-4"
          >
            <Link href="/contact-us">
              <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                Get a Pest-Free Home Today!
              </motion.button>
            </Link>
            <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
              <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                WhatsApp Now
              </motion.button>
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Slider indicators */}
      <div className="absolute bottom-8 left-0 right-0 z-10 flex justify-center space-x-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-3 h-3 rounded-full ${
              currentIndex === index ? "bg-white" : "bg-white/50"
            } transition-all duration-300`}
          />
        ))}
      </div>
    </div>
  )
}
