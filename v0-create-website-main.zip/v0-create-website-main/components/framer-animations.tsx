"use client"

import type React from "react"

import { type ReactNode, useRef, useEffect, useState } from "react"
import { motion, useAnimation, useInView, type Variant } from "framer-motion"

interface AnimatedSectionProps {
  children: ReactNode
  className?: string
  delay?: number
  duration?: number
  once?: boolean
  animation?: "fadeIn" | "slideUp" | "slideLeft" | "slideRight" | "scale"
}

export function AnimatedSection({
  children,
  className = "",
  delay = 0,
  duration = 0.5,
  once = true,
  animation = "fadeIn",
}: AnimatedSectionProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once, margin: "-100px 0px" })
  const controls = useAnimation()

  const variants = {
    hidden: {
      opacity: 0,
      y: animation === "slideUp" ? 20 : 0,
      x: animation === "slideLeft" ? -20 : animation === "slideRight" ? 20 : 0,
      scale: animation === "scale" ? 0.95 : 1,
    } as Variant,
    visible: {
      opacity: 1,
      y: 0,
      x: 0,
      scale: 1,
      transition: {
        duration,
        delay,
        ease: "easeOut",
      },
    } as Variant,
  }

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    } else if (!once) {
      controls.start("hidden")
    }
  }, [isInView, controls, once])

  return (
    <motion.div ref={ref} initial="hidden" animate={controls} variants={variants} className={className}>
      {children}
    </motion.div>
  )
}

interface StaggeredContainerProps {
  children: ReactNode
  className?: string
  staggerDelay?: number
  containerDelay?: number
  animation?: "fadeIn" | "slideUp" | "slideLeft" | "slideRight" | "scale"
}

export function StaggeredContainer({
  children,
  className = "",
  staggerDelay = 0.1,
  containerDelay = 0,
  animation = "fadeIn",
}: StaggeredContainerProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px 0px" })

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: staggerDelay,
        delayChildren: containerDelay,
      },
    },
  }

  const itemVariants = {
    hidden: {
      opacity: 0,
      y: animation === "slideUp" ? 20 : 0,
      x: animation === "slideLeft" ? -20 : animation === "slideRight" ? 20 : 0,
      scale: animation === "scale" ? 0.95 : 1,
    },
    visible: {
      opacity: 1,
      y: 0,
      x: 0,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  }

  return (
    <motion.div
      ref={ref}
      variants={containerVariants}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      className={className}
    >
      {Array.isArray(children)
        ? children.map((child, index) => (
            <motion.div key={index} variants={itemVariants}>
              {child}
            </motion.div>
          ))
        : children}
    </motion.div>
  )
}

export function fadeIn({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export function SlideUp({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export function SlideInLeft({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export function SlideInRight({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export function ScaleIn({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export function AnimatedButton({ children, className = "", onClick = null }) {
  return (
    <motion.button className={className} onClick={onClick} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
      {children}
    </motion.button>
  )
}

export function AnimatedLink({ children, className = "", href = "#" }) {
  return (
    <motion.a href={href} className={className} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
      {children}
    </motion.a>
  )
}

export function useScrollAnimation() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return scrollY
}

export { fadeIn as FadeIn }

export const FadeInStagger = ({ children }: { children: React.ReactNode }) => {
  return <div className="space-y-8">{children}</div>
}
