import Image from "next/image"
import Link from "next/link"
import { formatDate } from "@/lib/utils"

interface BlogCardProps {
  title: string
  date: string
  image: string
  slug: string
}

export default function BlogCard({ title, date, image, slug }: BlogCardProps) {
  return (
    <div className="group">
      <Link href={`/blog/${slug}`}>
        <div className="relative h-48 mb-4 overflow-hidden rounded-md">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
        <div>
          <p className="text-sm text-gray-500 mb-2">{formatDate(date)}</p>
          <h3 className="font-bold text-lg group-hover:text-primary transition-colors">{title}</h3>
        </div>
      </Link>
    </div>
  )
}
