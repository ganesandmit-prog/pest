"use client"

import { Phone, MessageSquare } from "lucide-react"
import { motion } from "framer-motion"

export const FloatingActionButton = () => {
  return (
    <motion.div
      className="fixed bottom-20 right-4 z-50 flex flex-col gap-3"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.a
        href="https://wa.me/917558108600"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center w-16 h-16 rounded-full bg-green-500 text-white shadow-lg relative group"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        aria-label="WhatsApp"
      >
        <MessageSquare size={28} />
        <span className="absolute -left-20 bg-black text-white px-2 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity">
          WhatsApp
        </span>
      </motion.a>

      <motion.a
        href="tel:+917558108600"
        className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-600 text-white shadow-lg relative group"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        aria-label="Call"
      >
        <Phone size={28} />
        <span className="absolute -left-20 bg-black text-white px-2 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity">
          Call Now
        </span>
      </motion.a>
    </motion.div>
  )
}

// Keep the default export for backward compatibility
export default FloatingActionButton
