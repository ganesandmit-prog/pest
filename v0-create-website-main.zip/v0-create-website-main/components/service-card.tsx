"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"

interface ServiceCardProps {
  title: string
  image: string
  href: string
}

export default function ServiceCard({ title, image, href }: ServiceCardProps) {
  return (
    <Link href={href} className="block service-card">
      <motion.div className="relative h-full w-full" whileHover={{ scale: 1.03 }} transition={{ duration: 0.3 }}>
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
        <div className="service-card-overlay">
          <motion.h3
            className="text-xl font-bold"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {title}
          </motion.h3>
        </div>
      </motion.div>
    </Link>
  )
}
