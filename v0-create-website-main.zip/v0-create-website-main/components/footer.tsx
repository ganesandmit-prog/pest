"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { AnimatedSection, StaggeredContainer } from "./framer-animations"

export default function Footer() {
  const serviceAreas = [
    { name: "Adambakkam", href: "/service-areas/adambakkam" },
    { name: "Adyar", href: "/service-areas/adyar" },
    { name: "Alandur", href: "/service-areas/alandur" },
    { name: "Alapakkam", href: "/service-areas/alapakkam" },
    { name: "Alwarpet", href: "/service-areas/alwarpet" },
    { name: "Alwarthirunagar", href: "/service-areas/alwarthirunagar" },
    { name: "Ambattur", href: "/service-areas/ambattur" },
    { name: "Aminjikarai", href: "/service-areas/aminjikarai" },
    { name: "Anna Nagar", href: "/service-areas/anna-nagar" },
    { name: "Annanur", href: "/service-areas/annanur" },
    { name: "Arumbakkam", href: "/service-areas/arumbakkam" },
    { name: "Ashok Nagar", href: "/service-areas/ashok-nagar" },
    { name: "Avadi", href: "/service-areas/avadi" },
    { name: "Ayanavaram", href: "/service-areas/ayanavaram" },
    { name: "Basin Bridge", href: "/service-areas/basin-bridge" },
    { name: "Beemannapettai", href: "/service-areas/beemannapettai" },
    { name: "Besant Nagar", href: "/service-areas/besant-nagar" },
    { name: "Chepauk", href: "/service-areas/chepauk" },
    { name: "Chetput", href: "/service-areas/chetput" },
    { name: "Chintadripet", href: "/service-areas/chintadripet" },
    { name: "Chitlapakkam", href: "/service-areas/chitlapakkam" },
    { name: "Choolai", href: "/service-areas/choolai" },
    { name: "Choolaimedu", href: "/service-areas/choolaimedu" },
    { name: "Chrompet", href: "/service-areas/chrompet" },
    { name: "Egmore", href: "/service-areas/egmore" },
    { name: "Ekkaduthangal", href: "/service-areas/ekkaduthangal" },
    { name: "Ennore", href: "/service-areas/ennore" },
    { name: "Foreshore Estate", href: "/service-areas/foreshore-estate" },
    { name: "Fort St. George", href: "/service-areas/fort-st-george" },
    { name: "George Town", href: "/service-areas/george-town" },
    { name: "Gopalapuram", href: "/service-areas/gopalapuram" },
    { name: "Government Estate", href: "/service-areas/government-estate" },
    { name: "Guindy", href: "/service-areas/guindy" },
    { name: "Guduvancheri", href: "/service-areas/guduvancheri" },
    { name: "Injambakkam", href: "/service-areas/injambakkam" },
    { name: "Iyyapanthangal", href: "/service-areas/iyyapanthangal" },
    { name: "Jafferkhanpet", href: "/service-areas/jafferkhanpet" },
    { name: "Kadambathur", href: "/service-areas/kadambathur" },
    { name: "Karapakkam", href: "/service-areas/karapakkam" },
    { name: "Kattivakkam", href: "/service-areas/kattivakkam" },
    { name: "Kattupakkam", href: "/service-areas/kattupakkam" },
    { name: "Kazhipattur", href: "/service-areas/kazhipattur" },
    { name: "K.K. Nagar", href: "/service-areas/kk-nagar" },
    { name: "Keelkattalai", href: "/service-areas/keelkattalai" },
    { name: "Kilpauk", href: "/service-areas/kilpauk" },
    { name: "Kodambakkam", href: "/service-areas/kodambakkam" },
    { name: "Kodungaiyur", href: "/service-areas/kodungaiyur" },
    { name: "Kolathur", href: "/service-areas/kolathur" },
    { name: "Korattur", href: "/service-areas/korattur" },
    { name: "Korukkupet", href: "/service-areas/korukkupet" },
    { name: "Kottivakkam", href: "/service-areas/kottivakkam" },
    { name: "Kotturpuram", href: "/service-areas/kotturpuram" },
    { name: "Kottur", href: "/service-areas/kottur" },
    { name: "Kovur", href: "/service-areas/kovur" },
    { name: "Koyambedu", href: "/service-areas/koyambedu" },
    { name: "Kundrathur", href: "/service-areas/kundrathur" },
    { name: "Madhavaram", href: "/service-areas/madhavaram" },
    { name: "Madipakkam", href: "/service-areas/madipakkam" },
    { name: "Maduravoyal", href: "/service-areas/maduravoyal" },
    { name: "Manali", href: "/service-areas/manali" },
    { name: "Manali New Town", href: "/service-areas/manali-new-town" },
    { name: "Manapakkam", href: "/service-areas/manapakkam" },
    { name: "Mandaveli", href: "/service-areas/mandaveli" },
    { name: "Mangadu", href: "/service-areas/mangadu" },
    { name: "Mannadi", href: "/service-areas/mannadi" },
    { name: "Mathur", href: "/service-areas/mathur" },
    { name: "Medavakkam", href: "/service-areas/medavakkam" },
    { name: "MGR Nagar", href: "/service-areas/mgr-nagar" },
    { name: "Minjur", href: "/service-areas/minjur" },
    { name: "Mogappair", href: "/service-areas/mogappair" },
    { name: "Mount Road", href: "/service-areas/mount-road" },
    { name: "Moulivakkam", href: "/service-areas/moulivakkam" },
    { name: "Mugalivakkam", href: "/service-areas/mugalivakkam" },
    { name: "Mudichur", href: "/service-areas/mudichur" },
    { name: "Mylapore", href: "/service-areas/mylapore" },
  ]

  return (
    <footer className="bg-dark-green text-white">
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <AnimatedSection animation="slideUp" delay={0.1}>
            <div className="flex flex-col items-start">
              <Link href="/" className="mb-4">
                <motion.div whileHover={{ scale: 1.05 }}>
                  <Image
                    src="/images/logo.png"
                    alt="No.1 Quality Pest Control Chennai - Best Pest Control Services Chennai"
                    width={220}
                    height={80}
                    className="max-h-20 w-auto"
                  />
                </motion.div>
              </Link>
              <div className="mt-2">
                <p className="font-semibold mb-1">Contact for Pest Control Services Chennai</p>
                <motion.a
                  href="tel:+917558108600"
                  className="text-xl font-bold hover:underline"
                  whileHover={{ scale: 1.05 }}
                >
                  +91 7558108600
                </motion.a>
              </div>
              <div className="mt-2">
                <p className="font-semibold mb-1">Email for Pest Control Chennai</p>
                <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
              </div>
              <div className="mt-2">
                <p className="font-semibold mb-1">Owner</p>
                <span className="font-bold">Chandran</span>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="slideUp" delay={0.2}>
            <div>
              <h3 className="text-sm font-semibold mb-4">Pest Control Service Address Chennai</h3>
              <p className="mb-1">202 Broadway Parrys</p>
              <p className="mb-4">Chennai-600001, Tamil Nadu</p>

              {/* Google Maps Embed */}
              <div className="mt-4" style={{ position: "relative" }}>
                <div style={{ position: "relative", paddingBottom: "75%", height: 0, overflow: "hidden" }}>
                  <iframe
                    style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: 0 }}
                    loading="lazy"
                    allowFullScreen
                    src="https://maps.google.com/maps?q=Broadway+parrys+chennai&output=embed"
                  ></iframe>
                </div>
                <a
                  href="https://mapembeds.com/"
                  rel="noreferrer noopener"
                  target="_blank"
                  style={{
                    position: "absolute",
                    width: "1px",
                    height: "1px",
                    padding: 0,
                    margin: "-1px",
                    overflow: "hidden",
                    clip: "rect(0,0,0,0)",
                    whiteSpace: "nowrap",
                    border: 0,
                  }}
                >
                  embed google maps
                </a>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="slideUp" delay={0.3}>
            <div>
              <h3 className="text-sm font-semibold mb-4">Pest Control Service Links Chennai</h3>
              <StaggeredContainer staggerDelay={0.05} animation="slideLeft">
                <ul className="space-y-2">
                  <li>
                    <Link href="/" className="hover:underline">
                      Home - Pest Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/about-us" className="hover:underline">
                      About Our Pest Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/residential" className="hover:underline">
                      Residential Pest Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/commercial" className="hover:underline">
                      Commercial Pest Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/services" className="hover:underline">
                      Our Pest Control Services Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/services/termite-control" className="hover:underline">
                      Termite Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/services/cockroach-control" className="hover:underline">
                      Cockroaches Control Chennai
                    </Link>
                  </li>
                  <li>
                    <Link href="/service-areas/adambakkam" className="hover:underline">
                      Pest Control in Adambakkam
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact-us" className="hover:underline">
                      Contact Us for Pest Control Chennai
                    </Link>
                  </li>
                </ul>
              </StaggeredContainer>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="slideUp" delay={0.4}>
            <div>
              <h3 className="text-sm font-semibold mb-4">Pest Control Service Areas in Chennai</h3>
              <p className="text-sm">
                We provide professional pest control services across Chennai including Anna Nagar, Adyar, T. Nagar,
                Velachery, Mylapore, Porur, Tambaram, OMR, Kodambakkam, and more. Our termite control, cockroaches
                control, and commercial pest control services are available throughout Chennai at competitive price.
              </p>
              <p className="text-sm mt-4">
                Looking for the best pest control service in Chennai? No.1 Quality Pest Control offers comprehensive
                pest control services Chennai including termite control, cockroaches control, and commercial pest
                control at affordable price. Our control services Chennai are the best in the city.
              </p>
            </div>
          </AnimatedSection>
        </div>

        <AnimatedSection animation="fadeIn" delay={0.5}>
          <div className="mt-12 pt-8 border-t border-gray-700 text-sm">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p>
                © 2025 No.1 Quality Pest Control Chennai. Best Pest Control Services Chennai for termite control,
                cockroaches control, and commercial pest control at affordable price. All Rights Reserved.
              </p>
              <div className="flex space-x-4 mt-4 md:mt-0">
                <Link href="/privacy-policy" className="hover:underline">
                  Privacy Policy
                </Link>
                <Link href="/terms-of-service" className="hover:underline">
                  Terms of Service
                </Link>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </footer>
  )
}
