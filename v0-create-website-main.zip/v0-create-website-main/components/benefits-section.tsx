"use client"

import type React from "react"

import { Shield, Leaf, Home, Building2, Factory, HeartPulse, Zap, BadgeCheck } from "lucide-react"
import { motion } from "framer-motion"
import { AnimatedSection } from "./framer-animations"

interface BenefitProps {
  icon: React.ReactNode
  title: string
  description: string
}

const Benefit = ({ icon, title, description }: BenefitProps) => (
  <motion.div
    className="bg-white p-6 rounded-lg shadow-md"
    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
  >
    <div className="text-dark-green mb-4">{icon}</div>
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </motion.div>
)

export const BenefitsSection = () => {
  const benefits = [
    {
      icon: <Leaf className="w-10 h-10" />,
      title: "Eco-Friendly Solutions",
      description:
        "Our pest control methods prioritize environmental safety with non-toxic and biodegradable products.",
    },
    {
      icon: <Shield className="w-10 h-10" />,
      title: "Safe for Family & Pets",
      description: "All our treatments are designed to be safe for your family, children, and pets.",
    },
    {
      icon: <Home className="w-10 h-10" />,
      title: "Home Pest Control",
      description: "Comprehensive residential pest control services to keep your home pest-free year-round.",
    },
    {
      icon: <Building2 className="w-10 h-10" />,
      title: "Office Pest Control",
      description: "Discreet and effective pest management solutions for commercial office spaces.",
    },
    {
      icon: <Factory className="w-10 h-10" />,
      title: "Industrial Pest Control",
      description: "Specialized pest control services for factories, warehouses, and industrial facilities.",
    },
    {
      icon: <HeartPulse className="w-10 h-10" />,
      title: "Health Protection",
      description: "Prevent disease transmission by eliminating pests that carry harmful pathogens.",
    },
    {
      icon: <Zap className="w-10 h-10" />,
      title: "Modern Techniques",
      description: "We employ the latest pest control technologies and methods for maximum effectiveness.",
    },
    {
      icon: <BadgeCheck className="w-10 h-10" />,
      title: "Certified Professionals",
      description: "Our team consists of trained and certified pest control experts with years of experience.",
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <AnimatedSection animation="fadeIn">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Why Choose Our Pest Control Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              RAM Pest Control delivers safe, effective, and eco-friendly pest management solutions for homes and
              businesses in Chennai.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
              <Benefit {...benefit} />
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection animation="fadeIn" delay={0.5}>
          <div className="mt-12 text-center">
            <a href="https://wa.me/919444420367" target="_blank" rel="noopener noreferrer">
              <motion.button
                className="btn-primary px-8 py-3 text-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Contact Us on WhatsApp
              </motion.button>
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

export default BenefitsSection
