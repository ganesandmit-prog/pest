import Link from "next/link"
import { cn } from "@/lib/utils"

interface CTAProps {
  title?: string
  description?: string
  buttonText?: string
  buttonLink?: string
  className?: string
  variant?: "primary" | "secondary"
  phone?: string
}

export default function CTA({
  title = "Ready to get rid of pests?",
  description = "Contact us today for a free inspection and quote. Our team of experts is ready to help you eliminate pests from your home or business.",
  buttonText = "Contact Us Now",
  buttonLink = "/contact-us",
  className,
  variant = "primary",
  phone = "+91 9840704510",
}: CTAProps) {
  return (
    <section
      className={cn(
        "py-12",
        variant === "primary" ? "bg-green-700 text-white" : "bg-gray-100 text-gray-900",
        className,
      )}
    >
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">{title}</h2>
          <p className={cn("mb-8 text-lg", variant === "primary" ? "text-green-100" : "text-gray-600")}>
            {description}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href={buttonLink}
              className={cn(
                "px-6 py-3 rounded-md font-medium text-center transition-colors",
                variant === "primary"
                  ? "bg-white text-green-700 hover:bg-green-50"
                  : "bg-green-700 text-white hover:bg-green-800",
              )}
            >
              {buttonText}
            </Link>

            {phone && (
              <a
                href={`tel:${phone.replace(/\s+/g, "")}`}
                className={cn(
                  "flex items-center gap-2 font-medium",
                  variant === "primary" ? "text-white" : "text-green-700",
                )}
              >
                <span>or call:</span>
                <span className="text-lg">{phone}</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
