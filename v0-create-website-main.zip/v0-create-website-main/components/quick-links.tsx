"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { StaggeredContainer } from "./framer-animations"

export function QuickLinks() {
  const links = [
    {
      title: "Customer Reviews",
      description: "Read what our Chennai pest control clients say",
      href: "/reviews",
    },
    {
      title: "Our Services",
      description: "Explore our pest control services Chennai",
      href: "/services",
    },
    {
      title: "Helpful Resources",
      description: "Learn about common pests in Chennai",
      href: "/pest-library",
    },
    {
      title: "Service Areas",
      description: "Chennai pest control service locations",
      href: "/service-areas",
    },
  ]

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <StaggeredContainer staggerDelay={0.1} animation="slideUp">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {links.map((link, index) => (
              <Link key={index} href={link.href}>
                <motion.div
                  className="bg-light-green text-white p-6 rounded-md flex flex-col items-center text-center hover:bg-light-green/90 transition-colors h-full"
                  whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                >
                  <span className="text-2xl font-semibold mb-2">{link.title}</span>
                  <span className="text-sm">{link.description}</span>
                </motion.div>
              </Link>
            ))}
          </div>
        </StaggeredContainer>
      </div>
    </section>
  )
}

// Add default export that references the named export
export default QuickLinks
