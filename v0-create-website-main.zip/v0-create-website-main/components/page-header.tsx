"use client"

import Link from "next/link"
import { motion } from "framer-motion"

interface PageHeaderProps {
  title: string
  backgroundImage?: string
  breadcrumbs?: { label: string; href: string }[]
}

export function PageHeader({
  title,
  backgroundImage = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",
  breadcrumbs,
}: PageHeaderProps) {
  return (
    <motion.div
      className="page-header"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">{title}</h1>

        {breadcrumbs && (
          <motion.div
            className="flex items-center justify-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            {breadcrumbs.map((crumb, index) => (
              <div key={index} className="flex items-center">
                {index > 0 && <span className="mx-2">/</span>}
                <Link href={crumb.href} className="hover:underline text-sm font-medium">
                  {crumb.label}
                </Link>
              </div>
            ))}
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default PageHeader
