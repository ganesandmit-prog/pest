import { LucideStar } from "lucide-react"

export const Star = LucideStar
