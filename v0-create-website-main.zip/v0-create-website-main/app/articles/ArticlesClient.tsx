"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import FloatingActionButton from "@/components/floating-action-button"

const articles = [
  {
    slug: "why-pest-control-in-chennai-is-essential",
    title: "Why Pest Control in Chennai Is Essential for Your Home and Health",
    excerpt:
      "Discover why pest control is crucial for maintaining a safe and healthy environment in Chennai's tropical climate.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpLHKJ.jpeg",
    date: "May 10, 2025",
  },
  {
    slug: "common-pests-in-chennai",
    title: "What Are the Common Pests in Chennai and How to Deal with Them",
    excerpt: "Learn about the most common pests in Chennai and effective strategies to manage them.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.59_ca633715.jpg-KwzRWzbglYoAXHoH4Ck0S8RZPv7NxQ.jpeg",
    date: "May 8, 2025",
  },
  {
    slug: "cost-of-pest-control-in-chennai",
    title: "The Cost of Pest Control in Chennai: What You Should Know",
    excerpt: "Understand the pricing factors and average costs for different pest control services in Chennai.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.16_5f166834.jpg-pUBa1DBY77fvkQrjSW3TNhOlnIZmau.jpeg",
    date: "May 5, 2025",
  },
  {
    slug: "common-pests-and-how-pest-control-helps",
    title: "Common Pests in Chennai and How Pest Control Can Help",
    excerpt:
      "Explore the various pests common in Chennai and how professional pest control services can effectively eliminate them.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.58_2e4e345f.jpg-lwb7nh9Iv04pJrAxIyHJa8J3a55yYD.jpeg",
    date: "May 3, 2025",
  },
  {
    slug: "eco-friendly-pest-control-services",
    title: "Eco-Friendly Pest Control Services in Chennai: A Safer Choice",
    excerpt:
      "Discover environmentally friendly pest control options that are safe for your family, pets, and the planet.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg",
    date: "April 30, 2025",
  },
  {
    slug: "how-to-choose-best-pest-control-company",
    title: "How to Choose the Best Pest Control Company in Chennai",
    excerpt: "Learn what factors to consider when selecting a reliable and effective pest control service in Chennai.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.07_95330c8b.jpg-B10Tm1BVj30SHkr83wW0gOaEAebAXw.jpeg",
    date: "April 28, 2025",
  },
  {
    slug: "is-pest-control-safe-for-family-and-pets",
    title: "Is Pest Control Safe for My Family and Pets in Chennai?",
    excerpt:
      "Understand how modern pest control methods ensure safety for your loved ones while effectively eliminating pests.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png",
    date: "April 25, 2025",
  },
  {
    slug: "how-often-should-you-get-pest-control",
    title: "How Often Should You Get Pest Control in Chennai? A Complete Guide",
    excerpt:
      "Find out the recommended frequency for pest control services based on your property type and pest issues.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpLHKJ.jpeg",
    date: "April 22, 2025",
  },
  {
    slug: "benefits-of-hiring-professional-pest-control",
    title: "The Benefits of Hiring a Professional Pest Control Service in Chennai",
    excerpt: "Explore the advantages of choosing professional pest management over DIY methods.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.59_ca633715.jpg-KwzRWzbglYoAXHoH4Ck0S8RZPv7NxQ.jpeg",
    date: "April 20, 2025",
  },
  {
    slug: "diy-vs-professional-pest-control",
    title: "DIY Pest Control vs. Professional Pest Control in Chennai: What's the Difference?",
    excerpt: "Compare the pros and cons of DIY pest control methods versus hiring professional services.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.16_5f166834.jpg-pUBa1DBY77fvkQrjSW3TNhOlnIZmau.jpeg",
    date: "April 18, 2025",
  },
]

export default function ArticlesClient() {
  return (
    <>
      <FloatingActionButton />
      <PageHeader
        title="Pest Control Articles & Resources"
        subtitle="Expert information, tips, and advice about pest control in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {articles.map((article, index) => (
                <motion.div
                  key={article.slug}
                  className="bg-white rounded-lg shadow-md overflow-hidden"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Link href={`/articles/${article.slug}`}>
                    <div className="relative h-48">
                      <Image
                        src={article.image || "/placeholder.svg"}
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-6">
                      <p className="text-sm text-gray-500 mb-2">{article.date}</p>
                      <h3 className="text-xl font-bold mb-2">{article.title}</h3>
                      <p className="text-gray-600">{article.excerpt}</p>
                      <div className="mt-4 text-light-green font-medium hover:underline">Read More →</div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>
    </>
  )
}
