"use client"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import FloatingActionButton from "@/components/floating-action-button"

export default function EcoFriendlyPestControlClient() {
  return (
    <>
      <FloatingActionButton />
      <PageHeader
        title="Eco-Friendly Pest Control Services in Chennai: A Safer Choice"
        subtitle="Safe and effective green pest control solutions"
      />

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <AnimatedSection animation="fadeIn">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="flex items-center text-sm text-gray-500 mb-6">
                <span>April 30, 2025</span>
                <span className="mx-2">•</span>
                <span>5 min read</span>
                <span className="mx-2">•</span>
                <Link href="/articles" className="text-light-green hover:underline">
                  Back to Articles
                </Link>
              </div>

              <article className="prose prose-lg max-w-none">
                <h1 className="text-3xl font-bold text-dark-green mb-6">
                  Eco-Friendly Pest Control Services in Chennai: A Safer Choice
                </h1>

                <p className="mb-6">
                  Chennai residents are increasingly looking for safe, eco-friendly pest control solutions to protect
                  their homes and businesses without harming health or the environment. With growing concerns about
                  chemical exposure, families with children, pets, and sensitive individuals are turning to green pest
                  control alternatives.
                </p>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Why Choose Eco-Friendly Pest Control in Chennai?
                </h2>
                <p className="mb-6">
                  Chennai's hot and humid climate attracts a variety of pests—termites, cockroaches, rodents, and
                  mosquitoes being the most common. While traditional pest control methods may use strong chemicals,
                  eco-friendly pest control services use plant-based, non-toxic, and biodegradable treatments that are:
                </p>

                <ul className="list-disc pl-6 mb-6">
                  <li>Safe for children & pets</li>
                  <li>Gentle on the environment</li>
                  <li>Just as effective as chemical-based methods</li>
                  <li>Ideal for homes, hospitals, schools & food-based businesses</li>
                </ul>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Common Pests Treated with Eco-Friendly Methods
                </h2>

                <h3 className="text-xl font-semibold text-dark-green mt-6 mb-3">1. Cockroaches</h3>
                <p className="mb-2">
                  <strong>Problem:</strong> Found in kitchens, bathrooms, and sewage pipelines.
                </p>
                <p className="mb-4">
                  <strong>Green Solution:</strong> Herbal gel baiting and boric-based powders.
                </p>

                <h3 className="text-xl font-semibold text-dark-green mt-6 mb-3">2. Termites</h3>
                <p className="mb-2">
                  <strong>Problem:</strong> Silent wood destroyers.
                </p>
                <p className="mb-4">
                  <strong>Green Solution:</strong> Natural termite repellents and non-toxic barriers like orange oil,
                  neem extract, and biotoxins.
                </p>

                <h3 className="text-xl font-semibold text-dark-green mt-6 mb-3">3. Rodents</h3>
                <p className="mb-2">
                  <strong>Problem:</strong> Damage wires, furniture and spread disease.
                </p>
                <p className="mb-4">
                  <strong>Green Solution:</strong> Ultrasonic rodent repellers, steel mesh sealing, and humane traps.
                </p>

                <h3 className="text-xl font-semibold text-dark-green mt-6 mb-3">4. Mosquitoes</h3>
                <p className="mb-2">
                  <strong>Problem:</strong> Spread dengue, malaria, chikungunya.
                </p>
                <p className="mb-4">
                  <strong>Green Solution:</strong> Larvicide based on Bacillus thuringiensis, citronella fogging, and
                  natural repellents like neem and lemongrass oil.
                </p>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Residential vs. Commercial Eco Pest Control Services
                </h2>

                <div className="overflow-x-auto mb-6">
                  <table className="min-w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-light-green text-white">
                        <th className="border border-gray-300 px-4 py-2">Category</th>
                        <th className="border border-gray-300 px-4 py-2">Residential Pest Control</th>
                        <th className="border border-gray-300 px-4 py-2">Commercial Pest Control</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border border-gray-300 px-4 py-2 font-semibold">Focus</td>
                        <td className="border border-gray-300 px-4 py-2">Family safety, low toxicity</td>
                        <td className="border border-gray-300 px-4 py-2">Staff & customer safety</td>
                      </tr>
                      <tr>
                        <td className="border border-gray-300 px-4 py-2 font-semibold">Popular in</td>
                        <td className="border border-gray-300 px-4 py-2">Homes, apartments</td>
                        <td className="border border-gray-300 px-4 py-2">Restaurants, clinics, offices</td>
                      </tr>
                      <tr>
                        <td className="border border-gray-300 px-4 py-2 font-semibold">Price Range</td>
                        <td className="border border-gray-300 px-4 py-2">₹1,200 – ₹3,000</td>
                        <td className="border border-gray-300 px-4 py-2">₹3,000 – ₹12,000/month</td>
                      </tr>
                      <tr>
                        <td className="border border-gray-300 px-4 py-2 font-semibold">Frequency</td>
                        <td className="border border-gray-300 px-4 py-2">Monthly / Quarterly</td>
                        <td className="border border-gray-300 px-4 py-2">Bi-weekly / Monthly</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <p className="mb-6">
                  Whether you're looking for a green solution for your home or a commercial pest control service in
                  Chennai, eco-friendly options are now widely available.
                </p>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Benefits of Green Pest Control Services in Chennai
                </h2>

                <ul className="list-disc pl-6 mb-6">
                  <li>
                    <strong>Safe Indoors:</strong> No need to vacate your home during treatment.
                  </li>
                  <li>
                    <strong>Eco-Conscious:</strong> Supports a sustainable Chennai.
                  </li>
                  <li>
                    <strong>Odor-Free:</strong> Unlike harsh chemicals, herbal treatments don't leave strong smells.
                  </li>
                  <li>
                    <strong>Pest-Specific Targeting:</strong> Modern eco-friendly formulas are engineered to attack only
                    pests—not humans or pets.
                  </li>
                </ul>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Choosing the Right Eco-Friendly Pest Control Company in Chennai
                </h2>

                <p className="mb-4">When selecting an eco-friendly pest control company, look for:</p>

                <ul className="list-disc pl-6 mb-6">
                  <li>Certification in herbal/green treatment methods</li>
                  <li>Transparent service process with product names listed</li>
                  <li>Positive customer reviews on Google & Justdial</li>
                  <li>Follow-up support and warranty</li>
                  <li>Options for residential and commercial services</li>
                </ul>

                <p className="mb-4">Search for companies that offer:</p>

                <ul className="list-disc pl-6 mb-6">
                  <li>Contactless inspection & digital payment options</li>
                  <li>Pest control offers in Chennai for green treatment</li>
                  <li>Annual contracts with herbal products</li>
                </ul>

                <h2 className="text-2xl font-semibold text-dark-green mt-8 mb-4">
                  Final Words: Go Green, Stay Pest-Free
                </h2>

                <p className="mb-6">
                  Eco-friendly pest control is no longer a luxury—it's a smart, sustainable choice. Whether you live in
                  a flat in Anna Nagar or run a café in T. Nagar, No1 Quality Pest Control provides safe, affordable,
                  and eco-conscious pest control solutions in Chennai.
                </p>

                <div className="bg-light-green/10 p-6 rounded-lg border border-light-green mb-8">
                  <h3 className="text-xl font-semibold text-dark-green mb-4">Ready to Go Green with Pest Control?</h3>
                  <p className="mb-4">Call No1 Quality Pest Control today for:</p>
                  <ul className="list-disc pl-6 mb-4">
                    <li>100% Herbal Treatment</li>
                    <li>Free Inspection & Quote</li>
                    <li>Affordable Packages for Homes & Businesses</li>
                  </ul>
                  <div className="mt-4">
                    <Link
                      href="/contact-us"
                      className="inline-block bg-light-green text-white px-6 py-3 rounded-md font-semibold hover:bg-dark-green transition-colors"
                    >
                      Contact Us Today
                    </Link>
                  </div>
                </div>
              </article>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </>
  )
}
