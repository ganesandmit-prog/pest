import type { Metadata } from "next"
import EcoFriendlyPestControlClient from "./EcoFriendlyPestControlClient"

export const metadata: Metadata = {
  title: "Eco-Friendly Pest Control in Chennai | Safe & Effective Pest Control Services",
  description:
    "Looking for eco-friendly pest control in Chennai? Discover safe, green pest control services for homes and commercial spaces. 100% chemical-free & certified.",
  keywords:
    "Pest control in Chennai, eco-friendly pest control, green pest control Chennai, pest control services, termite control, cockroach control, pest control company Chennai, residential pest control, commercial pest control",
}

export default function EcoFriendlyPestControlPage() {
  return <EcoFriendlyPestControlClient />
}
