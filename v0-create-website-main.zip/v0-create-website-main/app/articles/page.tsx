import type { Metadata } from "next"
import ArticlesClient from "./ArticlesClient"

export const metadata: Metadata = {
  title: "Pest Control Articles & Resources | No.1 Quality Pest Control Chennai",
  description:
    "Read our expert pest control articles about termites, cockroaches, rodents and more. Get tips, advice and information about pest control in Chennai.",
  keywords:
    "pest control articles, pest control blog, pest control tips, pest control Chennai, termite control, cockroach control, rodent control",
}

export default function ArticlesPage() {
  return <ArticlesClient />
}
