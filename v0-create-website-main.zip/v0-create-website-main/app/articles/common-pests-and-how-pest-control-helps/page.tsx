import type { Metadata } from "next"
import CommonPestsAndHowPestControlHelpsClient from "./CommonPestsAndHowPestControlHelpsClient"

export const metadata: Metadata = {
  title: "Common Pests in Chennai and How Pest Control Can Help | No1 Quality Pest Control",
  description:
    "Learn about common pests in Chennai and how professional pest control services can effectively eliminate them. Get expert solutions for termites, cockroaches, and more.",
  keywords:
    "common pests Chennai, pest control Chennai, termite control, cockroach control, rodent control, pest control services, pest control company Chennai",
}

export default function CommonPestsAndHowPestControlHelpsPage() {
  return <CommonPestsAndHowPestControlHelpsClient />
}
