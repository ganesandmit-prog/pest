import type { Metadata } from "next"
import CommonPestsInChennaiClient from "./CommonPestsInChennaiClient"

export const metadata: Metadata = {
  title: "What Are the Common Pests in Chennai and How to Deal with Them | No1 Quality Pest Control",
  description:
    "Learn about the most common pests in Chennai including termites, cockroaches, and rodents. Discover effective pest control treatments and solutions.",
  keywords:
    "common pests in Chennai, pest control Chennai, termite control, cockroach control, rodent control, pest control services, pest control company Chennai",
}

export default function CommonPestsInChennaiPage() {
  return <CommonPestsInChennaiClient />
}
