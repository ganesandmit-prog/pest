import type { Metadata } from "next"
import WhyPestControlIsEssentialClient from "./WhyPestControlIsEssentialClient"

export const metadata: Metadata = {
  title: "Why Pest Control in Chennai is Essential for Your Home and Health | No1 Quality Pest Control",
  description:
    "Protect your home and family from harmful pests like termites, cockroaches, and mosquitoes in Chennai. Discover the health risks and benefits of professional pest control services today.",
  keywords:
    "pest control in Chennai, termite control, mosquito control, cockroach control, eco-friendly pest control, pest control services, pest solutions Chennai, residential pest control Chennai",
}

export default function WhyPestControlIsEssentialPage() {
  return <WhyPestControlIsEssentialClient />
}
