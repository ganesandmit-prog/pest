import type { Metadata } from "next"
import CostOfPestControlClient from "./CostOfPestControlClient"

export const metadata: Metadata = {
  title: "The Cost of Pest Control in Chennai (2025) | Affordable Pest Control Services",
  description:
    "Wondering about the cost of pest control in Chennai? Discover average rates for termite, cockroach & commercial pest control services. Get expert insights & pricing today.",
  keywords:
    "Pest control in Chennai, pest control services, termite control Chennai, cockroach control Chennai, commercial pest control, residential pest control, Chennai pest control rates, pest control company Chennai, pest control offers",
}

export default function CostOfPestControlPage() {
  return <CostOfPestControlClient />
}
