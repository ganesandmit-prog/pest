"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check, Shield, Building, Home, Wrench } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function TermiteControlPage() {
  return (
    <>
      <PageHeader
        title="Best Termite Control Chennai | No.1 Quality Pest Control Chennai"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Hme5V4kzZs85ppxKPD4DM9Wo3gbavC.png"
        subtitle="Protect Your Property with Expert Termite Control Services Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <p className="mb-6">
                  Are termites silently destroying your property? 🐜 Don't wait until it's too late. At No.1 Quality
                  Pest Control, we offer expert termite control services in Chennai designed to eliminate termites from
                  the root and prevent future infestations. Our pest control Chennai solutions are affordable,
                  eco-friendly, and highly effective for both homes and commercial spaces.
                </p>

                <h2 className="text-2xl font-bold mb-4">🏆 Why Choose Our Termite Control Services in Chennai?</h2>
                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Advanced Termite Control Solutions – We use both pre-construction and post-construction
                      anti-termite treatments. Our termite control service Chennai guarantees total protection.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Safe, Eco-Friendly Treatments – Our control services Chennai use non-toxic methods, making it
                      safe for families, kids, and pets.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Complete Termite Elimination – From subterranean termites to drywood and dampwood, we provide
                      pest control services that target all types of termites.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Certified Experts in Termite Control Chennai – Our experienced team uses cutting-edge technology
                      for long-term results and peace of mind.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Affordable Pest Control Chennai – Get high-quality termite control services at the best price in
                      Chennai.
                    </p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">✅ 50,000+ Happy Customers</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now for Termite Control in Chennai</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      💬 WhatsApp: Start Chat
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-DrXuVqr8TseJvL7VFboeuxR2Wx14eu.png"
                  alt="Termite Control Services Chennai - Pest Control Chennai"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🔍 Our 3-Step Termite Control Process in Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">1</span>
                  </div>
                  <h3 className="text-xl font-bold">Termite Inspection & Detection Chennai</h3>
                </div>
                <p className="text-gray-600">
                  We use advanced tools to detect termite infestations and assess damage levels across homes and
                  businesses.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">2</span>
                  </div>
                  <h3 className="text-xl font-bold">Targeted Termite Treatment Chennai</h3>
                </div>
                <p className="text-gray-600">
                  We apply liquid termiticides, baiting systems, and wood-safe treatments to destroy colonies.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">3</span>
                  </div>
                  <h3 className="text-xl font-bold">Preventive Termite Control Measures Chennai</h3>
                </div>
                <p className="text-gray-600">
                  Our pest control service Chennai includes long-lasting soil treatments and barriers to keep termites
                  away permanently.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Locations Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">
              🏠 Where We Offer Termite Control Services in Chennai
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Home className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Residential Termite Control Chennai</h3>
                </div>
                <p className="text-gray-600">
                  Protect your home, wooden furniture, floors, and doors from termites in Chennai with our residential
                  termite control services. Our pest control service Chennai includes comprehensive termite control at
                  affordable price.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Building className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Commercial Termite Control Chennai</h3>
                </div>
                <p className="text-gray-600">
                  Safe & effective termite control solutions for offices, warehouses, and businesses in Chennai. Our
                  commercial pest control includes termite control services at competitive price. Best commercial pest
                  control service Chennai.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Shield className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Pre-Construction Anti-Termite Treatment Chennai</h3>
                </div>
                <p className="text-gray-600">
                  Prevent termite infestations before building construction in Chennai with our pre-construction termite
                  control services. Our control services Chennai include preventive termite treatment at affordable
                  price.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Wrench className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Post-Construction Termite Treatment Chennai</h3>
                </div>
                <p className="text-gray-600">
                  Stop active termite infestations and prevent future termite damage in Chennai properties with our
                  post-construction termite control services. Our pest control service Chennai includes effective
                  termite control solutions.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">📍 Areas We Serve for Termite Control in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We offer control services Chennai across: Adyar, Anna Nagar, T. Nagar, Velachery, Mylapore, Porur,
              Tambaram, OMR, Kodambakkam, and more.
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">🧾 Request a Free Termite Control Quote Chennai</h2>
            <p className="mb-6">
              Fill out our quick form for a free termite pest inspection or schedule a visit. Get affordable pest
              control Chennai packages that suit your needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Call Now for Termite Control Chennai: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Termite Control Quote Chennai
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Termite Control Services Chennai</h2>
          <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
            Fill out the form below to get a free quote for our termite control services in Chennai. We offer the best
            termite control solutions at competitive prices. Our control services Chennai for termite are effective and
            affordable.
          </p>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
