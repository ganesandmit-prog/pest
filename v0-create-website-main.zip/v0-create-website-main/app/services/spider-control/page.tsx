"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check, Shield, Home, Building, AlertTriangle } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function SpiderControlPage() {
  return (
    <>
      <PageHeader
        title="Professional Spider Control in Chennai | No.1 Quality Pest Control"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.26_12072727.jpg-gvvRMZQrmfIKCUKxoaMsC6JuTlq3MM.jpeg"
        subtitle="Safe & Effective Spider Removal Services in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <p className="mb-6">
                  Spiders can be both beneficial and a nuisance when they invade your home or business. At No.1 Quality
                  Pest Control, we provide professional spider control services in Chennai, offering safe, effective,
                  and eco-friendly solutions to eliminate harmful and nuisance spiders from your property.
                </p>

                <h2 className="text-2xl font-bold mb-4">🕸️ Why Choose Our Spider Control Services in Chennai?</h2>
                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✔ Complete Spider Elimination – We remove spiders, webs, and egg sacs from your property.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Safe & Eco-Friendly Methods – Our treatments are safe for families, pets, and the environment.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Preventive Measures – We identify and seal entry points to prevent future spider infestations.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Trained Spider Control Experts – Our team handles both harmless and venomous spiders with
                      expertise.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Affordable & Effective – Get budget-friendly spider control without compromising on quality.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.26_12072727.jpg-gvvRMZQrmfIKCUKxoaMsC6JuTlq3MM.jpeg"
                  alt="Spider Control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🚀 Our 3-Step Spider Control Process</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">1️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Inspection & Identification</h3>
                </div>
                <p className="text-gray-600">
                  We identify spider species, nesting areas, and entry points on your property.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">2️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Treatment & Web Removal</h3>
                </div>
                <p className="text-gray-600">
                  Targeted treatments are applied, and we remove existing webs and egg sacs to ensure long-lasting
                  results.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">3️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Prevention & Exclusion</h3>
                </div>
                <p className="text-gray-600">
                  We seal entry points and provide recommendations to avoid future spider infestations.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Common Spiders Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🕷️ Common Spiders Found in Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Venomous Spiders</h3>
                </div>
                <p className="text-gray-600">
                  Brown Widow, Black Widow, and Wolf Spiders. These spiders require professional removal for safety.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Shield className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Common House Spiders</h3>
                </div>
                <p className="text-gray-600">
                  Daddy Long Legs, Jumping Spiders, and Orb Weavers. These are generally harmless but can be a nuisance.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Locations Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🏠 Where Do We Offer Spider Control in Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Home className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Residential Spider Control</h3>
                </div>
                <p className="text-gray-600">Homes, apartments, gardens, garages, and residential complexes.</p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Building className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Commercial Spider Control</h3>
                </div>
                <p className="text-gray-600">Offices, warehouses, factories, schools, and commercial properties.</p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">📍 Areas We Serve in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We provide spider control services in Adyar, Anna Nagar, T. Nagar, Velachery, Mylapore, Porur, Tambaram,
              OMR, Kodambakkam, and all across Chennai.
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">📞 Get Professional Spider Control in Chennai Today!</h2>
            <p className="mb-6">
              Don't let spiders take over your property! No.1 Quality Pest Control offers safe, effective, and
              affordable spider control solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
