"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check, Shield, Building, Home, Wrench } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function RodentControlPage() {
  return (
    <>
      <PageHeader
        title="Best Rodent Control in Chennai | No.1 Quality Pest Control"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg"
        subtitle="Professional Rat & Mice Control Services in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <p className="mb-6">
                  Looking for effective rodent control in Chennai? Don't let rats and mice invade your space! At No.1
                  Quality Pest Control Chennai, we provide professional rodent control services in Chennai that
                  eliminate rodents safely and efficiently. Our rodent control Chennai services cover homes, offices,
                  warehouses, restaurants, and more — all at affordable price.
                </p>

                <h2 className="text-2xl font-bold mb-4">✅ Why Choose Our Rodent Control Services Chennai?</h2>
                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Expert Rodent Control Chennai – Get rid of rats and mice using advanced trapping, baiting, and
                      rodent exclusion techniques.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Safe & Humane Methods – Our rodent control solutions in Chennai are eco-friendly, non-toxic, and
                      safe for kids and pets.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Certified Pest Control Experts Chennai – Our trained professionals follow modern pest control
                      techniques for long-lasting rodent removal.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Affordable Rodent Services Chennai – We offer the best price rodent pest control without
                      compromising on quality.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      ✔ Prevention-Focused Rodent Control Chennai – We seal entry points and provide preventive
                      recommendations to avoid future infestations.
                    </p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">👉 Trusted by Over 50,000+ Customers Across Chennai!</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg"
                  alt="Rodent Control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🐭 Our 3-Step Rodent Pest Control Process Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">1️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Inspection & Assessment</h3>
                </div>
                <p className="text-gray-600">
                  We inspect your home or business to identify rodent entry points, nests, and activity zones.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">2️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Elimination & Treatment</h3>
                </div>
                <p className="text-gray-600">
                  Using traps, bait stations, and safe rodenticides, we eliminate all rodent presence effectively.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">3️⃣</span>
                  </div>
                  <h3 className="text-xl font-bold">Prevention & Exclusion</h3>
                </div>
                <p className="text-gray-600">
                  We block access points and offer long-term preventive solutions to keep your property rodent-free.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Locations Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">
              🏠 Rodent Control Services in Chennai – Where We Serve
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Home className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Residential Rodent Control</h3>
                </div>
                <p className="text-gray-600">Protect your home, kitchen, attic, and basement from rats and mice.</p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Building className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Commercial Rodent Control</h3>
                </div>
                <p className="text-gray-600">
                  Safe & effective solutions for restaurants, warehouses, offices, and retail stores.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Shield className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Emergency Rodent Control</h3>
                </div>
                <p className="text-gray-600">Quick response for urgent rodent problems in homes and businesses.</p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Wrench className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold">Preventive Rodent Control</h3>
                </div>
                <p className="text-gray-600">Regular maintenance to keep your property rodent-free year-round.</p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">📍 Rodent Control Service Areas in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We provide rodent pest control in: Adyar, Anna Nagar, T. Nagar, Velachery, Mylapore, Porur, Tambaram, OMR,
              Kodambakkam, and all areas of Chennai.
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">📞 Contact the Best Rodent Control Experts Chennai</h2>
            <p className="mb-6">
              Don't let rats and mice take over your home or office! Choose No.1 Quality Pest Control Chennai for
              affordable, effective, and trusted rodent control services in Chennai.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
