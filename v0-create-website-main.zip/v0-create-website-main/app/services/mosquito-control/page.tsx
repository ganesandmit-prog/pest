"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check, Shield, Zap, Clock, ThumbsUp, Leaf } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function MosquitoControlPage() {
  return (
    <>
      <PageHeader
        title="Mosquito Control in Chennai – Safe & Effective Pest Solutions"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpLHKJ.jpeg"
        subtitle="Protect Your Home & Business from Dengue, Malaria & Other Mosquito-Borne Diseases"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <p className="mb-6">
                  No.1 Quality Pest Control Chennai provides professional mosquito control services Chennai for homes,
                  offices, and commercial spaces. Our eco-friendly pest control services Chennai are designed to
                  eliminate mosquitoes using safe, long-lasting methods. We help protect families and businesses from
                  mosquito-borne diseases like dengue, malaria, and chikungunya.
                </p>

                <h2 className="text-2xl font-bold mb-4">Why You Need Professional Mosquito Control in Chennai</h2>
                <p className="mb-6">
                  Chennai's tropical climate and water stagnation create a perfect environment for mosquitoes to breed.
                  While DIY mosquito repellents offer temporary relief, our expert mosquito control service Chennai
                  ensures long-lasting protection using advanced mosquito pest control techniques.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✅ Dengue & Malaria Prevention – Stops mosquito breeding and destroys larvae.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✅ Eco-Friendly Mosquito Treatment – Child-safe, pet-safe, and environment-friendly.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✅ Advanced Fogging & Spraying – Targets adult mosquitoes and breeding areas.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✅ Long-Term Pest Control – Prevents re-infestation using smart techniques.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>✅ Affordable Price – Best pest control Chennai at competitive rates.</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp Now for mosquito control service Chennai
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpHKJ.jpeg"
                  alt="Mosquito Control Services Chennai - Professional Pest Control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Mosquito Control Services Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Zap className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">1. Mosquito Fogging Services</h3>
                </div>
                <p className="text-gray-600">
                  We use thermal fogging with eco-safe insecticides to eliminate adult mosquitoes from residential,
                  commercial, and industrial properties. Ideal for homes, schools, hospitals, and offices.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Shield className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">2. Larvicidal Treatment</h3>
                </div>
                <p className="text-gray-600">
                  Our larvicidal treatment Chennai destroys mosquito larvae in water tanks, drains, and garbage areas.
                  This control service ensures long-term results.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <ThumbsUp className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">3. Outdoor Mosquito Control</h3>
                </div>
                <p className="text-gray-600">
                  Protect your balcony, terrace, garden, and lawns from mosquito breeding. We offer repellents, fogging,
                  and mesh installation to prevent outdoor infestation.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Clock className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">4. Indoor Residual Spraying</h3>
                </div>
                <p className="text-gray-600">
                  We apply WHO-approved residual sprays inside your home or office — on ceilings, corners, and walls —
                  to provide long-lasting indoor mosquito control.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.5}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Leaf className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">5. Biological Mosquito Control</h3>
                </div>
                <p className="text-gray-600">
                  For eco-lovers, we use natural predators, organic repellents, and green pest control Chennai methods
                  to safely reduce mosquito populations.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.6}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3">
                    <Shield className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-bold">6. Mosquito Net Installation</h3>
                </div>
                <p className="text-gray-600">
                  We install high-quality mosquito-proof mesh on doors and windows for long-term physical protection
                  from mosquito entry.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Us for Mosquito Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "Best Mosquito Control Services Chennai",
                description: "100% satisfaction guaranteed",
              },
              {
                title: "Certified Pest Control Experts",
                description: "Trained and experienced professionals",
              },
              {
                title: "Advanced Pest Control Methods",
                description: "Smart, safe & reliable",
              },
              {
                title: "Non-Toxic & Pet-Friendly Treatment",
                description: "Safe for kids and pets",
              },
              {
                title: "Affordable Price",
                description: "Value-for-money mosquito control services Chennai",
              },
              {
                title: "24/7 Mosquito Pest Control Chennai",
                description: "Emergency same-day service",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">✔️ {item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">Areas We Serve in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We provide professional mosquito control services across North Chennai, South Chennai, West Chennai, and
              OMR/ECR. Our pest control services Chennai cover popular locations including:
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <div className="bg-white p-6 rounded-lg shadow-md max-w-4xl mx-auto">
              <div className="flex flex-wrap justify-center gap-x-4 gap-y-3">
                {[
                  "Adyar",
                  "Anna Nagar",
                  "T. Nagar",
                  "Velachery",
                  "Mylapore",
                  "Porur",
                  "Tambaram",
                  "OMR",
                  "Kodambakkam",
                  "Ashok Nagar",
                  "Avadi",
                  "K.K. Nagar",
                  "Koyambedu",
                  "Guindy",
                  "Medavakkam",
                  "Pallavaram",
                  "Sholinganallur",
                  "Thiruvanmiyur",
                  "& More!",
                ].map((area, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <span className="text-light-green mr-1">📍</span>
                    <span>{area} Pest Control</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Book Mosquito Control Services Chennai Today!</h2>
            <p className="mb-6">
              Ensure your home and office are mosquito-free with our expert mosquito control services!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now for Pest Control Services Chennai: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Pest Control Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
