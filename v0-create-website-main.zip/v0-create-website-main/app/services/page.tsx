"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection, StaggeredContainer } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function ServicesPage() {
  const services = [
    {
      title: "Mosquito Control Services Chennai",
      description:
        "Eliminate mosquito-borne diseases with our control services Chennai. We offer safe and affordable pest control solutions for complete mosquito removal.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzopu2w4caDDze0eTucWBnPgk5eQde.png",
      slug: "mosquito-control",
    },
    {
      title: "Cockroaches Control Services Chennai",
      description:
        "Get rid of cockroaches fast with our advanced cockroach control service Chennai. Our effective treatment ensures hygiene and health for your family.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-L5hASvrQm1wqMDdVr0v2zJqJoLHITk.png",
      slug: "cockroach-control",
    },
    {
      title: "Bed Bug Treatment Services Chennai",
      description:
        "Our specialized pest control Chennai treatments eliminate bed bugs permanently. Sleep peacefully with our trusted control services in Chennai.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pg04NtTuPrvAmJ2pJF7TGw0BOgdcGC.png",
      slug: "bed-bug-control",
    },
    {
      title: "Termite Control Services Chennai",
      description:
        "Protect your furniture and property with expert termite control Chennai. We use the latest technology for safe and long-lasting results.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-waanzPZrDnVZ2Xjkstuv5im8xH3oOi.png",
      slug: "termite-control",
    },
    {
      title: "Rodent Control Services Chennai",
      description:
        "Keep rats and mice away with our powerful rodent control service Chennai. Best control service Chennai for residential and commercial spaces.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg",
      slug: "rodent-control",
    },
    {
      title: "Snake Control Services Chennai",
      description:
        "Need emergency snake removal? Our control services Chennai include safe, humane snake control for homes and businesses.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.07_95330c8b.jpg-B10Tm1BVj30SHkr83wW0gOaEAebAXw.jpeg",
      slug: "snake-control",
    },
    {
      title: "Spider Control Services Chennai",
      description:
        "Say goodbye to spider webs with our expert spider control Chennai treatments. Clean and safe environment with our pest control services Chennai.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VhEzIq24sp1W9R6w5zc3sSHRLynXuk.png",
      slug: "spider-control",
    },
    {
      title: "Fly Control Services Chennai",
      description:
        "Remove houseflies and fruit flies with our top-rated fly control services Chennai. Trusted pest control service Chennai for homes and industries.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.44_705f83cb.jpg-6KTtzvkByZQZIMhRkvZ5JUH2dXEsGa.jpeg",
      slug: "fly-control",
    },
    {
      title: "Commercial Pest Control Services Chennai",
      description:
        "Comprehensive commercial pest control Chennai for restaurants, hotels, offices, and warehouses. Best price and guaranteed protection.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.58_2e4e345f.jpg-lwb7nh9Iv04pJrAxIyHJa8J3a55yYD.jpeg",
      slug: "commercial-pest-control",
    },
  ]

  return (
    <>
      <PageHeader
        title="Pest Control Services Chennai – No.1 Pest Control Chennai"
        backgroundImage="https://images.unsplash.com/photo-1605146768851-eda79da39897"
        subtitle="Safe, Effective & Affordable Pest Control Services Chennai for Homes & Commercial Pest Control"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              Looking for reliable pest control services in Chennai? At No.1 Quality Pest Control Chennai, we deliver
              expert termite control, cockroaches control, and commercial pest control services at the best price. Our
              certified team ensures safe, eco-friendly, and long-lasting pest control treatments for homes, offices,
              and industries across Chennai.
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <h2 className="text-3xl font-bold mb-8 text-center">Our Pest Control Services Chennai</h2>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <Link key={service.slug} href={`/services/${service.slug}`}>
                  <motion.div className="bg-white rounded-lg overflow-hidden shadow-md h-full" whileHover={{ y: -10 }}>
                    <div className="relative h-48">
                      <Image
                        src={service.image || "/placeholder.svg"}
                        alt={service.title + " - Pest Control Chennai"}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                        <div className="p-4">
                          <h3 className="text-xl font-bold text-white flex items-center">{service.title}</h3>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <p className="text-gray-600 mb-4">{service.description}</p>
                      <div className="text-light-green font-medium">View Details →</div>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </StaggeredContainer>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Quality Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "45+ Years of Experience in pest control Chennai",
                description: "Certified & Trained Experts for termite control and cockroaches control.",
              },
              {
                title: "Advanced Techniques & Eco-Friendly Solutions",
                description: "Latest pest control techniques for termite control, cockroaches control and all pests.",
              },
              {
                title: "Custom Solutions for Residential & Commercial Pest Control",
                description: "Tailored pest control solutions for homes and commercial pest control in Chennai.",
              },
              {
                title: "Affordable Pest Control Price in Chennai",
                description:
                  "Best pest control price in Chennai with guaranteed results for all pest control services.",
              },
              {
                title: "24x7 Pest Control Services Chennai",
                description: "Emergency pest control service available across Chennai for urgent pest problems.",
              },
              {
                title: "100% Customer Satisfaction Guaranteed",
                description: "Complete pest control services Chennai for all types of pests at competitive price.",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold">{item.title}</h3>
                      <p className="text-gray-600 mt-2">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">24x7 Pest Control Services Chennai – Call Now!</h2>
            <p className="mb-6">
              We offer emergency pest control service Chennai with fast response times and expert treatments. Whether
              it's termite control, cockroaches control, or any other pest, we've got you covered.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Call Now for Pest Control Service Chennai: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Pest Control Quote Chennai
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Get a Free Quote – Pest Control Services Chennai</h2>
          <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
            Fill out the form to get a free quote for pest control services Chennai. We offer termite control,
            cockroaches control, and commercial pest control at the best price.
          </p>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
