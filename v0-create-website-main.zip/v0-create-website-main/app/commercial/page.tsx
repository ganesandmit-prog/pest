"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import TestimonialCard from "@/components/testimonial-card"
import ContactForm from "@/components/contact-form"

export default function CommercialPage() {
  return (
    <>
      <PageHeader
        title="Commercial Pest Control Services in Chennai"
        backgroundImage="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab"
        subtitle="🚀 Protect Your Business with Expert Pest Control Solutions!"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <p className="mb-6">
                  At No.1 Quality Pest Control Chennai, we provide reliable, discreet, and effective commercial pest
                  control services tailored to protect businesses from unwanted pests. With 45+ years of experience, we
                  understand the unique pest challenges faced by restaurants, hotels, offices, warehouses, hospitals,
                  retail stores, and industrial spaces in Chennai.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <motion.a
                    href="tel:+917558108600"
                    className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <span>📞 Call Us Now: +91 7558108600</span>
                  </motion.a>
                  <motion.a
                    href="https://wa.me/917558108600"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-green-500 text-white px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <span>📲 WhatsApp Us</span>
                  </motion.a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png"
                  alt="Commercial pest control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Quality Pest Control?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                title: "45+ Years of Expertise",
                description: "Trusted by businesses across Chennai.",
              },
              {
                title: "Safe & Effective Treatments",
                description: "Eco-friendly & industry-approved solutions.",
              },
              {
                title: "Customized Pest Management",
                description: "Tailored plans for every business type.",
              },
              {
                title: "Compliant with Industry Standards",
                description: "Helps meet health & safety regulations.",
              },
              {
                title: "Emergency Pest Control",
                description: "Quick response for urgent pest issues.",
              },
              {
                title: "Affordable & Discreet Services",
                description: "Professional, efficient, and budget-friendly.",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.5}>
            <div className="text-center mt-8">
              <p className="mb-4 font-medium">
                📍 We serve businesses in: Adyar | Anna Nagar | T. Nagar | OMR | Guindy | Tambaram | Perungudi |
                Velachery | & More!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.a
                  href="tel:+917558108600"
                  className="btn-dark"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  📞 Call Now: +91 7558108600
                </motion.a>
                <Link href="/contact-us">
                  <motion.button className="btn-outline" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    📩 Get a Free Consultation
                  </motion.button>
                </Link>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Commercial Pest Control Services</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                title: "Hotels & Restaurants",
                description: "Maintain a clean, pest-free environment & protect your reputation.",
              },
              {
                title: "Offices & Corporate Spaces",
                description: "Ensure a hygienic, pest-free workspace.",
              },
              {
                title: "Hospitals & Clinics",
                description: "Compliant, safe pest control for healthcare facilities.",
              },
              {
                title: "Warehouses & Factories",
                description: "Prevent pest infestations from damaging goods.",
              },
              {
                title: "Retail Stores & Shopping Malls",
                description: "Protect your business & customers.",
              },
              {
                title: "Educational Institutions",
                description: "Safe pest control for schools & colleges.",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div>
                    <h3 className="text-xl font-bold mb-2">🔹 {item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.5}>
            <div className="text-center mt-8">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="text-xl mr-2">💡</span>
                <span className="font-medium">Looking for customized pest control for your business?</span>
                <a href="tel:+917558108600" className="ml-2 font-bold hover:underline">
                  📞 Call Now: +91 7558108600
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Approach Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Pest Control Approach</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                title: "Comprehensive Inspection",
                description: "Identify entry points & pest hotspots.",
              },
              {
                title: "Industry-Specific Treatment Plans",
                description: "Tailored pest control strategies.",
              },
              {
                title: "Preventative Measures",
                description: "Long-term pest control to avoid future infestations.",
              },
              {
                title: "Regular Monitoring & Maintenance",
                description: "Scheduled visits for ongoing protection.",
              },
              {
                title: "Emergency Pest Control",
                description: "Quick action for urgent pest infestations.",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">✅ {item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.5}>
            <div className="text-center mt-8">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="text-xl mr-2">💡</span>
                <span className="font-medium">Ensure a pest-free business environment!</span>
                <a href="tel:+917558108600" className="ml-2 font-bold hover:underline">
                  📞 Call Us Now: +91 7558108600
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">What Our Business Clients Say</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <TestimonialCard
                quote="Excellent pest control for our restaurant. Quick & effective service!"
                author="Ramesh K., Restaurant Owner, T. Nagar"
                rating={5}
              />
            </AnimatedSection>
            <AnimatedSection animation="slideUp" delay={0.2}>
              <TestimonialCard
                quote="Professional & reliable pest control for our hotel. Highly recommended!"
                author="Shruti B., Hotel Manager, OMR"
                rating={5}
              />
            </AnimatedSection>
            <AnimatedSection animation="slideUp" delay={0.3}>
              <TestimonialCard
                quote="Great service for our warehouse. No more rodent issues!"
                author="Vignesh R., Warehouse Owner, Guindy"
                rating={5}
              />
            </AnimatedSection>
          </div>

          <AnimatedSection animation="fadeIn" delay={0.4}>
            <div className="text-center mt-8">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/reviews">
                  <motion.button
                    className="flex items-center justify-center gap-2 bg-gray-200 text-gray-800 px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <span>💡 Check More Reviews</span>
                  </motion.button>
                </Link>
                <motion.a
                  href="tel:+917558108600"
                  className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>📞 Call Now: +91 7558108600</span>
                </motion.a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Contact No.1 Quality Pest Control Chennai Today!</h2>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.a
                  href="tel:+917558108600"
                  className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>📞 Call Us: +91 7558108600</span>
                </motion.a>
                <motion.a
                  href="https://wa.me/917558108600"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-green-500 text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>📲 WhatsApp: Click Here to Chat</span>
                </motion.a>
                <motion.div className="flex items-center justify-center gap-2 bg-gray-200 text-gray-800 px-6 py-3 rounded-md">
                  <span>📍 Location: Chennai, Tamil Nadu</span>
                </motion.div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.3}>
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="text-xl mr-2">💡</span>
                <span className="font-medium">Get a Free Inspection & Quote for Your Business!</span>
              </div>
            </div>
          </AnimatedSection>

          <div className="max-w-4xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  )
}
