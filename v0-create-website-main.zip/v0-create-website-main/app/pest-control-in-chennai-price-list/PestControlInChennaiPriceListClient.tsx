"use client"

import { useEffect } from "react"
import PageHeader from "@/components/page-header"
import CTA from "@/components/cta"
import Link from "next/link"
import { Phone, Check } from "lucide-react"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export default function PestControlInChennaiPriceListClient() {
  // Add schema markup for better SEO
  useEffect(() => {
    const script = document.createElement("script")
    script.type = "application/ld+json"
    script.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "PriceSpecification",
      name: "No.1 Quality Pest Control Price List",
      url: "https://www.no1qualitypestcontrol.com/pest-control-in-chennai-price-list",
      description: "Transparent pricing for all pest control services in Chennai.",
      priceCurrency: "INR",
      price: "999",
      validFrom: "2024-01-01",
      validThrough: "2024-12-31",
      eligibleRegion: {
        "@type": "GeoCircle",
        geoMidpoint: {
          "@type": "GeoCoordinates",
          latitude: "13.0827",
          longitude: "80.2707",
        },
        geoRadius: "50",
      },
      provider: {
        "@type": "PestControlService",
        name: "No.1 Quality Pest Control",
        telephone: "+91-9876543210",
        address: {
          "@type": "PostalAddress",
          streetAddress: "123 Main Street",
          addressLocality: "Chennai",
          addressRegion: "Tamil Nadu",
          postalCode: "600001",
          addressCountry: "IN",
        },
      },
    })
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  return (
    <>
      <PageHeader title="Pest Control Price List Chennai 2024" subtitle="Affordable & Verified Rates for 2024" />

      <main className="min-h-screen">
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl md:text-4xl font-bold text-dark-green mb-6">
                  Pest Control in Chennai – Price List 2024 [Affordable & Verified Rates]
                </h1>

                <p className="text-lg mb-6">
                  Looking for affordable pest control services in Chennai? Whether it's cockroach control, mosquito
                  treatment, termite protection, or bug removal, our expert pest control team offers safe, eco-friendly,
                  and budget-friendly solutions with guaranteed results.
                </p>

                <p className="text-lg mb-8">
                  We've listed our transparent pest control charges below for every home type – from 1BHK to 5BHK – so
                  you know exactly what to expect.
                </p>

                <h2 className="text-2xl font-bold text-dark-green mb-6">🏠 Pest Control Price List in Chennai</h2>

                <div className="overflow-x-auto mb-8">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-dark-green text-white">
                        <th className="border border-gray-300 px-4 py-3 text-left">Service</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">1BHK</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">2BHK</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">3BHK</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">4BHK</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">5BHK</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Mosquito Control</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹800</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1100</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1400</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1700</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1800</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Cockroach Control</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹800</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1100</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1300</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1700</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1800</td>
                      </tr>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Termite Control</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹2900</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4400</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4900</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹5900</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹5999</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Bug Treatment</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1500</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1800</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹2200</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹2700</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹2799</td>
                      </tr>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Rodent Control</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹800</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹900</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1000</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1100</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹1199</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Termite Piping Control</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4000</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹5500</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹6000</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹7000</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹7099</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="flex flex-col md:flex-row gap-4 mb-8">
                  <div className="flex-1 bg-light-green/10 p-4 rounded-lg flex items-center">
                    <Check className="h-6 w-6 text-light-green mr-2 flex-shrink-0" />
                    <span>No hidden charges</span>
                  </div>
                  <div className="flex-1 bg-light-green/10 p-4 rounded-lg flex items-center">
                    <Check className="h-6 w-6 text-light-green mr-2 flex-shrink-0" />
                    <span>Herbal & Odourless Options Available</span>
                  </div>
                  <div className="flex-1 bg-light-green/10 p-4 rounded-lg flex items-center">
                    <Check className="h-6 w-6 text-light-green mr-2 flex-shrink-0" />
                    <span>100% Safe for Kids & Pets</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h2 className="text-xl font-bold text-dark-green mb-4">
                    🔍 Why We Rank #1 for "Pest Control Chennai" Searches?
                  </h2>
                  <p className="mb-4">We use all the key search terms people are typing on Google:</p>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-1">One Word:</h3>
                      <p className="text-gray-700">
                        control, chennai, services, price, charges, termite, cockroach, india
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-1">Two Words:</h3>
                      <p className="text-gray-700">
                        pest control, control services, price list, services chennai, pest control charges, termite
                        control
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-1">Three Words:</h3>
                      <p className="text-gray-700">
                        pest control services, pest control service, pest control chennai, suguna pest control
                      </p>
                    </div>
                  </div>

                  <p className="mt-4 text-gray-700">
                    This ensures our website always shows up on the top of Google when you search for pest control in
                    Chennai price list.
                  </p>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  📞 Get in Touch with No.1 Quality Pest Control Today!
                </h2>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-start mb-3">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-3 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <div>
                        <p className="font-semibold">Location:</p>
                        <p>Otteri, Chennai</p>
                      </div>
                    </div>

                    <div className="flex items-start mb-3">
                      <Phone className="h-6 w-6 text-light-green mr-3 mt-0.5" />
                      <div>
                        <p className="font-semibold">Call:</p>
                        <p>+91 75581 08600</p>
                      </div>
                    </div>

                    <div className="flex items-start mb-3">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-3 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      <div>
                        <p className="font-semibold">Email:</p>
                        <p>no1qualitypestcontrol@gmail.com</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-3 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                        />
                      </svg>
                      <div>
                        <p className="font-semibold">Website:</p>
                        <p>https://www.no1qualitypestcontrol.com</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                      <p className="font-semibold">Available 24/7</p>
                    </div>

                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                        />
                      </svg>
                      <p className="font-semibold">Home & Office</p>
                    </div>

                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
                        />
                      </svg>
                      <p className="font-semibold">ISO Certified</p>
                    </div>

                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                        />
                      </svg>
                      <p className="font-semibold">Experienced Team</p>
                    </div>
                  </div>
                </div>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold text-dark-green mb-4">Book Now for a pest-free home in Chennai</h3>
                  <p className="mb-4">
                    Say goodbye to cockroaches, termites, mosquitoes, and bugs – at the most affordable prices in
                    Chennai!
                  </p>
                  <div className="flex justify-center">
                    <Link
                      href="/contact-us"
                      className="bg-light-green hover:bg-dark-green text-white font-bold py-3 px-6 rounded-lg transition-colors"
                    >
                      Book Now
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <CTA />

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center text-dark-green mb-8">
              Contact Us For Professional Pest Control
            </h2>
            <div className="max-w-3xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}
