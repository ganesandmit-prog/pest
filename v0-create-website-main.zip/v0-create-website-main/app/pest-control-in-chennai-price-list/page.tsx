import type { Metadata } from "next"
import PestControlInChennaiPriceListClient from "./PestControlInChennaiPriceListClient"

export const metadata: Metadata = {
  title: "Pest Control Price List Chennai 2024 | No.1 Quality Pest Control",
  description:
    "View our transparent pest control price list for Chennai. No.1 Quality Pest Control offers affordable rates for all pest control services including cockroach, termite, bed bug, and rodent treatments. Get detailed pricing for residential and commercial properties.",
  keywords:
    "pest control price, pest control cost Chennai, pest control charges, affordable pest control Chennai, pest control price list, termite control cost, cockroach control price, bed bug treatment cost, rodent control charges, pest control service rates Chennai",
  alternates: {
    canonical: "https://www.no1qualitypestcontrol.com/pest-control-in-chennai-price-list",
  },
}

export default function PestControlInChennaiPriceListPage() {
  return <PestControlInChennaiPriceListClient />
}
