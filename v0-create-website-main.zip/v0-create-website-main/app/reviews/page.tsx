"use client"

import PageHeader from "@/components/page-header"
import { AnimatedSection, StaggeredContainer } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Star, MapPin, Check } from "lucide-react"
import ContactForm from "@/components/contact-form"
import Link from "next/link"

export default function ReviewsPage() {
  const testimonials = [
    {
      quote: "Best Pest Control Service in Chennai!",
      author: "Ramesh S.",
      location: "Anna Nagar, Chennai",
      rating: 5,
      fullText:
        "I had a severe cockroach problem in my apartment. The team from No.1 Quality Pest Control Chennai arrived on time, explained everything clearly, and treated the space thoroughly. Within hours, it was pest-free. Absolutely the best cockroaches control Chennai!",
    },
    {
      quote: "Prompt and Professional Termite Control",
      author: "Suresh K.",
      location: "T. Nagar, Chennai",
      rating: 5,
      fullText:
        "Our wooden furniture was under attack by termites. I reached out for termite control Chennai and was impressed by the quick inspection and eco-friendly treatment. Excellent results and no mess left behind!",
    },
    {
      quote: "Highly Skilled Pest Control Experts",
      author: "Kousik R.",
      location: "Velachery, Chennai",
      rating: 5,
      fullText:
        "The team was very friendly, answered all my questions, and shared great pest prevention tips. Their expertise and dedication make them the top pest control services Chennai provider.",
    },
    {
      quote: "Affordable Bed Bug Control Services",
      author: "Raja K.",
      location: "Adyar, Chennai",
      rating: 5,
      fullText:
        "We had a bed bug infestation and were so worried. Thankfully, the team conducted a thorough inspection and complete treatment. Their bed bug control Chennai package was effective and affordable.",
    },
    {
      quote: "Reliable Commercial Pest Control for My Restaurant",
      author: "Palaniappan S.",
      location: "OMR, Chennai",
      rating: 5,
      fullText:
        "As a restaurant owner, I cannot afford pest problems. No.1 Quality Pest Control has been handling our monthly commercial pest control Chennai needs. We haven't had a single issue in over a year. Truly reliable!",
    },
    {
      quote: "Top-Notch Rodent Control in Chennai",
      author: "Sundaram V.",
      location: "Perungudi, Chennai",
      rating: 5,
      fullText:
        "Our warehouse had a rodent issue. The team delivered quick and effective rodent control Chennai service. No.1 Quality Pest Control is the best pest control company in Chennai without a doubt!",
    },
  ]

  return (
    <>
      <PageHeader
        title="Customer Testimonials – Why Chennai Trusts No.1 Quality Pest Control"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Real Reviews from Satisfied Homeowners & Businesses"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              At No.1 Quality Pest Control Chennai, we've been proudly serving homes and businesses for over 45 years
              with top-rated pest control services Chennai. From termite control to cockroaches control, our clients
              trust us for fast, safe, and affordable pest control solutions. Read what our customers are saying about
              the best pest control company in Chennai!
            </p>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  className="bg-dark-brown text-white p-6 rounded-lg shadow-lg"
                  whileHover={{ y: -5 }}
                >
                  <div className="flex mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <h3 className="text-xl font-bold mb-4">⭐⭐⭐⭐⭐ "{testimonial.quote}"</h3>
                  <div className="flex items-center mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">📍 Location: {testimonial.location}</span>
                  </div>
                  <p className="mb-4">"{testimonial.fullText}"</p>
                  <p className="font-bold">{testimonial.author}</p>
                </motion.div>
              ))}
            </div>
          </StaggeredContainer>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Quality Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "45+ Years of Experience",
                description: "Trusted by thousands across Chennai",
              },
              {
                title: "Certified Pest Control Experts",
                description: "Government-approved and well-trained",
              },
              {
                title: "Eco-Friendly & Safe Solutions",
                description: "Family and pet-safe treatments",
              },
              {
                title: "Affordable Pest Control Price Chennai",
                description: "Quality at the best rates",
              },
              {
                title: "Guaranteed Results",
                description: "Long-term pest prevention",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">📞 Book the Best Pest Control Services in Chennai</h2>
            <p className="mb-6">
              Ready for a pest-free home or business? Contact No.1 Quality Pest Control Chennai for expert services
              including termite control, cockroaches control, rodent control, and commercial pest control.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
