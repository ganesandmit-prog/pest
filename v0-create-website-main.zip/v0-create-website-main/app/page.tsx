"use client"

import HeroSlider from "@/components/hero-slider"
import QuickLinks from "@/components/quick-links"
import ContactForm from "@/components/contact-form"
import FloatingActionButton from "@/components/floating-action-button"
import PriceListSlider from "@/components/price-list-slider"
import { AnimatedSection } from "@/components/framer-animations"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Check, ClipboardList, Shield, RefreshCw } from "lucide-react"

export default function Home() {
  return (
    <>
      {/* Hero Section with Slider */}
      <HeroSlider />

      {/* Floating Action Button */}
      <FloatingActionButton />

      {/* Quick Links */}
      <QuickLinks />

      {/* About Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <motion.h1
                  className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                >
                  No.1 Quality Pest Control Chennai
                </motion.h1>
                <motion.h2
                  className="text-3xl md:text-4xl font-bold mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                >
                  Best Pest Control Services Chennai
                </motion.h2>
                <p className="mb-4">
                  Looking for the best pest control in Chennai? Say goodbye to pests with No.1 Quality Pest Control
                  Chennai, the leading name in pest control services Chennai. We provide safe, affordable, and effective
                  control services for residential, commercial, and industrial properties. Whether it's termite control,
                  cockroaches control, or rodent removal, our licensed experts deliver long-lasting results at the best
                  pest control price Chennai.
                </p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Trusted by Thousands of Customers for Pest Control Services Chennai</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Government-Certified & Licensed Pest Control Experts in Chennai</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>
                      Advanced Treatment for Termite Control Chennai, Cockroaches Control Chennai, Bed Bugs, Rodents &
                      More Pests
                    </p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call for Pest Control Service Chennai: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp for Pest Control Chennai
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png"
                  alt="Pest control professional in Chennai providing pest control services Chennai"
                  fill
                  className="object-cover"
                  loading="eager"
                  priority
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Rodent Control Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">🐀 Stop Rodents from Invading Your Space!</h2>
              <p className="text-lg">
                Rodents not only damage property but also spread dangerous diseases. Our rodent control service Chennai
                uses eco-friendly and efficient methods to eliminate rats and mice from your home or office.
              </p>
              <div className="mt-6">
                <a href="tel:+917558108600" className="btn-dark inline-block mr-4">
                  📞 Call Now for Fast & Reliable Rodent Control Chennai
                </a>
                <a
                  href="https://wa.me/917558108600"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary inline-block"
                >
                  📲 WhatsApp Us for Rodent Control Chennai
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Commercial Pest Control Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">💼 Trusted Commercial Pest Control Chennai</h2>
              <p className="text-lg text-center mb-8">Our commercial pest control services Chennai are tailored for:</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {["Restaurants", "Hotels", "Offices", "Warehouses", "Industrial Buildings"].map((item, index) => (
                  <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                    <div className="bg-white p-6 rounded-lg shadow-md text-center">
                      <h3 className="text-xl font-bold">{item}</h3>
                    </div>
                  </AnimatedSection>
                ))}
              </div>

              <p className="text-center mb-6">
                With 45+ years of experience, we provide certified commercial pest control that meets health and safety
                standards. Protect your business today with the best commercial pest control Chennai at a competitive
                price.
              </p>

              <div className="text-center">
                <Link href="/commercial">
                  <motion.button className="btn-dark" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    Learn More About Commercial Pest Control Chennai
                  </motion.button>
                </Link>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Residential Pest Control Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">
                🏠 Residential Pest Control Chennai – Get a Pest-Free Home Today!
              </h2>
              <p className="text-lg text-center mb-8">
                We offer customized residential pest control Chennai for apartments, villas, and houses. Our control
                service Chennai targets all household pests using modern pest control techniques and safe solutions.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {[
                  { title: "📍 Free Home Inspection", desc: "Comprehensive assessment of your pest problems" },
                  { title: "📍 Affordable Control Price Chennai", desc: "Budget-friendly pest control solutions" },
                  {
                    title: "📍 100% Safe for Children & Pets",
                    desc: "Eco-friendly treatments that protect your family",
                  },
                ].map((item, index) => (
                  <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                    <div className="bg-white p-6 rounded-lg shadow-md h-full">
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p>{item.desc}</p>
                    </div>
                  </AnimatedSection>
                ))}
              </div>

              <div className="text-center">
                <Link href="/residential">
                  <motion.button className="btn-dark" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    Learn More About Residential Pest Control Chennai
                  </motion.button>
                </Link>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Our Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🕷️ Our Pest Control Services Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.43_3e74b5d1.jpg-t1L0fJeq733tXCHCZv4Th2U1zpLHKJ.jpeg"
                    alt="Mosquito Control Services Chennai - Pest Control Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Mosquito Control Chennai</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Protect your loved ones from dengue & malaria with our effective mosquito control services Chennai.
                </p>
                <Link href="/services/mosquito-control">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.45.59_ca633715.jpg-KwzRWzbglYoAXHoH4Ck0S8RZPv7NxQ.jpeg"
                    alt="Cockroaches Control Services Chennai - Pest Control Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Cockroaches Control Chennai</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Remove stubborn cockroaches from your kitchen & bathrooms with our advanced cockroaches control
                  Chennai treatment.
                </p>
                <Link href="/services/cockroach-control">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.16_5f166834.jpg-pUBa1DBY77fvkQrjSW3TNhOlnIZmau.jpeg"
                    alt="Bed Bug Treatment Services Chennai - Pest Control Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Bed Bug Control Chennai</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Say goodbye to sleepless nights with our guaranteed bed bug treatment services Chennai.
                </p>
                <Link href="/services/bed-bug-control">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.58_2e4e345f.jpg-lwb7nh9Iv04pJrAxIyHJa8J3a55yYD.jpeg"
                    alt="Termite Control Services Chennai - Pest Control Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Termite Control Chennai</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Prevent damage to your furniture with our powerful termite control Chennai techniques.
                </p>
                <Link href="/services/termite-control">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.5}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.46.42_85785ce1.jpg-hVsztl4vs93HHWGRbJDfA6OKAiYBaL.jpeg"
                    alt="Rodent Control Services Chennai - Pest Control Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Rodent Control Chennai</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Protect your space from rats & mice with our proven rodent control Chennai solutions.
                </p>
                <Link href="/services/rodent-control">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.6}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="relative h-48 mb-4 overflow-hidden rounded-md">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-29%20at%2011.47.07_95330c8b.jpg-B10Tm1BVj30SHkr83wW0gOaEAebAXw.jpeg"
                    alt="Commercial Pest Control Services Chennai"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <h3 className="text-xl font-bold text-white">✅ Commercial Pest Control</h3>
                  </div>
                </div>
                <p className="text-gray-600">
                  Advanced termite piping control services for long-lasting termite prevention.
                </p>
                <Link href="/services/termite-piping">
                  <button className="mt-4 text-light-green font-medium hover:underline">View Details →</button>
                </Link>
              </motion.div>
            </AnimatedSection>
          </div>

          <AnimatedSection animation="fadeIn" delay={0.7}>
            <div className="text-center mt-8">
              <Link href="/services">
                <motion.button className="btn-dark" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  View All Pest Control Services Chennai
                </motion.button>
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🧪 Why Choose No.1 Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "✅ Government-Certified Pest Control Experts",
                description:
                  "Our team consists of trained & licensed pest control experts in Chennai with 45+ years of experience in termite control, cockroaches control and commercial pest control.",
              },
              {
                title: "✅ 45+ Years of Industry Experience",
                description:
                  "We use the latest pest control techniques and eco-friendly treatments for all pests in Chennai including termite control services Chennai and cockroaches control services Chennai.",
              },
              {
                title: "✅ Safe, Eco-Friendly Treatments",
                description:
                  "Tailored pest control solutions for homes, offices, and commercial pest control in Chennai at competitive price. Our control services Chennai are the best.",
              },
              {
                title: "✅ Advanced Equipment & Latest Methods",
                description:
                  "Quality pest control service Chennai at competitive rates with guaranteed results for termite control, cockroaches control and all pests. Best price for pest control services Chennai.",
              },
              {
                title: "✅ Affordable control price Chennai",
                description:
                  "We offer budget-friendly pest control solutions without compromising on quality or effectiveness.",
              },
              {
                title: "✅ 100% Customer Satisfaction Guaranteed",
                description:
                  "We stand behind our work with a satisfaction guarantee on all our pest control services Chennai.",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.4}>
            <div className="text-center mt-8">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="text-xl mr-2">🔹</span>
                <span className="font-medium">Get a Free Pest Control Inspection Chennai Today!</span>
                <a href="tel:+917558108600" className="ml-2 font-bold hover:underline">
                  📞 Call Now for Pest Control Service: +91 7558108600
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">🛠️ Our Pest Control Process Chennai</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {[
              {
                icon: <ClipboardList className="h-8 w-8" />,
                emoji: "🔍",
                title: "Step 1: Thorough Inspection",
                description:
                  "We start every control service Chennai with a complete pest inspection to identify the root problem.",
              },
              {
                icon: <ClipboardList className="h-8 w-8" />,
                emoji: "📋",
                title: "Step 2: Custom Plan",
                description: "We create a personalized plan tailored to your pest issue and property type.",
              },
              {
                icon: <Shield className="h-8 w-8" />,
                emoji: "✅",
                title: "Step 3: Safe Treatment",
                description:
                  "We apply eco-friendly pest control treatments that eliminate pests without harming the environment.",
              },
              {
                icon: <RefreshCw className="h-8 w-8" />,
                emoji: "🔄",
                title: "Step 4: Follow-Up",
                description:
                  "Regular follow-up and preventive control services Chennai to keep your property pest-free long-term.",
              },
            ].map((step, index) => (
              <AnimatedSection key={index} animation="fadeIn" delay={index * 0.2}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="flex items-center mb-4">
                    <div className="bg-dark-green text-white p-2 rounded-full mr-3">{step.icon}</div>
                    <div className="text-3xl">{step.emoji}</div>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Price List Section */}
      <PriceListSlider />

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">💬 What Our Clients Say – Customer Reviews</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                quote:
                  "They completely removed cockroaches from my kitchen using safe pest control methods. Highly recommended!",
                author: "Priya Sharma, Anna Nagar Pest Control",
              },
              {
                quote: "Best termite control in Chennai! They saved our furniture.",
                author: "Rajesh Kumar, T. Nagar Pest Control",
              },
              {
                quote: "Excellent monthly commercial pest control for our restaurant.",
                author: "Vijay Menon, Nungambakkam Pest Control",
              },
              {
                quote: "Solved our bed bug issue in one visit. Affordable and effective.",
                author: "Lakshmi Narayan, Adyar Pest Control",
              },
            ].map((testimonial, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex flex-col">
                    <p className="italic mb-4">"{testimonial.quote}"</p>
                    <p className="font-bold text-right">– {testimonial.author}</p>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.4}>
            <div className="text-center mt-8">
              <div className="inline-flex flex-col items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <p className="font-bold mb-2">✅ 100000+ Happy Clients across Chennai</p>
                <p className="font-bold">✅ 5-Star Rated Pest Control Services Chennai</p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-4">📍 Pest Control Service Areas in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We proudly serve all major areas with our expert pest control services Chennai, including:
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <div className="bg-white p-6 rounded-lg shadow-md max-w-4xl mx-auto">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[
                  "✔️ Adyar",
                  "✔️ Anna Nagar",
                  "✔️ T. Nagar",
                  "✔️ Velachery",
                  "✔️ Mylapore",
                  "✔️ Porur",
                  "✔️ Tambaram",
                  "✔️ OMR",
                  "✔️ Kodambakkam",
                  "✔️ & More!",
                ].map((area, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <span>{area}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.3}>
            <div className="mt-8 text-center">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="font-medium">Not sure if we serve your area?</span>
                <a href="tel:+917558108600" className="ml-2 font-bold hover:underline">
                  📞 Call Now: +91 7558108600 for area-specific control services Chennai
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">💬 Get a Free Quote – Contact Us Today!</h2>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.a
                  href="tel:+917558108600"
                  className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>📞 Phone: +91 7558108600</span>
                </motion.a>
                <motion.a
                  href="https://wa.me/917558108600"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-green-500 text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>📲 WhatsApp: Click Here</span>
                </motion.a>
                <motion.div
                  className="flex items-center justify-center gap-2 bg-gray-200 text-gray-800 px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                >
                  <span>📧 Email: no1qualitypestcontrol@gmail.com</span>
                </motion.div>
              </div>
              <div className="mt-4">
                <motion.div
                  className="inline-flex items-center justify-center gap-2 bg-gray-200 text-gray-800 px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                >
                  <span>📍 Address: 202 Broadway Parrys, Chennai-600001, Tamil Nadu</span>
                </motion.div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.3}>
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-light-green/10 px-6 py-3 rounded-lg">
                <span className="text-xl mr-2">💡</span>
                <span className="font-medium">Fill out the form below for a free pest control inspection & quote</span>
              </div>
            </div>
          </AnimatedSection>

          <div className="max-w-4xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-6">
                🚫 Don't Let Pests Take Over – Call the Experts in Pest Control Chennai!
              </h2>
              <p className="text-lg mb-8">
                Whether you need residential pest control, commercial pest control, termite control, or cockroaches
                control, No.1 Quality Pest Control Chennai has the solution for you.
              </p>
              <div className="space-y-3 mb-6">
                <p className="font-bold">✅ Best pest control Chennai</p>
                <p className="font-bold">✅ Top-rated control services Chennai</p>
                <p className="font-bold">✅ Affordable pest control price Chennai</p>
              </div>
              <motion.a
                href="tel:+917558108600"
                className="inline-flex items-center justify-center gap-2 bg-dark-green text-white px-8 py-4 rounded-md text-lg font-bold"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span>📞 Call Now for the No.1 Pest Control Service in Chennai – +91 7558108600</span>
              </motion.a>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </>
  )
}
