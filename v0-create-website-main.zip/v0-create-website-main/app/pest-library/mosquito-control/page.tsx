"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function MosquitoControlPage() {
  return (
    <>
      <PageHeader
        title="Mosquito Control in Chennai | No.1 Quality Pest Control"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzopu2w4caDDze0eTucWBnPgk5eQde.png"
        subtitle="Professional Mosquito Control Services in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <h2 className="text-3xl font-bold mb-4">Mosquito Control in Chennai – No.1 Quality Pestcontrol 🦟❌</h2>
                <p className="mb-6">
                  Tired of mosquito bites and disease risks? Our expert mosquito control services in Chennai provide a
                  long-term solution to keep your home and office mosquito-free!
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Fogging & Spraying Treatment – Targets mosquito breeding areas.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Eco-Friendly Solutions – Safe for families, pets, and the environment.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Dengue & Malaria Prevention – Reduces the risk of mosquito-borne diseases.</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Home & Commercial Mosquito Control – Hotels, apartments, offices & more.</p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">Trusted by 50000+ Happy Customers Across Chennai!</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzopu2w4caDDze0eTucWBnPgk5eQde.png"
                  alt="Mosquito Control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Mosquito Control Process</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">1</span>
                  </div>
                  <h3 className="text-xl font-bold">Inspection & Assessment</h3>
                </div>
                <p className="text-gray-600">
                  Our experts identify mosquito breeding sites and assess the infestation level.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">2</span>
                  </div>
                  <h3 className="text-xl font-bold">Treatment & Elimination</h3>
                </div>
                <p className="text-gray-600">
                  We apply fogging, spraying, and larvicide treatments to eliminate adult mosquitoes and larvae.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">3</span>
                  </div>
                  <h3 className="text-xl font-bold">Prevention & Maintenance</h3>
                </div>
                <p className="text-gray-600">
                  We provide recommendations to prevent future mosquito breeding and offer maintenance plans.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Benefits of Our Mosquito Control Services</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Disease Prevention</h3>
                <p className="text-gray-600">Reduce the risk of dengue, malaria, and other mosquito-borne diseases.</p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Comfortable Outdoor Spaces</h3>
                <p className="text-gray-600">
                  Enjoy your garden, balcony, and outdoor areas without mosquito disturbances.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Long-Lasting Protection</h3>
                <p className="text-gray-600">Our treatments provide extended protection against mosquitoes.</p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Get Reliable Mosquito Control in Chennai Today!</h2>
            <p className="mb-6">
              Don't let mosquitoes ruin your comfort! Contact No.1 Quality Pest Control for safe, effective, and
              affordable mosquito control solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
