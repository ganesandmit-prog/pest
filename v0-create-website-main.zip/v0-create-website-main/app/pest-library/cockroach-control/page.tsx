"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function CockroachControlPage() {
  return (
    <>
      <PageHeader
        title="Cockroach Control in Chennai | No.1 Quality Pest Control"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-L5hASvrQm1wqMDdVr0v2zJqJoLHITk.png"
        subtitle="Professional Cockroach Control Services in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <h2 className="text-3xl font-bold mb-4">
                  Cockroach Control Services in Chennai – No.1 Quality Pestcontrol
                </h2>
                <p className="mb-6">
                  Say goodbye to disease-spreading cockroaches with our safe and effective cockroach control services in
                  Chennai. We eliminate cockroaches from kitchens, bathrooms, and hidden corners using eco-friendly,
                  non-toxic treatments.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Residential & Commercial Cockroach Control</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Modern Gel & Spray Treatments</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Long-Lasting Results & 100% Satisfaction</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>24x7 Service | Affordable Rates | Expert Technicians</p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">
                    ✨ Best Cockroach Control Services Near You! Safe for Kids & Pets. Book Now!
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">📞 Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      📲 WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-L5hASvrQm1wqMDdVr0v2zJqJoLHITk.png"
                  alt="Cockroach Control"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Cockroach Control Process</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">1</span>
                  </div>
                  <h3 className="text-xl font-bold">Inspection & Assessment</h3>
                </div>
                <p className="text-gray-600">
                  Our experts identify cockroach species, hiding spots, and the extent of infestation.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">2</span>
                  </div>
                  <h3 className="text-xl font-bold">Treatment & Elimination</h3>
                </div>
                <p className="text-gray-600">
                  We apply gel baits, sprays, and dusts to eliminate cockroaches from their hiding places.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <div className="flex items-center mb-4">
                  <div className="bg-dark-green text-white p-3 rounded-full mr-3 flex-shrink-0">
                    <span className="text-xl font-bold">3</span>
                  </div>
                  <h3 className="text-xl font-bold">Prevention & Monitoring</h3>
                </div>
                <p className="text-gray-600">
                  We provide recommendations to prevent future infestations and conduct follow-up visits if needed.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Our Cockroach Control Services</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Fast & Reliable Service</h3>
                <p className="text-gray-600">
                  Quick response times and efficient cockroach elimination for your home or business.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Safe for Family & Pets</h3>
                <p className="text-gray-600">
                  Our treatments are non-toxic and safe for children, pets, and the environment.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-4">Experienced Technicians</h3>
                <p className="text-gray-600">
                  Our team consists of trained professionals with years of experience in cockroach control.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Get Professional Cockroach Control in Chennai Today!</h2>
            <p className="mb-6">
              Don't let cockroaches invade your space! Contact No.1 Quality Pest Control for safe, effective, and
              affordable cockroach control solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
