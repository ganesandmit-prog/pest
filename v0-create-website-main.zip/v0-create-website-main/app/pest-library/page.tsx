"use client"

import type React from "react"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection, StaggeredContainer } from "@/components/framer-animations"
import { motion } from "framer-motion"
import ContactForm from "@/components/contact-form"
import { Check } from "lucide-react"

interface PestType {
  name: string
  image: string
  slug: string
  content: React.ReactNode
}

export default function PestLibraryPage() {
  const pests: PestType[] = [
    {
      name: "Ant Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-6lrD4kBfAovJAmZhpzAfdnGzcSUyvn.png",
      slug: "ant-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">How to Protect Your Home from Ants – Expert Tips</h3>
          <p className="mb-3">
            Ant infestations can be frustrating! Follow these proven ant control tips to keep your home pest-free:
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Keep Food Sealed – Store food in airtight containers to avoid attracting ants.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Clean Regularly – Wipe spills, sweep crumbs, and maintain a clutter-free space.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Seal Entry Points – Block cracks, gaps, and holes to prevent ants from entering.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Use Natural Repellents – Sprinkle cinnamon, vinegar, or lemon at entry points.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>
                Professional Pest Control – Get expert ant control services in Chennai from No.1 Quality Pestcontrol for
                a 100% pest-free environment.
              </span>
            </li>
          </ul>
          <p className="font-bold">Call Now: 7558108600 for Safe & Affordable Ant Control!</p>
          <p className="mt-2">24x7 Pest Control | Non-Toxic Solutions | Best Ant Extermination in Chennai</p>
        </div>
      ),
    },
    {
      name: "Bed Bug Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pg04NtTuPrvAmJ2pJF7TGw0BOgdcGC.png",
      slug: "bed-bug-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">Best Bed Bug Control in Chennai – No.1 Quality Pestcontrol 🛏️🐞</h3>
          <p className="mb-3">
            Are bed bugs disturbing your sleep? Get fast, effective, and affordable bed bug control in Chennai with No.1
            Quality Pestcontrol!
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Complete Bed Bug Removal – Eliminates bed bugs from mattresses, furniture, and hidden spots.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Eco-Friendly & Safe Treatment – Non-toxic solutions, safe for children & pets.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Advanced Heat & Chemical Treatment – Kills bed bugs at all life stages.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>24x7 Pest Control Services – Emergency service available for homes, hotels, and offices.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Guaranteed Pest-Free Environment – Say goodbye to bed bugs permanently!</span>
            </li>
          </ul>
          <p className="font-bold">Call Now: 7558108600 for Professional Bed Bug Control in Chennai! 🚫🐞</p>
          <p className="mt-2">Affordable Prices | Expert Pest Control | 100% Customer Satisfaction</p>
        </div>
      ),
    },
    {
      name: "Cockroach Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-L5hASvrQm1wqMDdVr0v2zJqJoLHITk.png",
      slug: "cockroach-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">Cockroach Control Services in Chennai – No.1 Quality Pestcontrol</h3>
          <p className="mb-3">
            Say goodbye to disease-spreading cockroaches with our safe and effective cockroach control services in
            Chennai. We eliminate cockroaches from kitchens, bathrooms, and hidden corners using eco-friendly, non-toxic
            treatments.
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Residential & Commercial Cockroach Control</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Modern Gel & Spray Treatments</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Long-Lasting Results & 100% Satisfaction</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>24x7 Service | Affordable Rates | Expert Technicians</span>
            </li>
          </ul>
          <p className="font-bold">
            Call No.1 Quality Pestcontrol at 7558108600 for fast & reliable cockroach extermination in Chennai.
          </p>
          <p className="mt-2">✨ Best Cockroach Control Services Near You! Safe for Kids & Pets. Book Now!</p>
        </div>
      ),
    },
    {
      name: "Rodent & Rat Control in Chennai",
      image: "https://images.unsplash.com/photo-1548767797-d8c844163c4c",
      slug: "rodent-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">
            Best Rodent & Rat Control in Chennai – No.1 Quality Pestcontrol 🐀🚫
          </h3>
          <p className="mb-3">
            Rodents and rats can cause property damage, contaminate food, and spread diseases. Get expert rat control in
            Chennai with our safe and effective pest control methods!
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Complete Rodent Removal – Eliminates rats and mice from homes, offices, and industries.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Eco-Friendly & Non-Toxic Solutions – Safe for pets and children.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Structural Damage Prevention – Protects wiring, furniture, and food storage areas.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>24x7 Pest Control Service – Quick response and emergency rodent control.</span>
            </li>
          </ul>
          <p className="font-bold">Call 7558108600 for Affordable Rat Control in Chennai! 🐀🚫</p>
        </div>
      ),
    },
    {
      name: "Mosquito Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzopu2w4caDDze0eTucWBnPgk5eQde.png",
      slug: "mosquito-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">Mosquito Control in Chennai – No.1 Quality Pestcontrol 🦟❌</h3>
          <p className="mb-3">
            Tired of mosquito bites and disease risks? Our expert mosquito control services in Chennai provide a
            long-term solution to keep your home and office mosquito-free!
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Fogging & Spraying Treatment – Targets mosquito breeding areas.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Eco-Friendly Solutions – Safe for families, pets, and the environment.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Dengue & Malaria Prevention – Reduces the risk of mosquito-borne diseases.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Home & Commercial Mosquito Control – Hotels, apartments, offices & more.</span>
            </li>
          </ul>
          <p className="font-bold">Call 7558108600 for Reliable Mosquito Control in Chennai! 🦟❌</p>
        </div>
      ),
    },
    {
      name: "Spider Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VhEzIq24sp1W9R6w5zc3sSHRLynXuk.png",
      slug: "spider-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">
            Professional Spider Control in Chennai – No.1 Quality Pestcontrol 🕷️🚫
          </h3>
          <p className="mb-3">
            Spiders can be creepy and cause allergic reactions! Our spider control service in Chennai ensures safe and
            complete spider removal from homes, offices, and warehouses.
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Advanced Pest Control Treatment – Eliminates spiders and their webs.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Non-Toxic & Eco-Friendly Solutions – Safe for your family.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Prevents Future Infestations – Long-term spider prevention methods.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>24x7 Service Available – Get expert pest control anytime!</span>
            </li>
          </ul>
          <p className="font-bold">Call 7558108600 for Best Spider Control in Chennai! 🕷️🚫</p>
        </div>
      ),
    },
    {
      name: "Termite Control in Chennai",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-DrXuVqr8TseJvL7VFboeuxR2Wx14eu.png",
      slug: "termite-control",
      content: (
        <div>
          <h3 className="text-xl font-bold mb-3">Top Termite Control in Chennai – No.1 Quality Pestcontrol 🏡🐜</h3>
          <p className="mb-3">
            Protect your home, furniture, and wooden structures from destructive termites with our professional termite
            control services in Chennai!
          </p>
          <ul className="space-y-2 mb-4">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Pre-Construction & Post-Construction Termite Treatment – Long-term protection.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Advanced Termite Control Techniques – Eliminates termites at the source.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Structural Damage Prevention – Saves your wooden furniture and property.</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
              <span>Odorless & Non-Toxic Solutions – Safe and effective treatment.</span>
            </li>
          </ul>
          <p className="font-bold">Call 7558108600 for Expert Termite Control in Chennai! 🏡🐜</p>
          <p className="mt-4">
            Need pest-free solutions? No.1 Quality Pestcontrol is your trusted partner for safe, eco-friendly, and
            affordable pest control services in Chennai! 🚫🐜🐀🦟
          </p>
          <p className="mt-2">📞 Book Your Service Now – 7558108600! ✅</p>
        </div>
      ),
    },
  ]

  return (
    <>
      <PageHeader
        title="No.1 Quality Pest Control Chennai – Pest Library"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-tcKxS27RCmynOE0pfWHFsyWYsqOwFU.png"
        subtitle="Comprehensive Pest Control Services in Chennai"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              At No.1 Quality Pest Control Chennai, we provide professional, eco-friendly, and highly effective pest
              control solutions for both residential and commercial properties. Whether you are dealing with termites,
              cockroaches, rodents, bed bugs, or mosquitoes, our expert team is here to help you maintain a pest-free
              home or business.
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <h2 className="text-2xl font-bold mb-8 text-center">
              Explore our Pest Library to learn about common pests in Chennai and how we can help you eliminate them!
            </h2>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.3}>
            <h2 className="text-2xl font-bold mb-8">Common Pests in Chennai & Our Specialized Treatments</h2>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pests.map((pest) => (
                <Link key={pest.slug} href={`/pest-library/${pest.slug}`}>
                  <motion.div className="bg-white rounded-lg overflow-hidden shadow-md h-full" whileHover={{ y: -10 }}>
                    <div className="relative h-48">
                      <Image src={pest.image || "/placeholder.svg"} alt={pest.name} fill className="object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                        <div className="p-4">
                          <h3 className="text-xl font-bold text-white flex items-center">{pest.name}</h3>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="text-light-green font-medium mt-4">View Details →</div>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </StaggeredContainer>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Quality Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "Residential & Commercial Pest Control Services in Chennai",
                description: "",
              },
              {
                title: "Eco-Friendly, Non-Toxic, & Odorless Pest Solutions",
                description: "",
              },
              {
                title: "100% Satisfaction Guarantee & Affordable Pricing",
                description: "",
              },
              {
                title: "24/7 Emergency Pest Control Services in Chennai",
                description: "",
              },
              {
                title: "Serving All Areas: Anna Nagar, Velachery, Tambaram, T. Nagar, OMR, Adyar & More",
                description: "",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold">{item.title}</h3>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Call Us Now: +91 7558108600</h2>
            <p className="mb-6">Get a Free Pest Inspection Today!</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Call Now
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Contact No.1 Quality Pest Control Chennai Today!</h2>
              <p className="text-gray-600 mb-4">
                Get in touch with Chennai's leading pest control experts for a free consultation. We offer affordable,
                effective, and eco-friendly solutions to make your home or office 100% pest-free.
              </p>
              <p className="font-medium">
                Service Areas: Chennai, Anna Nagar, Velachery, Tambaram, T. Nagar, OMR, Adyar, Perungudi, Sholinganallur
                & more.
              </p>
            </div>
          </AnimatedSection>

          <div className="max-w-4xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  )
}
