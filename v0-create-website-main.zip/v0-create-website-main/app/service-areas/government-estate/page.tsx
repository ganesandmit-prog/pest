import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import GovernmentEstatePestControlClient from "./GovernmentEstatePestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Government Estate, Chennai | No.1 Quality Pest Control",
  description:
    "Reliable pest control solutions for Government Estate, Chennai. We specialize in pest management for government buildings and facilities with safe, professional services.",
  keywords:
    "pest control Government Estate, Government Estate pest services, cockroach control Government Estate, termite treatment Government Estate, rodent control Government Estate, mosquito control Government Estate, commercial pest control Government Estate, Chennai pest control",
}

export default function GovernmentEstatePage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Best Pest Control in Government Estate, Chennai"
        description="Reliable Pest Control Solutions for government buildings and facilities"
      />
      <GovernmentEstatePestControlClient />
    </main>
  )
}
