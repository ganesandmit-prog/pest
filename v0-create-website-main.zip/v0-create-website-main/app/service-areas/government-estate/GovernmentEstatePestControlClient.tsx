"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"
import ProcessSection from "@/components/process-section"

export default function GovernmentEstatePestControlClient() {
  const [isFormSubmitted, setIsFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setIsFormSubmitted(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h2 className="text-3xl font-bold mb-6 text-primary">
          Best Pest Control in Government Estate, Chennai – Reliable Pest Control Solutions
        </h2>
        <p className="mb-4">
          Looking for pest control services in Government Estate, Chennai? We specialize in providing efficient and
          effective pest control solutions for government buildings, facilities, and offices. Whether you're dealing
          with termite infestations or rodent issues, our team is here to help with safe, professional services.
        </p>

        <h3 className="text-2xl font-semibold mt-8 mb-4 text-primary">
          Our Pest Control Services in Government Estate:
        </h3>
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>🪳 Cockroach Control</li>
          <li>🐜 Termite Control</li>
          <li>🐀 Rodent Control</li>
          <li>🦟 Mosquito Control</li>
          <li>🌿 Organic Pest Control</li>
          <li>🛏 Bed Bug Treatment</li>
          <li>🏢 Commercial Pest Control for government offices and buildings</li>
        </ul>
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Why Choose Us for Pest Control in Government Estate?
        </h3>
        <BenefitsSection
          benefits={[
            "Specialized Services – Pest management for government buildings and facilities",
            "Affordable Solutions – Professional pest control at competitive prices",
            "Eco-Friendly Treatments – Safe and non-toxic pest control methods",
            "Expert Technicians – Skilled and certified pest control professionals",
            "Reliable and Timely – Fast and efficient pest control service delivery",
          ]}
        />
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Areas We Serve in and Around Government Estate, Chennai:
        </h3>
        <ul className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <li className="bg-gray-100 p-3 rounded-lg text-center">Government Estate</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Secretariat Colony</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Egmore</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Fort St. George</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Triplicane</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Mylapore</li>
        </ul>
      </motion.section>

      <ProcessSection />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Contact Us for Pest Control in Government Estate, Chennai:
        </h3>
        <div className="bg-gray-100 p-6 rounded-lg mb-8">
          <p className="mb-2">
            <strong>📱 Call:</strong> +91 7558108600
          </p>
          <p className="mb-2">
            <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
          </p>
          <p>
            <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-xl font-semibold mb-4 text-primary">Request a Free Quote</h4>
          <ContactForm onSubmitSuccess={handleFormSubmit} location="Government Estate" />
          {isFormSubmitted && (
            <p className="mt-4 text-green-600 font-medium">
              Thank you for your inquiry! Our team will contact you shortly with a free quote for pest control services
              in Government Estate.
            </p>
          )}
        </div>
      </motion.section>
    </div>
  )
}
