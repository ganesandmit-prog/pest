import type { Metadata } from "next"
import { PalavakkamPestControlClient } from "./PalavakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Palavakkam | Trusted Residential Pest Control Services",
  description:
    "Looking for affordable pest control services in Palavakkam, Chennai? We offer expert residential pest control, termite treatment, and more at the best prices with free quotes!",
  keywords:
    "pest control Palavakkam, pest control services Palavakkam, Palavakkam pest control, residential pest control, termite treatment, rodent removal, mosquito control, pest control company Palavakkam, affordable pest control, eco-friendly pest control, pest control quotes, cleaning services, sanitization services, pest control Chennai",
}

export default function PalavakkamPage() {
  return <PalavakkamPestControlClient />
}
