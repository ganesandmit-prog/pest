"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PalavakkamPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Palavakkam",
              "description": "Professional pest control services in Palavakkam, Chennai. We offer residential and commercial pest control, termite treatment, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/palavakkam",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Palavakkam, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Termite Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Palavakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Palavakkam including general pest control, termite treatment, rodent removal, mosquito control, and specialized residential pest control solutions with cleaning and sanitization services."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Palavakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Palavakkam start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Palavakkam. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Palavakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Palavakkam. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Palavakkam, Chennai"
          description="Professional pest control solutions for homes and businesses in Palavakkam. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Palavakkam – Trusted Residential Pest Control Services
              </h2>
              <p className="text-gray-600 mb-4">
                Looking for affordable pest control services in Palavakkam, Chennai? 🏠 We are your trusted pest control
                company offering expert residential pest control, termite treatment, and more — at the best prices with
                free quotes!
              </p>
              <p className="text-gray-600 mb-4">
                Whether you're battling cockroaches, termites, rodents, or mosquitoes, our control services ensure your
                home is clean, safe, and pest-free.
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Palavakkam</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>General Pest Control – Comprehensive protection against ants, cockroaches, spiders, and more.</li>
                <li>
                  Termite Treatment Services – Prevent costly damages to your property with our powerful termite
                  control.
                </li>
                <li>Rodent and Mice Removal – Safe and effective rodent control solutions.</li>
                <li>Mosquito Control Services – Specialized treatments for mosquito-free living.</li>
                <li>Residential Pest Control – Customized services for homes and apartments.</li>
                <li>Cleaning and Sanitization Services – Post-pest-control cleaning to keep your home fresh.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Why Choose Our Pest Control Company in Palavakkam?
              </h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Expert Pest Control Services – Highly trained professionals using advanced treatment methods.</li>
                <li>Affordable Prices and Transparent Charges – No hidden fees; get upfront pest control quotes.</li>
                <li>Fast & Effective Pest Solutions – Immediate response and lasting results.</li>
                <li>Eco-Friendly Cleaning and Treatment Options – Safe for kids, pets, and nature.</li>
                <li>Local Palavakkam Specialists – We understand the specific pest challenges in your area.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Areas We Serve</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Residences and Villas in Palavakkam</li>
                <li>Apartments, PGs, and Rental Homes</li>
                <li>Commercial Offices and Shops in Chennai</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Get Free Pest Control Quotes in Palavakkam</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
