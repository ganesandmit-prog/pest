import type { Metadata } from "next"
import ChrompetPestControlClient from "./ChrompetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Chrompet | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Chrompet, Chennai. Fast, effective & reliable solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Chrompet, pest control services Chrompet, Chrompet pest control, cockroach control Chrompet, termite control Chrompet, bed bug control Chrompet, rodent control Chrompet",
}

export default function ChrompetPestControl() {
  return <ChrompetPestControlClient />
}
