"use client"

import { useState } from "react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"
import ContactForm from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"
import Image from "next/image"
import Link from "next/link"
import { Check, MapPin, Phone, Star } from "lucide-react"

export function VelappanchavadiPestControlClient() {
  const [location] = useState("Velappanchavadi")

  return (
    <>
      <PageHeader
        title="No.1 Quality Pest Control Services in Velappanchavadi, Chennai"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Professional & Affordable Pest Control in Velappanchavadi"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold mb-4">Expert Pest Control Services in Velappanchavadi, Chennai</h2>
              <p className="text-gray-600 mb-6">
                Velappanchavadi, an industrial and residential area in West Chennai, faces unique pest challenges due to
                its industrial zones, warehouses, and developing residential areas. No.1 Quality Pest Control offers
                specialized pest management solutions tailored to Velappanchavadi's specific needs.
              </p>
              <p className="text-gray-600 mb-6">
                With 45+ years of experience in pest control services, we've become the most trusted choice for
                residents and businesses in Velappanchavadi. Our comprehensive pest management solutions effectively
                eliminate rodents, cockroaches, termites, mosquitoes, and other pests common in industrial and
                residential settings.
              </p>
              <div className="bg-light-green/10 p-4 rounded-lg border border-light-green mb-6">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-light-green" />
                  Common Pest Issues in Velappanchavadi:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Rodent infestations in industrial areas and warehouses</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroach problems in residential buildings and food establishments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Termite issues in wooden structures and new constructions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Mosquito breeding in open areas and construction sites</span>
                  </li>
                </ul>
              </div>
              <div className="flex items-center justify-start mb-6">
                <Phone className="h-5 w-5 text-light-green mr-2" />
                <span className="font-semibold">Call us at: </span>
                <a href="tel:+917558108600" className="text-light-green font-bold ml-2 hover:underline">
                  +91 7558108600
                </a>
              </div>
              <Link href="/contact-us" className="btn-primary">
                Get Free Inspection in Velappanchavadi
              </Link>
            </AnimatedSection>

            <AnimatedSection animation="fadeIn" delay={0.2}>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Pest Control Services in Velappanchavadi"
                  width={800}
                  height={600}
                  className="w-full h-auto"
                />
              </div>
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <Star className="h-5 w-5 mr-2 text-yellow-500" />
                  Why Velappanchavadi Residents & Businesses Choose Us:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>45+ years of pest control expertise in Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Specialized industrial pest control solutions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Eco-friendly and safe pest management methods</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Affordable pricing with no hidden charges</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Emergency pest control services available</span>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ServicesList
        title="Our Comprehensive Pest Control Services in Velappanchavadi"
        description="We offer a wide range of pest control services to keep your home and business in Velappanchavadi pest-free."
        location="Velappanchavadi"
      />

      <ProcessSection
        title="Our Pest Control Process in Velappanchavadi"
        description="Our systematic approach ensures effective and long-lasting pest control results for Velappanchavadi residents and businesses."
      />

      <BenefitsSection
        title="Benefits of Our Pest Control Services in Velappanchavadi"
        description="Experience the advantages of choosing No.1 Quality Pest Control for your pest management needs in Velappanchavadi."
      />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Pest Control FAQs for Velappanchavadi Residents</h2>
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  What pest control services do you offer for industrial areas in Velappanchavadi?
                </h3>
                <p className="text-gray-600">
                  For industrial areas in Velappanchavadi, we offer specialized pest control services including
                  comprehensive rodent management, stored product pest control, fly control, and general pest
                  management. Our industrial pest control programs are designed to meet regulatory compliance while
                  ensuring minimal disruption to your operations.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  How do you handle rodent problems in Velappanchavadi warehouses?
                </h3>
                <p className="text-gray-600">
                  For Velappanchavadi warehouses, we implement a multi-faceted rodent control approach including
                  exclusion methods (sealing entry points), strategic placement of tamper-resistant bait stations,
                  mechanical traps, and regular monitoring. We also provide recommendations for storage practices that
                  reduce rodent attraction.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Are your pest control methods safe for residential areas in Velappanchavadi?
                </h3>
                <p className="text-gray-600">
                  Yes, we use eco-friendly and family-safe pest control methods in Velappanchavadi residential areas.
                  Our technicians are trained to apply treatments that effectively eliminate pests while ensuring the
                  safety of residents, pets, and the environment. We'll provide specific safety instructions for each
                  treatment.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Do you offer annual pest control contracts for Velappanchavadi businesses?
                </h3>
                <p className="text-gray-600">
                  Yes, we provide customized annual pest control contracts for businesses in Velappanchavadi. These
                  contracts include regular inspections, preventive treatments, and emergency response services. Our
                  commercial pest management programs can be tailored to your specific business needs and scheduled to
                  minimize disruption.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <TestimonialsSection
        title="What Our Velappanchavadi Customers Say"
        description="Read testimonials from satisfied customers in Velappanchavadi who have experienced our quality pest control services."
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Pest Control in Velappanchavadi</h2>
            <ContactForm defaultLocation={location} />
          </AnimatedSection>
        </div>
      </section>

      <QuickLinks />
    </>
  )
}

export default VelappanchavadiPestControlClient
