import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Annanur | No.1 Quality Pest Control Chennai",
  description:
    "Looking for top pest control services in Annanur? We offer safe, effective, and long-lasting pest control treatments for your home and office.",
}

export default function AnnanurPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control Services in Annanur, Chennai" subtitle="Affordable & Reliable" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              Looking for top pest control services in Annanur? We offer safe, effective, and long-lasting pest control
              treatments for your home and office. From cockroach gel pest control to complete termite control, our
              services are trusted by hundreds of clients across Annanur, Anna Nagar, and all over Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why We're the Leading Pest Control Company in Annanur?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Verified on Sulekha, Justdial, and Google</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Certified & Odorless Gel Pest Control Services</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Professional Technicians & Fast Response Time</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Affordable Pricing & Customizable Packages</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Positive Ratings, Photos, and Reviews From Happy Customers</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Serving Residential, Commercial & Industrial Properties</span>
              </li>
            </ul>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Pest Control Services in Annanur Chennai Include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🪳 Cockroach Gel Pest Control</h3>
                <p>Effective elimination of cockroaches using advanced gel treatments.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐜 Termite Treatment & Pre/Post Construction Solutions</h3>
                <p>Comprehensive termite protection for your property and wooden furniture.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🦟 Mosquito Control Services</h3>
                <p>Advanced treatments to keep your home free from mosquitoes.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐀 Rodent/Rat Control</h3>
                <p>Safe and effective solutions to eliminate rats and mice from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🛏️ Bed Bug Treatment</h3>
                <p>Specialized treatments to eliminate bed bugs completely.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🧹 Home Cleaning & Disinfection Services</h3>
                <p>Professional cleaning services to maintain a hygienic environment.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🏢 Commercial & Industrial Pest Management</h3>
                <p>Specialized pest control solutions for commercial spaces and offices.</p>
              </div>
            </div>
            <p className="mt-4">
              We use modern gel-based pest control methods which are safe for children and pets, making us the most
              trusted residential pest control service in Annanur.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">We Serve:</h2>
            <p>Along with Annanur, we extend our services to:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Anna Nagar</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Villivakkam</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Ambattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Korattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Mogappair</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Padi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Aminjikarai</div>
            </div>
            <p className="mt-4">Our technicians reach you quickly to resolve any pest issue efficiently.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 className="text-2xl font-bold mb-4">What Makes Us Better Than Others?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Leading Pest Control Service Provider in Annanur</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Trusted on Sulekha & Google With 4.9+ Ratings</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Affordable Pest Control With Free Inspection</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Residential, Commercial & Industrial Expertise</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Flexible Timing, Emergency Service Available</span>
              </li>
            </ul>
            <p className="mt-4">
              With high-quality services and years of experience, we're the #1 pest control company in Annanur Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Book Your Service Today!</h2>
            <p className="mb-4">
              Ready to get rid of pests for good? Get in touch with the top-rated pest control service near you.
            </p>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Call Us:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Website:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Annanur</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
