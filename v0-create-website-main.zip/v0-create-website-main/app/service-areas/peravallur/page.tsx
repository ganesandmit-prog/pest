import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import PeravallurPestControlClient from "./PeravallurPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Peravallur Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Peravallur? No.1 Quality Pest Control offers reliable, safe, and organic pest control services in Peravallur Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function PeravallurPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Peravallur Chennai"
        subtitle="Professional & Affordable Pest Control Services in Peravallur"
      />
      <PeravallurPestControlClient />
    </main>
  )
}
