"use client"

import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export default function PeravallurPestControlClient() {
  return (
    <div className="container mx-auto px-4 py-12">
      <AnimatedSection animation="fadeIn" delay={0.1}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Peravallur</h2>
          <p className="mb-4">
            Are you searching for trusted pest control services in Peravallur, Chennai? Our expert control services
            specialize in effective pest management for homes, warehouses, and commercial properties. We offer safe and
            organic pest control solutions tailored to keep your environment pest-free and healthy.
          </p>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.2}>
        <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Peravallur</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🐞 General Pest Control & Organic Pest Treatments</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🐀 Rodent Control for Residential and Warehouses</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🧹 Professional Cleaning and Sanitization Services</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🌿 Eco-Friendly, Organic Pest Solutions</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🏢 Commercial & Residential Pest Control</span>
            </div>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.3}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">
            Why Choose Our Pest Control Company in Peravallur?
          </h2>
          <ul className="list-none space-y-3">
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Experienced Professionals: Trained experts offering reliable and safe control services.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Organic & Eco-Friendly: Using natural pest control methods safe for your family and pets.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>
                Trusted Company: Highly recommended on Sulekha and by local clients in Peravallur and Chennai.
              </span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Warehouse Pest Solutions: Specialized pest control for warehouses and commercial spaces.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Affordable & Transparent Pricing: Clear quotes with no hidden fees.</span>
            </li>
          </ul>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.4}>
        <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Serving Peravallur and Chennai Areas</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">Peravallur</div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">Chennai</div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">Nearby Localities</div>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="fadeIn" delay={0.5}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Contact Us Today for Pest Control in Peravallur!</h2>
          <p className="mb-4">
            Protect your home or business with the best pest control services in Peravallur. Call us now for a free
            quote and expert pest management solutions!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex items-center">
              <span className="font-bold mr-2">📱 Phone:</span>
              <a href="tel:+917558108600" className="text-light-green hover:underline">
                +91 7558108600
              </a>
            </div>
            <div className="flex items-center">
              <span className="font-bold mr-2">📧 Email:</span>
              <a href="mailto:no1qualitypestcontrol@gmail.com" className="text-light-green hover:underline">
                no1qualitypestcontrol@gmail.com
              </a>
            </div>
          </div>
          <div>
            <p>
              <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
            </p>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="fadeIn" delay={0.6}>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
            Contact Us for Pest Control in Peravallur
          </h2>
          <ContactForm />
        </div>
      </AnimatedSection>
    </div>
  )
}
