import type { Metadata } from "next"
import { PammalPestControlClient } from "./PammalPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pammal | Trusted Experts in Chennai",
  description:
    "Are pests disturbing your peace? Our expert pest control services in Pammal, Chennai deliver powerful and lasting pest management solutions at affordable rates.",
  keywords:
    "pest control Pammal, pest control services Pammal, Pammal pest control, cockroach control Pammal, gel pest control, general pest control Pammal, mosquito control Pammal, rodent control Pammal, commercial pest control Pammal, eco-friendly cleaning services, pest management Pammal, affordable pest control, pest control Chennai",
}

export default function PammalPage() {
  return <PammalPestControlClient />
}
