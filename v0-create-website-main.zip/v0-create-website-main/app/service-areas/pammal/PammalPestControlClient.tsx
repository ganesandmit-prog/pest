"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PammalPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Pammal",
              "description": "Professional pest control services in Pammal, Chennai. We offer residential and commercial pest control, cockroach control, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pammal",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Pammal, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Cockroach Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Pammal?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Pammal including cockroach control, general pest control, mosquito control, rodent removal, commercial pest control, and eco-friendly cleaning services."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Pammal?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Pammal start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Pammal. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Pammal?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Pammal. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Pammal, Chennai"
          description="Professional pest control solutions for homes and businesses in Pammal. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Pammal – Trusted Experts in Chennai
              </h2>
              <p className="text-gray-600 mb-4">
                Are pests disturbing your peace at home or work? 🏠✨ Our expert pest control services in Pammal,
                Chennai are here to help! From cockroach infestations to full property treatments, we deliver powerful
                and lasting pest management solutions at affordable rates.
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Pammal</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Cockroach Control – Targeted gel pest control to eliminate cockroaches fast.</li>
                <li>General Pest Control Services – Covers ants, bed bugs, spiders, and more.</li>
                <li>Mosquito Control Solutions – Safe and effective mosquito eradication.</li>
                <li>Rodent Removal Services – Keep your home safe from rodents and rats.</li>
                <li>Commercial Pest Control – Solutions for offices, shops, and restaurants.</li>
                <li>Eco-Friendly Cleaning Services – Special cleaning and pest ban techniques.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Why Choose Us for Pest Control in Pammal?</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Certified Professionals – Trained and experienced pest control experts.</li>
                <li>Advanced Solutions – Use of gel pest control, safe chemicals, and eco-friendly methods.</li>
                <li>Affordable Pricing – Best rates for residential and commercial spaces.</li>
                <li>Fast and Efficient Service – Quick response and long-lasting pest management.</li>
                <li>Complete Pest Solutions – Covering mega pest issues and city pest challenges effectively.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Areas We Serve in Pammal</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Residential Homes and Villas</li>
                <li>Apartments and Gated Communities</li>
                <li>Shops, Restaurants, and Offices</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Contact Us for Pest Control in Pammal!</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
