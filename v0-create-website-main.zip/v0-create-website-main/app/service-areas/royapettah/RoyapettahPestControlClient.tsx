"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function RoyapettahPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Royapettah, Chennai"
        description="Professional & affordable pest control services in Royapettah. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            ✅ Pest Control in Royapettah, Chennai – Expert Pest Control Services You Can Trust
          </h2>

          <p>
            Looking for trusted pest control in Royapettah, Chennai? We offer the most reliable, safe, and professional
            pest control services tailored to homes, apartments, offices, and commercial spaces. Whether you're facing
            issues with cockroaches, termites, bed bugs, or other pests, our expert team delivers fast, effective
            solutions that last.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pest Control Services in Royapettah Include:</h3>

          <ul>
            <li>🪳 Cockroach Control – Odorless gel treatment & spray</li>
            <li>🐀 Rodent Control – Complete rat and mouse removal</li>
            <li>🛏️ Bed Bug Treatment – Deep treatment with long-term results</li>
            <li>🦟 Mosquito Control – Fogging & larvicide-based solutions</li>
            <li>🐜 General Pest Control – Ants, spiders, lizards & more</li>
            <li>🧱 Termite Control Services – Pre- and post-construction treatment</li>
            <li>🌿 Eco-Friendly Pest Solutions – Safe for children and pets</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Us for Pest Control in Royapettah?</h3>

          <ul>
            <li>✔️ Certified & Experienced Professionals – Serving Chennai for years</li>
            <li>✔️ Comprehensive Control Services – Covers all types of pests</li>
            <li>✔️ Affordable Pest Control Packages – No hidden charges</li>
            <li>✔️ Customer-Focused Approach – Excellent feedback from Royapettah clients</li>
            <li>✔️ Same-Day Service – Quick scheduling & emergency pest control</li>
            <li>✔️ 100% Satisfaction Guarantee – Trusted pest solutions with results</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 We Serve Royapettah & Nearby Areas:</h3>

          <ul>
            <li>Royapettah, Chennai</li>
            <li>Triplicane</li>
            <li>Mylapore</li>
            <li>Gopalapuram</li>
            <li>Teynampet</li>
            <li>Thousand Lights</li>
            <li>Egmore</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">🔍 Keywords Targeted for SEO Ranking:</h3>

          <ul>
            <li>Pest Control in Royapettah Chennai</li>
            <li>Best Pest Control Services in Royapettah</li>
            <li>Affordable Pest Control Chennai</li>
            <li>General Pest Control Services Royapettah</li>
            <li>Control Services Chennai</li>
            <li>Top Pest Management Near Royapettah</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">
              📞 Call the Best Pest Control Service in Royapettah Now!
            </h3>
            <p>
              Protect your home or business from unwanted pests with Royapettah's most trusted team. Book a free
              inspection or get your pest control quote today.
            </p>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
