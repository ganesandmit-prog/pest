import type { Metadata } from "next"
import { RoyapettahPestControlClient } from "./RoyapettahPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Royapettah, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Royapettah, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Royapettah, pest services Royapettah, cockroach control Royapettah, termite treatment Royapettah, bed bug control Royapettah, mosquito control Royapettah, rodent control Royapettah, pest control services Royapettah Chennai",
}

export default function RoyapettahPage() {
  return <RoyapettahPestControlClient />
}
