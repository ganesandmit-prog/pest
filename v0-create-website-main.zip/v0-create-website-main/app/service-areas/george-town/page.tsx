import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import GeorgeTownPestControlClient from "./GeorgeTownPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in George Town, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in George Town, Chennai. We offer cockroach, termite, rodent, and mosquito control with eco-friendly solutions. Contact us for a pest-free home!",
  keywords:
    "pest control George Town, George Town pest services, cockroach control George Town, termite treatment George Town, rodent control George Town, mosquito control George Town, bed bug treatment George Town, commercial pest control George Town, Chennai pest control",
}

export default function GeorgeTownPage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Pest Control Services in George Town, Chennai"
        description="Professional and affordable pest control solutions for homes and businesses in George Town"
      />
      <GeorgeTownPestControlClient />
    </main>
  )
}
