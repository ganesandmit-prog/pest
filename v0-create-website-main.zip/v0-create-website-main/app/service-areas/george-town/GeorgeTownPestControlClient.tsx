"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"
import ProcessSection from "@/components/process-section"

export default function GeorgeTownPestControlClient() {
  const [isFormSubmitted, setIsFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setIsFormSubmitted(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h2 className="text-3xl font-bold mb-6 text-primary">Pest Control Services in George Town, Chennai</h2>
        <p className="mb-4">
          Looking for pest control services in George Town, Chennai? We offer professional pest management solutions to
          keep your home and business pest-free. Our expert team provides effective treatments for all types of pest
          infestations.
        </p>

        <h3 className="text-2xl font-semibold mt-8 mb-4 text-primary">Our Pest Control Services in George Town:</h3>
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>🪳 Cockroach Control</li>
          <li>🐜 Termite Control</li>
          <li>🐀 Rodent Control</li>
          <li>🦟 Mosquito Control</li>
          <li>🛏 Bed Bug Treatment</li>
          <li>🌿 Organic Pest Control</li>
          <li>💼 Commercial Pest Control</li>
        </ul>
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">Why Choose Us for Pest Control in George Town?</h3>
        <BenefitsSection
          benefits={[
            "Certified Experts – Skilled and experienced pest control technicians",
            "Affordable Pricing – Quality services at competitive rates",
            "Safe & Effective – Eco-friendly pest control solutions for peace of mind",
            "Available 24/7 – Quick response for urgent pest issues",
            "Highly Recommended – Trusted by residents and businesses in George Town, Chennai",
          ]}
        />
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">Areas We Serve in and Around George Town, Chennai:</h3>
        <ul className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <li className="bg-gray-100 p-3 rounded-lg text-center">George Town</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Parrys</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Broadway</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Mannady</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Sowcarpet</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Mint</li>
        </ul>
      </motion.section>

      <ProcessSection />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Contact Us for Pest Control in George Town, Chennai:
        </h3>
        <div className="bg-gray-100 p-6 rounded-lg mb-8">
          <p className="mb-2">
            <strong>📱 Call:</strong> +91 7558108600
          </p>
          <p className="mb-2">
            <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
          </p>
          <p>
            <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-xl font-semibold mb-4 text-primary">Request a Free Quote</h4>
          <ContactForm onSubmitSuccess={handleFormSubmit} location="George Town" />
          {isFormSubmitted && (
            <p className="mt-4 text-green-600 font-medium">
              Thank you for your inquiry! Our team will contact you shortly with a free quote for pest control services
              in George Town.
            </p>
          )}
        </div>
      </motion.section>
    </div>
  )
}
