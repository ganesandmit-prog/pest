import type { Metadata } from "next"
import KattupakkamPestControlClient from "./KattupakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Kattupakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kattupakkam, Chennai. Effective solutions for cockroaches, mosquitoes, termites, bed bugs & more. Call us for a pest-free home!",
  keywords:
    "pest control Kattupakkam, Kattupakkam pest services, cockroach control Kattupakkam, termite treatment Kattupakkam, mosquito control Kattupakkam, bed bug treatment Kattupakkam, residential pest control Kattupakkam, commercial pest control Kattupakkam, pest management Kattupakkam, No.1 Quality Pest Control Kattupakkam",
}

export default function KattupakkamPestControlPage() {
  return <KattupakkamPestControlClient />
}
