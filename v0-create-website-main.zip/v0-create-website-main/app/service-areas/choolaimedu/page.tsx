import type { Metadata } from "next"
import ChoolaimedupestControlClient from "./ChoolaimedupestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Choolaimedu | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Choolaimedu, Chennai. Safe, reliable & affordable solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Choolaimedu, pest control services Choolaimedu, Choolaimedu pest control, cockroach control Choolaimedu, termite control Choolaimedu, bed bug control Choolaimedu, rodent control Choolaimedu",
}

export default function ChoolaimedupestControl() {
  return <ChoolaimedupestControlClient />
}
