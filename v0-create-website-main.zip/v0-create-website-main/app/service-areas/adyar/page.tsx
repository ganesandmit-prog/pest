import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Adyar Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Adyar? No.1 Quality Pest Control offers reliable, safe, and affordable pest control services in Adyar Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function AdyarPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Adyar Chennai"
        subtitle="Professional & Affordable Pest Control Services in Adyar"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Adyar</h2>
            <p className="mb-4">
              Are you searching for professional pest control in Adyar? You're in the right place! At No.1 Quality Pest
              Control, we offer reliable, safe, and affordable pest control services in Adyar Chennai, ensuring your
              home or office stays 100% pest-free.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Top-Rated Pest Control Adyar Services</h2>
            <p className="mb-4">
              We are the #1 pest control company in Adyar, known for delivering effective pest control treatments for:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🪳 Cockroaches</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐜 Ants</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐀 Rodents</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🕷️ Spiders</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐛 Termites</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🦟 Mosquitoes</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐞 All Common Household Pests</div>
            </div>
            <p>
              Whether it's your house, apartment, shop, office, or restaurant — our professional pest control services
              in Adyar are tailored for complete protection at the best price.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Why Choose Our Pest Control in Adyar?</h2>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Experienced Professionals</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Safe for Kids & Pets</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Odor-Free Pest Treatments</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Best Price in Adyar Chennai</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>100% Customer Satisfaction</span>
              </li>
            </ul>
            <p className="mt-4">
              We specialize in control services using eco-friendly products, ensuring your family's health and safety
              while eliminating pests permanently.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call Now:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Adyar</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <h3 className="text-xl font-bold text-dark-green mb-2">🪳 Cockroach Control in Adyar</h3>
                <p>
                  Dealing with cockroaches in your kitchen or washroom? Our advanced cockroach pest control in Adyar
                  eliminates them from every corner. Say goodbye to cockroach infestations with our best pest control
                  company in Adyar.
                </p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <h3 className="text-xl font-bold text-dark-green mb-2">🐛 Termite Treatment in Adyar</h3>
                <p>
                  Protect your wooden furniture, wardrobes, and doors with our anti-termite pest control services in
                  Adyar Chennai. We use professional termites treatment methods that ensure long-term protection.
                </p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Pest Control Services in Adyar Include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Home Pest Control Adyar</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Office Pest Control Services</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Commercial Pest Control</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Termite Treatment Adyar Chennai</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Cockroach Control Adyar</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Pests Control Service for All</span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Pest Control Near You in Adyar Chennai</h2>
            <p className="mb-4">We proudly serve:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Adyar</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Besant Nagar</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Indira Nagar</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Thiruvanmiyur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">RA Puram</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Mylapore</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Teynampet</div>
            </div>
            <p className="mt-4">
              Looking for "pest control Adyar" or "Adyar Chennai pest control service"? You've found the best!
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Book Now: Professional Pest Control in Adyar</h2>
            <p className="mb-4">Want quick, affordable, and professional pest control near you?</p>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
              <div className="flex items-center">
                <span className="font-bold mr-2">💬 WhatsApp:</span>
                <a href="https://wa.me/917558108600" className="text-light-green hover:underline">
                  Instant Quote & Booking
                </a>
              </div>
            </div>
            <div>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.8}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Adyar
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
