"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { MapPin, Phone, Mail, Clock, CheckCircle } from "lucide-react"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"
import { AnimatedSection, FadeInStagger } from "@/components/framer-animations"

export function NolamburPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Pest Control Services in Nolambur, Chennai"
        description="Professional pest control services in Nolambur, Chennai. We offer termite control, cockroach control, and more at affordable prices."
      />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-gray-50 to-white py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <AnimatedSection animation="fadeIn">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold mb-4">
                    Reliable Pest Control Services in Nolambur, Chennai
                  </h1>
                  <p className="text-lg mb-6">
                    Are pests invading your home or office in Nolambur, Chennai? No.1 Quality Pest Control offers
                    professional and affordable pest control services tailored for Nolambur residents and businesses.
                  </p>
                  <p className="text-lg mb-6">
                    Our expert team provides effective solutions for every kind of pest problem. From termite control to
                    organic pest management, we ensure your spaces stay pest-free and safe for your family and
                    employees.
                  </p>
                  <div className="flex flex-wrap gap-4 mb-8">
                    <Link href="/contact-us">
                      <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        Get Free Quote
                      </motion.button>
                    </Link>
                    <Link href="tel:+917558108600">
                      <motion.button className="btn-outline" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        Call Us Now
                      </motion.button>
                    </Link>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pest-control-nolambur-Yx9Ij9Ij9Ij9Ij9Ij9.jpg"
                    alt="Pest Control Service in Nolambur"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Our Pest Control Solutions in Nolambur Include</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FadeInStagger>
                {[
                  {
                    title: "Termite Control & Treatment",
                    description:
                      "Comprehensive termite inspection and treatment to protect your property from structural damage.",
                  },
                  {
                    title: "Rodent & Cockroach Control",
                    description: "Effective elimination of rodents and cockroaches using safe and targeted methods.",
                  },
                  {
                    title: "Mosquito Management",
                    description: "Reduce mosquito populations around your property with our specialized treatments.",
                  },
                  {
                    title: "Eco-Friendly Organic Pest Solutions",
                    description: "Environmentally friendly pest control options that are safe for families and pets.",
                  },
                  {
                    title: "Residential Pest Control",
                    description: "Customized pest management solutions for homes and residential properties.",
                  },
                  {
                    title: "Commercial Pest Control",
                    description:
                      "Professional pest control services for offices, restaurants, and commercial establishments.",
                  },
                ].map((service, index) => (
                  <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                    <motion.div
                      className="bg-white p-6 rounded-lg shadow-md h-full"
                      whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                    >
                      <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                      <p className="text-gray-600">{service.description}</p>
                    </motion.div>
                  </AnimatedSection>
                ))}
              </FadeInStagger>
            </div>

            <AnimatedSection animation="fadeIn" delay={0.5}>
              <div className="text-center mt-8">
                <p className="text-lg mb-4">
                  We use government-approved chemicals and modern techniques to deliver lasting results with minimal
                  disruption.
                </p>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-12">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Serving Nolambur and Nearby Areas</h2>
            </AnimatedSection>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              {["Nolambur, Chennai", "Poonamallee", "Thirumazhisai", "Kundrathur", "Mogappair", "Valasaravakkam"].map(
                (area, index) => (
                  <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                    <div className="bg-gray-50 p-4 rounded-lg text-center">
                      <MapPin className="h-5 w-5 mx-auto mb-2 text-dark-green" />
                      <p>{area}</p>
                    </div>
                  </AnimatedSection>
                ),
              )}
            </div>

            <AnimatedSection animation="fadeIn" delay={0.5}>
              <div className="text-center">
                <p className="text-lg">
                  Join 1000+ satisfied clients who trust us on Sulekha Chennai for dependable pest control services!
                </p>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Why Choose No.1 Quality Pest Control in Nolambur?</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "40+ Years of Industry Experience",
                  description: "Benefit from our decades of expertise in pest management.",
                },
                {
                  title: "Certified Pest Control Experts",
                  description: "Our technicians are trained and certified in the latest pest control methods.",
                },
                {
                  title: "Transparent Pricing",
                  description: "Clear pricing with no hidden charges or surprise fees.",
                },
                {
                  title: "Fast, Reliable, and Safe Solutions",
                  description: "Quick response times and effective treatments that are safe for your family.",
                },
                {
                  title: "Customized Pest Control Plans",
                  description: "Tailored solutions designed to address your specific pest problems.",
                },
                {
                  title: "Satisfaction Guaranteed",
                  description: "We're not satisfied until your pest problem is completely resolved.",
                },
              ].map((benefit, index) => (
                <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                  <motion.div
                    className="bg-white p-6 rounded-lg shadow-md h-full"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  >
                    <div className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                        <p className="text-gray-600">{benefit.description}</p>
                      </div>
                    </div>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Customer Feedback</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <AnimatedSection animation="fadeIn" delay={0.1}>
                <motion.div
                  className="bg-white p-6 rounded-lg shadow-md border-l-4 border-dark-green"
                  whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                >
                  <p className="italic mb-4">
                    "Fast and effective termite treatment in Nolambur. Very professional service!"
                  </p>
                  <p className="font-bold">— Ramesh K., Nolambur Resident</p>
                </motion.div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <motion.div
                  className="bg-white p-6 rounded-lg shadow-md border-l-4 border-dark-green"
                  whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                >
                  <p className="italic mb-4">
                    "Great organic pest control service that's safe for my kids and pets. Highly recommended!"
                  </p>
                  <p className="font-bold">— Meena S., Chennai</p>
                </motion.div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Get Your Pest Problem Solved Today!</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="fadeIn" delay={0.1}>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <MapPin className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>Nolambur, Chennai</p>
                    </div>
                    <div className="flex items-start">
                      <Phone className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>
                        <a href="tel:+917558108600" className="hover:underline">
                          +91 75581 08600
                        </a>
                      </p>
                    </div>
                    <div className="flex items-start">
                      <Mail className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>
                        <a href="mailto:no1qualitypestcontrol@gmail.com" className="hover:underline">
                          no1qualitypestcontrol@gmail.com
                        </a>
                      </p>
                    </div>
                    <div className="flex items-start">
                      <Clock className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>Available 24/7 for emergency pest control services</p>
                    </div>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </section>

        <ServicesList />
        <BenefitsSection />
        <TestimonialsSection />
      </main>
    </div>
  )
}

export default NolamburPestControlClient
