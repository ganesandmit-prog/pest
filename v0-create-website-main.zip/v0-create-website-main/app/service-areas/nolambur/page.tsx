import type { Metadata } from "next"
import NolamburPestControlClient from "./NolamburPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nolambur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nolambur, Chennai. We offer termite control, cockroach control, and more at affordable prices.",
  keywords:
    "pest control Nolambur, termite control Nolambur, cockroach control Nolambur, pest management Chennai, Nolambur pest services, residential pest control, commercial pest control",
}

export default function NolamburPage() {
  return <NolamburPestControlClient />
}
