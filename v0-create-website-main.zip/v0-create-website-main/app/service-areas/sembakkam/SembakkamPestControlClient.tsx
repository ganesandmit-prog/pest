"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SembakkamPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Sembakkam, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Pest Control in Sembakkam – Trusted Pest Control Services in Sembakkam, Chennai
              </h1>

              <div className="prose max-w-none">
                <p>
                  Are you looking for reliable pest control services in Sembakkam, Chennai? Our professional team
                  provides fast, effective, and eco-friendly solutions to safeguard your home and business from pests.
                  Whether you need general pest control, cockroach removal, or specialized treatments, we have the right
                  solution for you!
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐜 Our Pest Control Services in Sembakkam Include:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control – Effective treatment and prevention methods</li>
                  <li>🐜 General Pest Control – Eliminate all kinds of pests from your property</li>
                  <li>🦟 Mosquito Control – Keep mosquitoes at bay with our proven solutions</li>
                  <li>🐀 Rodent Control – Safe and humane methods to remove rodents</li>
                  <li>🌱 Eco-Friendly Pest Solutions – Safe for pets and children</li>
                  <li>🧹 Post-Treatment Cleaning – Ensuring a hygienic and pest-free space</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  💡 Why Choose Our Pest Control Service in Sembakkam?
                </h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Experienced Professionals – Trained and certified pest control experts</li>
                  <li>✔️ Affordable Pricing – Transparent rates with no hidden costs</li>
                  <li>✔️ Fast Response – Same-day service for urgent pest issues</li>
                  <li>✔️ Top Reviews – Trusted by residents in Sembakkam and Chennai</li>
                  <li>✔️ Eco-Friendly Solutions – Green methods that are safe for your family and pets</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 We Serve Sembakkam & Nearby Areas:</h2>

                <ul className="list-none space-y-2">
                  <li>Sembakkam, Chennai</li>
                  <li>Madipakkam</li>
                  <li>Tambaram</li>
                  <li>Pallavaram</li>
                  <li>Perungalathur</li>
                  <li>Velachery</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact Us for Pest Control in Sembakkam!</h3>
                  <p>
                    Protect your property with the best pest control services in Sembakkam. Call today to schedule an
                    inspection!
                  </p>
                  <p className="mt-4">
                    📱 Call Now: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
