import type { Metadata } from "next"
import MandaveliPestControlClient from "./MandaveliPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Mandaveli | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mandaveli, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Mandaveli, pest control services Mandaveli, cockroach control Mandaveli, termite control Mandaveli, rodent control Mandaveli, bed bug treatment Mandaveli, pest control Chennai, No.1 Quality Pest Control",
}

export default function MandaveliPage() {
  return <MandaveliPestControlClient />
}
