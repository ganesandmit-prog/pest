import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import GuindyPestControlClient from "./GuindyPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Guindy, Chennai | No.1 Quality Pest Control",
  description:
    "Trusted pest control solutions in Guindy, Chennai. We offer professional pest management to protect your home and office from harmful pests with safe and efficient treatments.",
  keywords:
    "pest control Guindy, Guindy pest services, cockroach control Guindy, termite treatment Guindy, rodent control Guindy, mosquito control Guindy, bed bug treatment Guindy, commercial pest control Guindy, Chennai pest control",
}

export default function GuindyPage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Best Pest Control in Guindy, Chennai"
        description="Trusted Pest Control Solutions for homes and businesses"
      />
      <GuindyPestControlClient />
    </main>
  )
}
