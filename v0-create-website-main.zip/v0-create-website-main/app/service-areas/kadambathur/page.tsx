import type { Metadata } from "next"
import KadambathurPestControlClient from "./KadambathurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Kadambathur | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kadambathur, Thiruvallur. High-quality, eco-friendly solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Kadambathur, pest control services Kadambathur, Kadambathur pest control, cockroach control Kadambathur, termite control Kadambathur, bed bug control Kadambathur, rodent control Kadambathur",
}

export default function KadambathurPestControl() {
  return <KadambathurPestControlClient />
}
