import type { Metadata } from "next"
import { TeynampetPestControlClient } from "./TeynampetPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Teynampet, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Teynampet, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Teynampet, Teynampet pest services, pest management Teynampet, pest control near me, No.1 Quality Pest Control Teynampet, cockroach control Teynampet, termite treatment Teynampet, bed bug control Teynampet",
}

export default function TeynampetPage() {
  return <TeynampetPestControlClient />
}
