import type { Metadata } from "next"
import JafferkhanpetPestControlClient from "./JafferkhanpetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Jafferkhanpet | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Jafferkhanpet, Chennai. Effective, safe & affordable solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Jafferkhanpet, pest control services Jafferkhanpet, Jafferkhanpet pest control, cockroach control Jafferkhanpet, termite control Jafferkhanpet, bed bug control Jafferkhanpet, rodent control Jafferkhanpet",
}

export default function JafferkhanpetPestControl() {
  return <JafferkhanpetPestControlClient />
}
