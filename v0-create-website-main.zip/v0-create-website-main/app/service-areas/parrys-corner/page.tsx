import type { Metadata } from "next"
import { ParrysCornerPestControlClient } from "./ParrysCornerPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Parry's Corner – Trusted Experts at Your Service!",
  description:
    "Looking for professional pest control services in Parry's Corner? We provide fast, reliable, and eco-friendly solutions for residential and commercial spaces in Chennai.",
}

export default function ParrysCornerPage() {
  return <ParrysCornerPestControlClient />
}
