"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function MadhavaramPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control in Madhavaram, Chennai" subtitle="Safe & Effective Solutions" />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Searching for trusted pest control services in Madhavaram Chennai? Look no further! Our team at Shiva
                Sai Pest Control provides expert pest control solutions designed to eliminate pests safely and
                efficiently. We specialize in organic pest management, ensuring your home or office remains clean and
                pest-free.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🐜 Our Top Pest Control Services in Madhavaram:
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Quick and long-lasting relief
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Control</strong> – Safe treatment to protect your property
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Stop mosquitoes before they spread diseases
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent & Rat Control</strong> – Reliable removal of rodents
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Treatment</strong> – Effective and discreet services
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🌿</span>
                    <span>
                      <strong>Organic Pest Solutions</strong> – Eco-friendly & child-safe options
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Our Pest Control in Madhavaram?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Trusted by thousands on Sulekha Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>100% Safe & Certified Organic Pest Control</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Fast, Reliable & Affordable Pest Services</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Experienced Team & Licensed Professionals</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Customized Control Services for Homes & Businesses</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Serving Residential, Commercial & Industrial Properties</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 Areas We Serve Near Madhavaram:</h2>
                <p className="mb-4">Perambur | Kolathur | Retteri | Red Hills | Manali | Korattur</p>
              </div>

              <div className="bg-gray-100 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">⭐ Customer Reviews</h2>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 mb-4">
                  "Excellent pest control service in Madhavaram. The team was punctual, and the results were amazing."
                  <footer className="text-right font-semibold mt-2">– Ravi S., Resident of Madhavaram</footer>
                </blockquote>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2">
                  "Tried their termite control – highly recommend Shiva Sai Pest Control!"
                  <footer className="text-right font-semibold mt-2">
                    – Preethi M., Owner of a retail store in Chennai
                  </footer>
                </blockquote>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">📞 Contact the Best Pest Control in Madhavaram Today!</h2>
                <p className="mb-2">
                  📱 Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Website: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
                <p>📍 Location: Madhavaram, Chennai Tamil Nadu</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🏡 Don't let pests take over your property! Contact our expert team today for professional pest
                  control services in Madhavaram, Chennai. We're here to help you maintain a clean, healthy, and
                  pest-free environment.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Madhavaram</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
