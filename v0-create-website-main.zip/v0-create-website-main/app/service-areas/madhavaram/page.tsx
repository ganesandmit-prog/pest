import type { Metadata } from "next"
import MadhavaramPestControlClient from "./MadhavaramPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Madhavaram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Madhavaram, Chennai. We offer cockroach control, termite treatment, rodent removal and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Madhavaram, pest control services Madhavaram, cockroach control Madhavaram, termite control Madhavaram, rodent control Madhavaram, bed bug treatment Madhavaram, pest control Chennai, No.1 Quality Pest Control",
}

export default function MadhavaramPage() {
  return <MadhavaramPestControlClient />
}
