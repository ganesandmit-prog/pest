import type { Metadata } from "next"
import ChepaukPestControlClient from "./ChepaukPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Chepauk | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Chepauk, Chennai. Safe, affordable, and effective solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Chepauk, pest control services Chepauk, Chepauk pest control, cockroach control Chepauk, termite control Chepauk, bed bug control Chepauk, rodent control Chepauk",
}

export default function ChepaukPestControl() {
  return <ChepaukPestControlClient />
}
