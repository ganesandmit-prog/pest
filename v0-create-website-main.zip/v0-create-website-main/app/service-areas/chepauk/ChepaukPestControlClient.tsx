"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function ChepaukPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Chepauk" subtitle="Safe, Reliable & Affordable" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Best Pest Control in Chepauk</h2>
                  <div className="prose max-w-none">
                    <p>
                      Looking for pest control in Chepauk that actually works? We're the #1 pest control service in
                      Chepauk, trusted by hundreds of homeowners and businesses across Chennai. Whether it's cockroach
                      control, termite treatment, or general pest control, we've got you covered with proven, eco-safe
                      solutions.
                    </p>
                    <h3>Our Pest Control Services Include:</h3>
                    <ul>
                      <li>General Pest Control (Cockroach, Ants, Lizards, Spiders)</li>
                      <li>Termite Control – Pre & Post Construction</li>
                      <li>Cockroach Control – Fast & Long-Lasting</li>
                      <li>Bed Bugs & Rodents</li>
                      <li>Cleaning & Sanitization Services</li>
                      <li>Residential & Commercial Pest Control in Chepauk</li>
                    </ul>
                    <h3>Why Choose Us?</h3>
                    <ul>
                      <li>Certified & Trained Experts</li>
                      <li>Safe & Odor-Free Chemicals</li>
                      <li>Fast, Same-Day Service in Chepauk</li>
                      <li>Affordable Pricing with Free Quote</li>
                      <li>Trusted by 1000+ Clients in Chennai</li>
                      <li>Excellent Reviews on Google & Justdial</li>
                    </ul>
                    <h3>Service Areas Around Chepauk:</h3>
                    <ul>
                      <li>Chepauk</li>
                      <li>Triplicane</li>
                      <li>Marina</li>
                      <li>Mount Road</li>
                      <li>Royapettah</li>
                      <li>Egmore</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Chepauk"
            benefits={[
              {
                title: "Safe & Eco-Friendly",
                description:
                  "We use environmentally friendly products that are safe for your family, pets, and the environment.",
                icon: "Shield",
              },
              {
                title: "Experienced Team",
                description:
                  "Our technicians have years of experience in handling all types of pest infestations in Chepauk.",
                icon: "Users",
              },
              {
                title: "Customized Solutions",
                description: "We provide tailored pest control plans based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Quick Response",
                description: "We offer same-day service for urgent pest control needs in Chepauk.",
                icon: "Clock",
              },
              {
                title: "Guaranteed Results",
                description: "We ensure effective pest elimination with our proven methods and follow-up services.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Chepauk"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Chepauk</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Chepauk home or business? Contact No.1 Quality Pest Control
                        today for a free inspection and quote. Our team of experienced professionals is ready to help
                        you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
