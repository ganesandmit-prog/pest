import type { Metadata } from "next"
import EgmorePestControlClient from "./EgmorePestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Egmore | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Egmore, Chennai. Fast & reliable solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Egmore, pest control services Egmore, Egmore pest control, cockroach control Egmore, termite control Egmore, bed bug control Egmore, rodent control Egmore",
}

export default function EgmorePestControl() {
  return <EgmorePestControlClient />
}
