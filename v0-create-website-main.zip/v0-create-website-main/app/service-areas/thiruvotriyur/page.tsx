import type { Metadata } from "next"
import ThiruvotriyurPestControlClient from "./ThiruvotriyurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Thiruvotriyur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thiruvotriyur, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with 45+ years of experience.",
  keywords:
    "pest control Thiruvotriyur, Thiruvotriyur pest services, cockroach control Thiruvotriyur, termite treatment Thiruvotriyur, bed bug control Thiruvotriyur, rodent control Thiruvotriyur, mosquito control Thiruvotriyur, pest management Thiruvotriyur Chennai",
}

export default function ThiruvotriyurPestControlPage() {
  return <ThiruvotriyurPestControlClient />
}
