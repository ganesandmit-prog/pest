"use client"
import { motion } from "framer-motion"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { fadeIn } from "@/components/framer-animations"

export default function MoolakadaiPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Pest Control in Moolakadai, Chennai - No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Moolakadai, Chennai. Affordable cockroach, termite, rodent & mosquito control with safe, eco-friendly solutions. Call now!"
        />
        <meta
          name="keywords"
          content="pest control Moolakadai, cockroach control Moolakadai, termite treatment Moolakadai, rodent control Chennai, mosquito control Moolakadai, bed bug treatment Chennai, pest control services Moolakadai"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/moolakadai" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Moolakadai",
              "description": "Professional pest control services in Moolakadai, Chennai including cockroach, termite, rodent and mosquito control with eco-friendly solutions.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/moolakadai",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Moolakadai",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.1212,
                "longitude": 80.2387
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "areaServed": ["Moolakadai", "Chennai", "Tamil Nadu"]
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Moolakadai"
        subtitle="Professional, Quick & Affordable Pest Solutions"
      />

      <div className="container mx-auto px-4 py-12">
        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-6 text-center">Trusted Pest Control Services in Moolakadai, Chennai</h2>
          <p className="text-lg mb-4">
            Looking for trusted pest control services in Moolakadai? You've found the best! At No.1 Quality Pest
            Control, we offer top-notch, reliable, and eco-friendly pest control in Moolakadai Chennai – all at prices
            that won't break the bank.
          </p>
          <p className="text-lg mb-4">
            From cockroach control in homes to rodent removal in warehouses, we've got Moolakadai covered with fast,
            effective solutions. 🏠🏭
          </p>
        </motion.div>

        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-2xl font-bold mb-6">Say Goodbye To Pests With Our Expert Services:</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🪳 Cockroach Control Services</h3>
              <p>
                Professional cockroach elimination using advanced techniques and safe chemicals to ensure complete
                removal.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🐀 Rodent & Mouse Removal</h3>
              <p>
                Effective rodent control solutions to eliminate mice and rats from your property with preventive
                measures.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🐜 Termite Treatment in Moolakadai</h3>
              <p>Comprehensive termite control services to protect your property from structural damage.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🦟 Mosquito & Fly Control</h3>
              <p>Effective mosquito and fly management to protect your family from disease-carrying insects.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🛏 Bed Bug Extermination</h3>
              <p>Complete bed bug removal services using specialized treatments for lasting results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🌿 Herbal & Organic Pest Control Options</h3>
              <p>Eco-friendly pest control solutions that are safe for your family, pets, and the environment.</p>
            </div>
          </div>
          <p className="mt-6 text-lg">
            We use only government-approved chemicals for safe indoor & outdoor pest removal.
          </p>
        </motion.div>

        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-2xl font-bold mb-6">Why People in Moolakadai Trust Us:</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ 10+ Years of Proven Expertise</h3>
              <p>With over a decade of experience, we've perfected our pest control techniques.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Certified Technicians & Eco-Friendly Treatments</h3>
              <p>Our team consists of trained professionals who use environmentally responsible methods.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Same-Day Appointments 🚀</h3>
              <p>We understand pest emergencies and offer prompt service when you need it most.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Residential & Warehouse Pest Control</h3>
              <p>Specialized solutions for both homes and commercial properties in Moolakadai.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Rates + Free Inspection 📞</h3>
              <p>Competitive pricing with no hidden charges and complimentary property assessment.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Listed on Sulekha Chennai with 5★ Reviews</h3>
              <p>Highly rated by satisfied customers across Chennai for our quality service.</p>
            </div>
          </div>
        </motion.div>

        <TestimonialsSection
          testimonials={[
            {
              quote: "Best pest control service in Moolakadai! They cleared out all cockroaches in one visit.",
              author: "Sathya R., Homeowner",
              rating: 5,
              location: "Moolakadai",
            },
            {
              quote: "They took care of termite control in my warehouse. Very professional.",
              author: "Rajesh K., Business Owner",
              rating: 5,
              location: "Moolakadai",
            },
          ]}
        />

        <motion.div
          className="mb-12 text-center"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-6">Contact No.1 Quality Pest Control – Moolakadai's Pest Experts</h2>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="mb-2">
              <strong>📍 Location:</strong> Moolakadai, Chennai, Tamil Nadu
            </p>
            <p className="mb-2">
              <strong>📞 Call Now:</strong>{" "}
              <a href="tel:+917558108600" className="text-blue-600 hover:underline">
                +91 75581 08600
              </a>
            </p>
            <p className="mb-2">
              <strong>📧 Email:</strong>{" "}
              <a href="mailto:no1qualitypestcontrol@gmail.com" className="text-blue-600 hover:underline">
                no1qualitypestcontrol@gmail.com
              </a>
            </p>
            <p className="mb-2">
              <strong>🌐 Website:</strong>{" "}
              <a
                href="https://www.no1qualitypestcontrol.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                www.no1qualitypestcontrol.com
              </a>
            </p>
          </div>
        </motion.div>

        <ProcessSection />
        <BenefitsSection />
        <ContactForm />
      </div>
    </>
  )
}
