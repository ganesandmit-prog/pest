import type { Metadata } from "next"
import MoolakadaiPestControlClient from "./MoolakadaiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Moolakadai, Chennai - No.1 Quality Pest Control",
  description:
    "Professional pest control services in Moolakadai, Chennai. Affordable cockroach, termite, rodent & mosquito control with safe, eco-friendly solutions. Call now!",
}

export default function MoolakadaiPage() {
  return <MoolakadaiPestControlClient />
}
