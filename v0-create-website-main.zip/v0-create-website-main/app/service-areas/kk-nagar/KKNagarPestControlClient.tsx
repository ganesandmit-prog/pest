"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KKNagarPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader
        title="Best Pest Control in K.K. Nagar, Chennai"
        subtitle="Expert Control Services for All Your Needs"
      />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Looking for pest control in K.K. Nagar? We are your go-to professionals for fast, affordable, and
                effective pest control services in K.K. Nagar, Chennai. Whether you're dealing with cockroaches,
                termites, rats, mosquitoes, or bed bugs, our expert team provides trusted control services that ensure a
                clean and pest-free environment.
              </p>
              <p className="text-lg mb-6">
                We are known for our top-rated Chennai pest control solutions, offering customized treatments for homes,
                offices, and commercial spaces. Our mission? To deliver safe, long-lasting, and eco-friendly pest
                removal that suits your budget and specific needs.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🛠 Pest Control Services in K.K. Nagar, Chennai
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Treatment</strong> – Protect your wooden furniture and structures.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Prevent diseases like dengue and malaria.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent & Rat Control</strong> – Keep your premises rodent-free.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Removal</strong> – Sleep peacefully with our proven solutions.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Eliminate hidden pests in your kitchen and bathrooms.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest Control</strong> – For all-round pest management services.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Our Pest Control Experts in K.K. Nagar?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Trusted control services in K.K. Nagar and Nagar Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Certified & Experienced Technicians</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Eco-friendly and Child-safe Treatments</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Affordable Pricing – No Hidden Charges</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Fast Response and Guaranteed Results</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Serving Residential & Commercial Clients</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Leading Name in Chennai Pest Control</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 Areas We Serve Near K.K. Nagar:</h2>
                <p className="mb-4">
                  Ashok Nagar | Vadapalani | Nesapakkam | Kodambakkam | T. Nagar | West Mambalam | All over Nagar
                  Chennai
                </p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">📞 Book Pest Control in K.K. Nagar Today!</h2>
                <p className="mb-2">
                  📱 Call:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p>
                  🌐 Website: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🛡️ Whether you're in K.K. Nagar or anywhere in Chennai, we offer top-notch pest control services
                  tailored to your exact needs. Choose our expert control services in Nagar Chennai and experience the
                  best in Chennai pest control. We're your local, reliable partner in keeping pests away for good.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in K.K. Nagar</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
