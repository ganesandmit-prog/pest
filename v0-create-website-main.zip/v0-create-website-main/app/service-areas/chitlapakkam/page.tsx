import type { Metadata } from "next"
import ChitlapakkamPestControlClient from "./ChitlapakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Chitlapakkam | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Chitlapakkam, Chennai. Safe, reliable & affordable solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Chitlapakkam, pest control services Chitlapakkam, Chitlapakkam pest control, cockroach control Chitlapakkam, termite control Chitlapakkam, bed bug control Chitlapakkam, rodent control Chitlapakkam",
}

export default function ChitlapakkamPestControl() {
  return <ChitlapakkamPestControlClient />
}
