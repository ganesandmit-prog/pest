"use client"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { FadeInStagger } from "@/components/framer-animations"
import { ScrollToTop } from "@/components/scroll-to-top"

export function OtteriPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <ScrollToTop />

      <PageHeader
        title="Pest Control Services in Otteri, Chennai"
        description="Professional and affordable pest control solutions for residential and commercial properties in Otteri"
      />

      <main className="flex-grow container mx-auto px-4 py-8">
        <FadeInStagger>
          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Pest Control Services in Otteri</h2>
            <div className="prose max-w-none">
              <p>
                No.1 Quality Pest Control provides comprehensive pest management solutions to residents and businesses
                in Otteri, Chennai. With over 45 years of experience, our team of certified technicians delivers
                effective and safe pest control services to eliminate all types of pests including termites,
                cockroaches, bed bugs, rodents, and more.
              </p>
              <p>
                Otteri is a residential area in Chennai that can face various pest problems due to the tropical climate
                and urban environment. Our customized pest control treatments are designed to address the specific pest
                challenges faced by Otteri residents, ensuring your home or business remains pest-free throughout the
                year.
              </p>
            </div>
          </section>

          <ServicesList />

          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Why Choose Our Pest Control Services in Otteri?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">Local Expertise</h3>
                <p>
                  Our technicians are familiar with the pest challenges specific to Otteri and surrounding areas,
                  allowing us to provide targeted solutions.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">Quick Response</h3>
                <p>
                  We offer prompt service to Otteri residents, with emergency pest control available when you need it
                  most.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">Affordable Pricing</h3>
                <p>
                  Our pest control services in Otteri are competitively priced with transparent quotes and no hidden
                  charges.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">Eco-Friendly Solutions</h3>
                <p>
                  We use environmentally responsible pest control methods that are safe for your family, pets, and the
                  environment.
                </p>
              </div>
            </div>
          </section>

          <BenefitsSection />

          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Pest Control Process in Otteri</h2>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">1. Inspection</h3>
                <p>
                  Our technicians conduct a thorough inspection of your property in Otteri to identify pest entry
                  points, nesting areas, and the extent of infestation.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">2. Customized Treatment Plan</h3>
                <p>
                  Based on the inspection findings, we develop a tailored pest control plan specific to your Otteri
                  property's needs.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">3. Implementation</h3>
                <p>
                  Our certified technicians execute the treatment plan using advanced equipment and effective pest
                  control products.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-3">4. Follow-up & Prevention</h3>
                <p>
                  We provide follow-up visits to ensure complete pest elimination and offer preventive measures to keep
                  your Otteri property pest-free.
                </p>
              </div>
            </div>
          </section>

          <TestimonialsSection />

          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">How often should I get pest control done in Otteri?</h3>
                <p>
                  For residential properties in Otteri, we recommend quarterly pest control treatments to maintain a
                  pest-free environment. Commercial properties may require more frequent treatments depending on the
                  nature of the business.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Are your pest control methods safe for children and pets?
                </h3>
                <p>
                  Yes, we use child and pet-friendly pest control methods in Otteri homes. Our technicians will advise
                  on any precautions to take during and after treatment.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Do you provide warranty for your pest control services in Otteri?
                </h3>
                <p>
                  Yes, we offer service warranties for our pest control treatments in Otteri. The warranty period varies
                  depending on the type of pest control service.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  How quickly can you respond to pest emergencies in Otteri?
                </h3>
                <p>
                  We understand the urgency of pest problems and strive to provide same-day or next-day service for pest
                  emergencies in Otteri.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Contact Us for Pest Control in Otteri</h2>
            <ContactForm />
          </section>
        </FadeInStagger>
      </main>
    </div>
  )
}
