import type { Metadata } from "next"
import { OtteriPestControlClient } from "./OtteriPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Otteri, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Otteri, Chennai. We offer termite control, cockroach control, and more at affordable prices.",
  keywords:
    "pest control Otteri, termite control Otteri, cockroach control Otteri, bed bug control Otteri, rodent control Otteri, pest management Otteri Chennai, affordable pest control Otteri",
}

export default function OtteriPage() {
  return <OtteriPestControlClient />
}
