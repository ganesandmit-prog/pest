import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import InjambakkamPestControlClient from "./InjambakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Injambakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Trusted pest management solutions in Injambakkam, Chennai. We offer expert pest control services to keep your home and business free from pests with specialized treatments.",
  keywords:
    "pest control Injambakkam, Injambakkam pest services, cockroach control Injambakkam, termite treatment Injambakkam, rodent control Injambakkam, mosquito control Injambakkam, bed bug treatment Injambakkam, commercial pest control Injambakkam, Chennai pest control",
}

export default function InjambakkamPage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Best Pest Control in Injambakkam, Chennai"
        description="Trusted Pest Management Solutions for homes and businesses"
      />
      <InjambakkamPestControlClient />
    </main>
  )
}
