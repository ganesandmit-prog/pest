import type { Metadata } from "next"
import NoombalPestControlClient from "./NoombalPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Noombal, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Noombal, Chennai. We offer termite control, cockroach control, and more at affordable prices.",
  keywords:
    "pest control Noombal, termite control Noombal, cockroach control Noombal, pest management Chennai, Noombal pest services, residential pest control, commercial pest control",
}

export default function NoombalPage() {
  return <NoombalPestControlClient />
}
