"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Check, Phone, MapPin, Clock, Shield, Award, ThumbsUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import ContactForm from "@/components/contact-form"
import { AnimatedSection } from "@/components/framer-animations"

export default function KarapakkamPestControlClient() {
  const [activeTab, setActiveTab] = useState("residential")

  return (
    <>
      {/* Hero Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold mb-4 text-dark-green">
                  Professional Pest Control Services in Karapakkam, Chennai
                </h1>
                <p className="text-lg mb-6 text-gray-700">
                  No.1 Quality Pest Control provides comprehensive pest management solutions for homes and businesses in
                  Karapakkam. Our 45+ years of experience ensures effective and long-lasting pest control.
                </p>
                <div className="space-y-4 mb-8">
                  {[
                    "Residential & Commercial Pest Control",
                    "Child & Pet-Friendly Treatments",
                    "Eco-Friendly Solutions",
                    "Licensed & Certified Technicians",
                    "100% Satisfaction Guarantee",
                  ].map((item, index) => (
                    <div key={index} className="flex items-start">
                      <Check className="h-6 w-6 text-light-green mr-3 mt-1 flex-shrink-0" />
                      <p>{item}</p>
                    </div>
                  ))}
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <a href="tel:+917558108600" className="btn-primary flex items-center justify-center gap-2">
                    <Phone className="h-5 w-5" /> Call Us Now
                  </a>
                  <Link href="#contact-form">
                    <button className="btn-secondary w-full sm:w-auto">Get Free Quote</button>
                  </Link>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Pest Control Service in Karapakkam"
                  width={600}
                  height={500}
                  className="w-full h-auto object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Our Pest Control Services in Karapakkam</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                We offer a wide range of pest control services to keep your home or business pest-free. Our treatments
                are effective, safe, and tailored to your specific needs.
              </p>
            </div>
          </AnimatedSection>

          <div className="flex justify-center mb-10">
            <div className="inline-flex rounded-md shadow-sm bg-white p-1">
              <button
                onClick={() => setActiveTab("residential")}
                className={`px-4 py-2 text-sm font-medium rounded-md ${
                  activeTab === "residential" ? "bg-light-green text-white" : "bg-white text-gray-700 hover:bg-gray-100"
                }`}
              >
                Residential
              </button>
              <button
                onClick={() => setActiveTab("commercial")}
                className={`px-4 py-2 text-sm font-medium rounded-md ${
                  activeTab === "commercial" ? "bg-light-green text-white" : "bg-white text-gray-700 hover:bg-gray-100"
                }`}
              >
                Commercial
              </button>
            </div>
          </div>

          {activeTab === "residential" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Cockroach Control",
                  description:
                    "Eliminate cockroach infestations with our targeted treatments that reach deep into hiding places.",
                  link: "/services/cockroach-control",
                },
                {
                  title: "Mosquito Control",
                  description:
                    "Protect your family from mosquito-borne diseases with our effective mosquito control solutions.",
                  link: "/services/mosquito-control",
                },
                {
                  title: "Termite Control",
                  description:
                    "Prevent costly structural damage with our comprehensive termite inspection and treatment services.",
                  link: "/services/termite-control",
                },
                {
                  title: "Bed Bug Treatment",
                  description: "Get rid of bed bugs completely with our specialized heat and chemical treatments.",
                  link: "/services/bed-bug-control",
                },
                {
                  title: "Rodent Control",
                  description:
                    "Keep rats and mice away from your home with our humane and effective rodent control methods.",
                  link: "/services/rodent-control",
                },
                {
                  title: "Ant Control",
                  description: "Eliminate ant colonies at the source with our targeted ant control treatments.",
                  link: "/pest-library/ant-control",
                },
              ].map((service, index) => (
                <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                  <motion.div className="bg-white p-6 rounded-lg shadow-md h-full flex flex-col" whileHover={{ y: -5 }}>
                    <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                    <p className="text-gray-700 mb-4 flex-grow">{service.description}</p>
                    <Link href={service.link} className="text-light-green font-medium hover:underline">
                      View Details →
                    </Link>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Office Pest Control",
                  description:
                    "Maintain a pest-free work environment with our discreet and effective office pest control services.",
                  link: "/commercial",
                },
                {
                  title: "Restaurant Pest Management",
                  description:
                    "Comply with health regulations and protect your reputation with our restaurant pest control solutions.",
                  link: "/commercial",
                },
                {
                  title: "Warehouse Pest Control",
                  description:
                    "Protect your inventory and meet safety standards with our warehouse pest management programs.",
                  link: "/commercial",
                },
                {
                  title: "Hotel Pest Control",
                  description:
                    "Safeguard your guests and reputation with our discreet and thorough hotel pest control services.",
                  link: "/commercial",
                },
                {
                  title: "School & Hospital Pest Management",
                  description:
                    "Create a safe and healthy environment with our specialized pest control for sensitive facilities.",
                  link: "/commercial",
                },
                {
                  title: "Retail Store Pest Control",
                  description:
                    "Protect your merchandise and customer experience with our retail pest management solutions.",
                  link: "/commercial",
                },
              ].map((service, index) => (
                <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                  <motion.div className="bg-white p-6 rounded-lg shadow-md h-full flex flex-col" whileHover={{ y: -5 }}>
                    <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                    <p className="text-gray-700 mb-4 flex-grow">{service.description}</p>
                    <Link href={service.link} className="text-light-green font-medium hover:underline">
                      View Details →
                    </Link>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Choose No.1 Quality Pest Control in Karapakkam?</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                With over 45 years of experience serving Karapakkam and surrounding areas, we deliver reliable and
                effective pest control solutions.
              </p>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Shield className="h-10 w-10 text-light-green" />,
                title: "Safe & Eco-Friendly",
                description:
                  "We use environmentally responsible products that are effective against pests but safe for your family, pets, and the environment.",
              },
              {
                icon: <Award className="h-10 w-10 text-light-green" />,
                title: "Certified Technicians",
                description:
                  "Our pest control experts are fully licensed, insured, and trained in the latest pest management techniques.",
              },
              {
                icon: <ThumbsUp className="h-10 w-10 text-light-green" />,
                title: "Guaranteed Results",
                description:
                  "We stand behind our work with a satisfaction guarantee. If pests return, so do we – at no additional cost.",
              },
              {
                icon: <Clock className="h-10 w-10 text-light-green" />,
                title: "Prompt Service",
                description:
                  "We offer flexible scheduling and prompt service to address your pest concerns quickly and efficiently.",
              },
              {
                icon: <MapPin className="h-10 w-10 text-light-green" />,
                title: "Local Expertise",
                description:
                  "As a Chennai-based company, we understand the unique pest challenges faced by Karapakkam residents and businesses.",
              },
              {
                icon: <Check className="h-10 w-10 text-light-green" />,
                title: "Customized Solutions",
                description:
                  "We develop tailored pest control plans based on your specific situation, property type, and the pests you're facing.",
              },
            ].map((feature, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-gray-700">{feature.description}</p>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Karapakkam-Specific Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight">
              <div>
                <h2 className="text-3xl font-bold mb-4">Pest Control Solutions for Karapakkam Residents</h2>
                <p className="text-lg mb-6 text-gray-700">
                  Karapakkam, located along the IT Corridor in Chennai, faces unique pest challenges due to its
                  proximity to water bodies and rapid urban development. Our specialized pest control services address
                  these specific concerns:
                </p>
                <div className="space-y-4 mb-8">
                  {[
                    "Specialized mosquito control for areas near Buckingham Canal and marshlands",
                    "Termite prevention for new constructions and existing buildings",
                    "Rodent control solutions for residential apartments and commercial complexes",
                    "Cockroach management for food establishments and residential kitchens",
                    "Comprehensive pest management for IT parks and office buildings",
                  ].map((item, index) => (
                    <div key={index} className="flex items-start">
                      <Check className="h-6 w-6 text-light-green mr-3 mt-1 flex-shrink-0" />
                      <p>{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Pest Control in Karapakkam"
                  width={600}
                  height={500}
                  className="w-full h-auto object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">What Our Karapakkam Customers Say</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                Don't just take our word for it. Here's what our satisfied customers in Karapakkam have to say about our
                pest control services.
              </p>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Ramesh Kumar",
                location: "Karapakkam",
                testimonial:
                  "We had a serious termite problem in our new apartment. No.1 Quality Pest Control responded quickly and eliminated the issue completely. Their technicians were professional and thorough. Highly recommended!",
              },
              {
                name: "Priya Sundaram",
                location: "Okkiyam Thoraipakkam",
                testimonial:
                  "Living near the marsh area, mosquitoes were a constant problem. After their treatment, we've seen a dramatic reduction. Their quarterly maintenance program keeps our home pest-free year-round.",
              },
              {
                name: "Tech Solutions India",
                location: "Karapakkam IT Park",
                testimonial:
                  "We've been using No.1 Quality Pest Control for our office building for over 3 years. Their commercial pest management services are discreet, effective, and reasonably priced. Our workspace remains pest-free thanks to their regular maintenance.",
              },
            ].map((testimonial, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-light-green rounded-full flex items-center justify-center text-white text-xl font-bold mr-4">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold">{testimonial.name}</h3>
                      <p className="text-gray-600">{testimonial.location}</p>
                    </div>
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.testimonial}"</p>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                Find answers to common questions about our pest control services in Karapakkam.
              </p>
            </div>
          </AnimatedSection>

          <div className="max-w-3xl mx-auto">
            {[
              {
                question: "How often should I schedule pest control services in Karapakkam?",
                answer:
                  "For most homes in Karapakkam, we recommend quarterly pest control treatments to maintain a pest-free environment. However, this can vary based on your specific situation, property type, and the pests you're dealing with. During the monsoon season, more frequent treatments might be necessary, especially for mosquito control.",
              },
              {
                question: "Are your pest control treatments safe for children and pets?",
                answer:
                  "Yes, we use child and pet-friendly pest control solutions. Our technicians are trained to apply treatments in a way that minimizes exposure to family members and pets. We'll provide specific safety instructions for each treatment, such as when it's safe to re-enter treated areas.",
              },
              {
                question: "Do you offer emergency pest control services in Karapakkam?",
                answer:
                  "Yes, we understand that some pest situations require immediate attention. We offer emergency pest control services throughout Karapakkam and can typically respond within 24-48 hours of your call.",
              },
              {
                question: "What types of pests are common in Karapakkam?",
                answer:
                  "Karapakkam residents commonly deal with mosquitoes (due to nearby water bodies), cockroaches, termites, ants, and rodents. During certain seasons, flying insects like flies and seasonal pests may also be problematic. Our treatments are designed to address these specific local pest challenges.",
              },
              {
                question: "Do you provide commercial pest control for businesses in Karapakkam?",
                answer:
                  "Yes, we offer specialized commercial pest control services for all types of businesses in Karapakkam, including offices, restaurants, retail stores, warehouses, and more. Our commercial programs are designed to be discreet, effective, and compliant with industry regulations.",
              },
            ].map((faq, index) => (
              <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                <div className="mb-6 bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-3">{faq.question}</h3>
                  <p className="text-gray-700">{faq.answer}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white">
        <div className="container mx-auto px-4 text-center">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-6">Ready for a Pest-Free Home or Business in Karapakkam?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Contact No.1 Quality Pest Control today for a free inspection and quote. Our expert team is ready to solve
              your pest problems quickly and effectively.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="tel:+917558108600" className="btn-white flex items-center justify-center gap-2">
                <Phone className="h-5 w-5" /> Call: +91 7558108600
              </a>
              <Link href="#contact-form">
                <button className="btn-white">Get Free Quote</button>
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact-form" className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                Fill out the form below to schedule a free inspection or request a quote for pest control services in
                Karapakkam.
              </p>
            </div>
          </AnimatedSection>
          <div className="max-w-4xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  )
}
