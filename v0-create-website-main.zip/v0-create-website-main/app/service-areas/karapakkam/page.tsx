import type { Metadata } from "next"
import KarapakkamPestControlClient from "./KarapakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Karapakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Karapakkam, Chennai. Effective solutions for cockroaches, mosquitoes, termites, bed bugs & more. Call us for a pest-free home!",
  keywords:
    "pest control Karapakkam, Karapakkam pest services, cockroach control Karapakkam, termite treatment Karapakkam, mosquito control Karapakkam, bed bug treatment Karapakkam, residential pest control Karapakkam, commercial pest control Karapakkam, pest management Karapakkam, No.1 Quality Pest Control Karapakkam",
}

export default function KarapakkamPestControlPage() {
  return <KarapakkamPestControlClient />
}
