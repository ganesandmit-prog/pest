import type { Metadata } from "next"
import MedavakkamPestControlClient from "./MedavakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Medavakkam | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Medavakkam, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Medavakkam, pest control services Medavakkam, cockroach control Medavakkam, termite control Medavakkam, rodent control Medavakkam, bed bug treatment Medavakkam, pest control Chennai, No.1 Quality Pest Control",
}

export default function MedavakkamPage() {
  return <MedavakkamPestControlClient />
}
