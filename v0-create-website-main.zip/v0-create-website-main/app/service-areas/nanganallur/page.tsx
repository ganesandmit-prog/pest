import type { Metadata } from "next"
import NanganallurPestControlClient from "./NanganallurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nanganallur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nanganallur, Chennai. We offer termite treatment, cockroach control, and general pest management with safe, long-lasting results.",
  keywords:
    "pest control Nanganallur, termite treatment Nanganallur, cockroach control Chennai, pest management Nanganallur, No.1 Quality Pest Control",
}

export default function NanganallurPestControlPage() {
  return <NanganallurPestControlClient />
}
