"use client"
import Image from "next/image"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"

export function PattabiramPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Pattabiram, Chennai – Trusted Pest Control Services & Solutions</title>
        <meta
          name="description"
          content="Looking for expert pest control services in Pattabiram, Chennai? Our dedicated team delivers effective control solutions for homes and businesses. Get a free quote today!"
        />
        <meta
          name="keywords"
          content="pest control Pattabiram, pest control services Chennai, bee removal, cockroach control, termite inspection, rodent control, eco-friendly pest control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/pattabiram" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Pattabiram",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pattabiram",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Parrys",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.1148,
                "longitude": 80.1095
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹"
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Pattabiram"
        description="Professional & Affordable Pest Control Solutions"
      />

      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Best Pest Control in Pattabiram, Chennai – Trusted Pest Control Services & Solutions
            </h2>
            <p className="mb-4">
              Looking for expert pest control services in Pattabiram, Chennai? Whether you need residential or
              commercial pest control, our dedicated team of trained professionals delivers the most effective control
              solutions to keep your home and business safe from harmful pests.
            </p>
            <p className="mb-4">
              We specialize in customized pest control services designed to tackle all types of infestations, using
              eco-friendly and advanced methods for long-lasting results. From termite treatment to cockroach and
              mosquito management, our reliable control services are trusted by locals and featured on Sulekha for
              outstanding service and competitive quotes.
            </p>
            <div className="bg-amber-100 p-4 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-2">
                🐜 Our Comprehensive Pest Control Services in Pattabiram Include:
              </h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>🐝 Bee Removal & Nest Treatment</li>
                <li>🪳 Cockroach & Ant Control</li>
                <li>🐜 General Pest Control for Homes & Offices</li>
                <li>🦟 Mosquito & Fly Control Solutions</li>
                <li>🐀 Rodent & Rat Control Services</li>
                <li>🐞 Termite Inspection & Treatment</li>
                <li>🌱 Eco-Friendly & Safe Pest Control Options</li>
                <li>🧹 Professional Cleaning & Sanitization Services</li>
              </ul>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Pest Control Service in Pattabiram"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Why Choose Our Pest Control Services in Pattabiram, Chennai?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Professionals</h3>
              <p>Skilled technicians who understand the best control solutions for every pest type.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Reliable & Effective Service</h3>
              <p>Fast, thorough pest elimination with guaranteed results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Quotes</h3>
              <p>Transparent pricing with no hidden costs—get the best value for your money.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Eco-Friendly Pest Control</h3>
              <p>Safe for your family, pets, and the environment.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Trusted on Sulekha</h3>
              <p>Rated highly by customers for top-quality services.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Commercial Pest Control Experts</h3>
              <p>Tailored services for offices, shops, and industrial spaces.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Pattabiram</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Chennai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Surrounding Localities</h3>
          </div>
        </div>
      </section>

      <ProcessSection />
      <ServicesList />
      <BenefitsSection />
      <TestimonialsSection />

      <section className="container mx-auto px-4 py-12">
        <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold mb-4 text-center">Get Your Free Pest Control Quote in Pattabiram Today!</h2>
          <p className="text-center mb-6">
            Don't let pests take over your property! Contact our expert control services for the best pest control
            solutions in Pattabiram. Call now for a fast, no-obligation quote and enjoy a pest-free environment with our
            trusted services.
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📱</span>
              <span>Phone: +91 7558108600</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📧</span>
              <span>Email: no1qualitypestcontrol@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">🌐</span>
              <span>Website: www.no1qualitypestcontrol.com</span>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
