import type { Metadata } from "next"
import { PattabiramPestControlClient } from "./PattabiramPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pattabiram, Chennai – Trusted Pest Control Services & Solutions",
  description:
    "Looking for expert pest control services in Pattabiram, Chennai? Our dedicated team delivers effective control solutions for homes and businesses. Get a free quote today!",
}

export default function PattabiramPage() {
  return <PattabiramPestControlClient />
}
