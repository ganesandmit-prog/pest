import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Ambattur | No.1 Quality Pest Control Chennai",
  description:
    "Looking for reliable pest control in Ambattur? We offer professional pest control services in Ambattur Chennai, trusted by hundreds of homes and businesses.",
}

export default function AmbatturPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control in Ambattur" subtitle="Trusted Services in Chennai" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              Looking for reliable pest control in Ambattur? Your search ends here! We offer professional pest control
              services in Ambattur Chennai, trusted by hundreds of homes and businesses.
            </p>
            <p className="text-lg">
              From cockroach infestations to termite protection, our expert technicians deliver safe, fast, and
              long-lasting solutions for all your pest problems.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why Choose Our Pest Control Services in Ambattur?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Certified Service Provider with 10+ Years of Experience</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Safe & Odorless Chemicals – Child & Pet Friendly</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Affordable Pest Control Charges in Ambattur</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>5-Star Reviews on Google and Sulekha</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Same-Day Service in Ambattur & Nearby Areas</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>General, Deep & Preventive Pest Control Plans</span>
              </li>
            </ul>
            <p className="mt-4">
              Whether you need residential or commercial pest control, we're the top-rated choice in Ambattur Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Expert Services Include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🪳 Cockroach Control Services</h3>
                <p>Professional gel and spray treatments to eliminate cockroaches from your home or office.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐜 Termite Control in Ambattur</h3>
                <p>Comprehensive termite protection for your property and wooden furniture.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐀 Rodent & Rat Control</h3>
                <p>Effective solutions to eliminate rats and mice from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🦟 Mosquito & Bed Bug Treatment</h3>
                <p>Advanced treatments to keep your home free from mosquitoes and bed bugs.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🧹 Deep Cleaning & Sanitization</h3>
                <p>Professional cleaning services to maintain a hygienic environment.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🏢 Corporate & Office Pest Management</h3>
                <p>Specialized pest control solutions for commercial spaces and offices.</p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Areas We Serve Near Ambattur:</h2>
            <p>We provide pest control services across:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Ambattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Ambattur Industrial Estate</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Mogappair</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Korattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Padi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Thirumullaivoyal</div>
            </div>
            <p className="mt-4">
              Our network is strong in Chennai and Tamil Nadu, with specialized teams for Ambattur pest control
              services.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 className="text-2xl font-bold mb-4">Top Pest Control Company in Ambattur</h2>
            <p className="mb-4">
              We are proud to be among the best pest control service providers in Ambattur, with a strong focus on:
            </p>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Customer Satisfaction</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Timely Service</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Eco-Friendly Chemicals</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Transparent Pricing</span>
              </li>
            </ul>
            <p className="mt-4">
              Whether you are in a house, apartment, villa, or office, we provide customized pest control packages that
              suit your needs and budget.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Book a Free Inspection Today!</h2>
            <p className="mb-4">
              Get professional pest control in Ambattur at unbeatable prices. We ensure your home is safe, pest-free,
              and hygienic.
            </p>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Visit:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Ambattur</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
