"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SelaiyurPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Selaiyur, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🛡️ Reliable Pest Control in Selaiyur – Expert Services at Affordable Prices
              </h1>

              <div className="prose max-w-none">
                <p>
                  Are you searching for trusted pest control services in Selaiyur, Chennai? Look no further! Our
                  professional team provides fast, safe, and effective pest solutions tailored for homes and businesses
                  in the Selaiyur region. From cockroach issues to termite infestations, we offer comprehensive
                  treatment options that are budget-friendly and eco-conscious.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐞 Our Pest Control Services in Selaiyur:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control – Eliminate disease-carrying pests from your kitchen and home.</li>
                  <li>🐜 Termite Treatment – Prevent structural damage with advanced termite protection.</li>
                  <li>🦟 Mosquito Control – Safe fogging and larvicide solutions for long-term relief.</li>
                  <li>🛏️ Bed Bug Removal – Targeted treatments for total eradication.</li>
                  <li>🐁 Rodent Control – Block entry points and remove rats/mice humanely.</li>
                  <li>🌿 Eco-Friendly Cleaning & Pest Management</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">💡 Why Choose Us in Selaiyur?</h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Experienced Professionals – With years of expertise across Chennai localities.</li>
                  <li>✔️ General Pest Control Specialists – From ants to termites, we handle it all.</li>
                  <li>✔️ Affordable and Transparent Pricing – No hidden charges.</li>
                  <li>✔️ Quick Response Time – Fast service in Selaiyur and surrounding areas.</li>
                  <li>✔️ Eco-Safe Products – Safe for kids, pets, and the environment.</li>
                  <li>✔️ Post-Cleaning & Disinfection Available – Keep your space sanitized post-treatment.</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Serving Pest Control in:</h2>

                <ul className="list-none space-y-2">
                  <li>Selaiyur</li>
                  <li>Selaiyur-Chennai border areas</li>
                  <li>Camp Road, Tambaram East</li>
                  <li>Residential Apartments & Commercial Spaces</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact Us Today!</h3>
                  <p className="mt-4">
                    📱 Call: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
