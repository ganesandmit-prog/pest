import type { Metadata } from "next"
import BasinBridgePestControlClient from "./BasinBridgePestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Basin Bridge | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Basin Bridge, Chennai. Safe, affordable, and effective solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Basin Bridge, pest control services Basin Bridge, Basin Bridge pest control, cockroach control Basin Bridge, termite control Basin Bridge, bed bug control Basin Bridge, rodent control Basin Bridge",
}

export default function BasinBridgePestControl() {
  return <BasinBridgePestControlClient />
}
