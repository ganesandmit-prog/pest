"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function BasinBridgePestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Basin Bridge" subtitle="Trusted by 100000+ Happy Clients" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Best Pest Control Services in Basin Bridge</h2>
                  <div className="prose max-w-none">
                    <p>
                      If you're searching for trusted pest control in Basin Bridge, your search ends here. We specialize
                      in general pest control, termite treatment, and residential & commercial pest solutions with
                      proven results across Basin Bridge and Chennai.
                    </p>
                    <p>
                      From cockroaches to termites, we offer effective, eco-friendly, and affordable pest solutions to
                      keep your space safe.
                    </p>
                    <h3>Our Services Include:</h3>
                    <ul>
                      <li>General Pest Control – Cockroaches, Ants, Lizards, Spiders</li>
                      <li>Termite Control – Pre & Post Construction Treatments</li>
                      <li>Rodent Control – Mice, Rats, Squirrels</li>
                      <li>Bed Bug & Mosquito Control</li>
                      <li>Eco-Safe, Family-Friendly Chemicals</li>
                      <li>Fast Service in Basin Bridge & Nearby Chennai Areas</li>
                    </ul>
                    <h3>Why Choose Us?</h3>
                    <ul>
                      <li>Over a Decade in Basin Bridge Chennai</li>
                      <li>Certified Pest Control Professionals</li>
                      <li>Trusted by Homes & Businesses Alike</li>
                      <li>100% Safe, Odor-Free Chemicals</li>
                      <li>Same-Day Pest Control Services Available</li>
                      <li>Top Reviews on Google, Justdial, and Sulekha</li>
                    </ul>
                    <h3>Serving All Nearby Locations:</h3>
                    <ul>
                      <li>Basin Bridge</li>
                      <li>Park Town</li>
                      <li>Perambur</li>
                      <li>George Town</li>
                      <li>Purasaiwakkam</li>
                      <li>Sowcarpet</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Basin Bridge"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Basin Bridge"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Basin Bridge</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Basin Bridge home or business? Contact No.1 Quality Pest
                        Control today for a free inspection and quote. Our team of experienced professionals is ready to
                        help you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
