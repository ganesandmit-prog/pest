import { MudichurPestControlClient } from "./MudichurPestControlClient"

export const metadata = {
  title: "Pest Control in Mudichur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mudichur, Chennai. Fast, safe & affordable solutions for cockroach, termite, rodent control & more. Book same-day service!",
}

export default function MudichurPage() {
  return <MudichurPestControlClient />
}
