"use client"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { ContactForm } from "@/components/contact-form"
import { FadeIn } from "@/components/framer-animations"

export function MudichurPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Pest Control in Mudichur, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Mudichur, Chennai. Fast, safe & affordable solutions for cockroach, termite, rodent control & more. Book same-day service!"
        />
        <meta
          name="keywords"
          content="pest control Mudichur, Mudichur pest services, cockroach control Mudichur, termite treatment Mudichur, rodent control Mudichur, bed bug treatment Mudichur, affordable pest control Mudichur, Chennai pest control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/mudichur" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Mudichur",
              "description": "Professional pest control services in Mudichur, Chennai. We offer fast, safe, and affordable pest control solutions for homes and businesses.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/mudichur",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Mudichur",
                "addressRegion": "Chennai",
                "postalCode": "600100",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "12.9401",
                "longitude": "80.1309"
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "07:00",
                "closes": "22:00"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹",
              "servesCuisine": "Pest Control Services"
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "serviceType": "Pest Control Service",
              "provider": {
                "@type": "ProfessionalService",
                "name": "No.1 Quality Pest Control"
              },
              "areaServed": {
                "@type": "City",
                "name": "Mudichur, Chennai"
              },
              "description": "Professional pest control services in Mudichur, Chennai including cockroach control, termite treatment, rodent control, and more.",
              "offers": {
                "@type": "Offer",
                "price": "999.00",
                "priceCurrency": "INR"
              }
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Mudichur, Chennai"
        description="Fast, Safe & Affordable Pest Solutions by No.1 Quality Pest Control"
      />

      <div className="container mx-auto px-4 py-12">
        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Professional Pest Control in Mudichur</h2>
            <p className="text-gray-700 mb-4">
              Looking for reliable pest control in Mudichur? You're in the right place! At No.1 Quality Pest Control, we
              provide top-rated, eco-safe, and fully guaranteed pest control services in Mudichur Chennai for homes,
              apartments, and businesses. From cockroach removal to termite treatment, we use expert methods and
              government-approved solutions to keep your space pest-free.
            </p>
            <p className="text-gray-700 mb-4">
              Our team of certified technicians specializes in eliminating all types of pests while ensuring the safety
              of your family, pets, and the environment. We understand the unique pest challenges faced by Mudichur
              residents and offer customized solutions to address them effectively.
            </p>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Mudichur</h2>
            <ul className="list-disc pl-6 mb-4 space-y-2 text-gray-700">
              <li>
                <span className="font-semibold">Cockroach Control Services</span> - Eliminate cockroach infestations
                with our targeted treatments
              </li>
              <li>
                <span className="font-semibold">Rodent Control & Removal</span> - Comprehensive solutions for rat and
                mice problems
              </li>
              <li>
                <span className="font-semibold">Termite Control in Mudichur</span> - Protect your property from
                destructive termites
              </li>
              <li>
                <span className="font-semibold">Mosquito & Fly Management</span> - Reduce disease-carrying insects
                around your property
              </li>
              <li>
                <span className="font-semibold">Bed Bug Treatments</span> - Specialized solutions for complete bed bug
                elimination
              </li>
              <li>
                <span className="font-semibold">Ant, Spider & General Insect Removal</span> - Control various crawling
                insects
              </li>
              <li>
                <span className="font-semibold">Organic Pest Control Services</span> - Eco-friendly options for
                environmentally conscious customers
              </li>
            </ul>
            <p className="text-gray-700">
              We also provide disinfection & cleaning services to keep your environment hygienic and fresh.
            </p>
          </div>
        </FadeIn>

        <BenefitsSection
          title="Why Choose No.1 Quality Pest Control in Mudichur?"
          benefits={[
            {
              title: "10+ Years of Experience",
              description: "Benefit from our decade of pest control expertise in Chennai",
            },
            {
              title: "Certified Technicians",
              description: "Our team is fully trained and certified in the latest pest control methods",
            },
            {
              title: "Safe for Children & Pets",
              description: "We use family-friendly treatments that are effective yet safe",
            },
            {
              title: "Quick Bookings – Same-Day Service",
              description: "Fast response times when you need pest control urgently",
            },
            {
              title: "Affordable Pricing with Free Quotes",
              description: "Competitive rates with transparent pricing and no hidden fees",
            },
            {
              title: "Listed on Sulekha Chennai – Trusted by 1000+ Clients",
              description: "Join our satisfied customers throughout Chennai",
            },
          ]}
        />

        <ProcessSection
          title="Our Pest Control Process in Mudichur"
          steps={[
            {
              title: "Inspection",
              description: "Thorough assessment of your property to identify pest issues and entry points",
            },
            {
              title: "Customized Treatment Plan",
              description: "Developing a targeted solution based on your specific pest problem",
            },
            {
              title: "Professional Treatment",
              description: "Application of effective, government-approved pest control methods",
            },
            {
              title: "Preventive Measures",
              description: "Implementing strategies to prevent future infestations",
            },
            {
              title: "Follow-up Service",
              description: "Ensuring complete pest elimination with follow-up visits if needed",
            },
          ]}
        />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Customer Testimonials from Mudichur</h2>
            <div className="space-y-4">
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Quick and clean pest control service! We had a termite issue and they solved it effectively."
                </p>
                <p className="text-gray-600 font-semibold">— Karthik S., Mudichur</p>
              </div>
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Best pest control company in Mudichur. Highly recommend them for cockroach and ant problems."
                </p>
                <p className="text-gray-600 font-semibold">— Sandhya T., Homeowner</p>
              </div>
            </div>
          </div>
        </FadeIn>

        <TestimonialsSection />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-800">
                  How often should I get pest control service in Mudichur?
                </h3>
                <p className="text-gray-700">
                  For most homes in Mudichur, we recommend quarterly pest control treatments to maintain a pest-free
                  environment. However, this can vary based on your specific situation and the types of pests in your
                  area.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Are your pest control treatments safe for children and pets?
                </h3>
                <p className="text-gray-700">
                  Yes, we use government-approved chemicals that are safe for families and pets when applied correctly.
                  We'll provide specific safety instructions for each treatment.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Do you offer emergency pest control services in Mudichur?
                </h3>
                <p className="text-gray-700">
                  Yes, we offer same-day emergency pest control services throughout Mudichur. Contact us immediately for
                  urgent pest issues.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">What areas near Mudichur do you serve?</h3>
                <p className="text-gray-700">
                  Besides Mudichur, we serve Tambaram, Chromepet, Pallavaram, and all surrounding areas in South
                  Chennai.
                </p>
              </div>
            </div>
          </div>
        </FadeIn>

        <ContactForm />
      </div>
    </>
  )
}
