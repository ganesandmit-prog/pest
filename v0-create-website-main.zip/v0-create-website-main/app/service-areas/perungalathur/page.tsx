import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import PerungalathurPestControlClient from "./PerungalathurPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Perungalathur Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Perungalathur? No.1 Quality Pest Control offers reliable, safe, and affordable pest control services in Perungalathur Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function PerungalathurPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Perungalathur Chennai"
        subtitle="Professional & Affordable Pest Control Services in Perungalathur"
      />
      <PerungalathurPestControlClient />
    </main>
  )
}
