"use client"

import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export default function PerungalathurPestControlClient() {
  return (
    <div className="container mx-auto px-4 py-12">
      <AnimatedSection animation="fadeIn" delay={0.1}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Perungalathur</h2>
          <p className="mb-4">
            Looking for reliable pest control services in Perungalathur, Chennai? Our expert team specializes in
            comprehensive control services that ensure your home and business remain pest-free. From tough cockroach
            infestations to general pest management, we provide fast, effective, and affordable solutions.
          </p>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.2}>
        <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Perungalathur</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🪳 Cockroach Control</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🐀 Rodent Control</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🐞 General Pest Control</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🧹 Professional Cleaning Services</span>
            </div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">
              <span className="text-dark-green">🌿 Eco-Friendly & Safe Pest Treatments</span>
            </div>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.3}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">Why Choose Us for Pest Control in Perungalathur?</h2>
          <ul className="list-none space-y-3">
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Skilled Professionals: Experienced in handling all pest types with precision.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>
                Trusted by Chennai Residents: Recognized on Sulekha and trusted by the Perungalathur community.
              </span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Affordable Quotes: Transparent pricing with no hidden charges.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Advanced Solutions: Using world-class pest control methods for effective results.</span>
            </li>
            <li className="flex items-start">
              <span className="text-light-green font-bold mr-2">✅</span>
              <span>Customer Satisfaction: Commitment to a pest-free, healthy environment.</span>
            </li>
          </ul>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="slideUp" delay={0.4}>
        <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">
            Serving Perungalathur, Chennai, and Surrounding Areas
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">Perungalathur</div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">New Perungalathur</div>
            <div className="bg-white p-3 rounded-lg text-center shadow-sm">Chennai</div>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="fadeIn" delay={0.5}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-dark-green mb-4">
            Contact Us Today for Pest Control in Perungalathur!
          </h2>
          <p className="mb-4">
            Secure your space with top-rated pest control services in Perungalathur. Call now for a free quote and swift
            action!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex items-center">
              <span className="font-bold mr-2">📱 Phone:</span>
              <a href="tel:+917558108600" className="text-light-green hover:underline">
                +91 7558108600
              </a>
            </div>
            <div className="flex items-center">
              <span className="font-bold mr-2">📧 Email:</span>
              <a href="mailto:no1qualitypestcontrol@gmail.com" className="text-light-green hover:underline">
                no1qualitypestcontrol@gmail.com
              </a>
            </div>
          </div>
          <div>
            <p>
              <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
            </p>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection animation="fadeIn" delay={0.6}>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
            Contact Us for Pest Control in Perungalathur
          </h2>
          <ContactForm />
        </div>
      </AnimatedSection>
    </div>
  )
}
