"use client"
import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ChevronRight, Check, Phone, MapPin } from "lucide-react"

import { AnimatedSection } from "@/components/framer-animations"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"
import FAQSection from "@/components/faq-section"
import ContactForm from "@/components/contact-form"
import CTA from "@/components/cta"

export default function VirugambakkamPestControlClient() {
  const [location] = useState("Virugambakkam")

  const virugambakkamFAQs = [
    {
      question: "What pest control services do you offer in Virugambakkam?",
      answer:
        "We offer comprehensive pest control services in Virugambakkam including cockroach control, termite treatment, bed bug elimination, rodent control, mosquito control, and general pest management for both residential and commercial properties. Our services are customized to address the specific pest challenges common in the Virugambakkam area.",
    },
    {
      question: "How much does pest control cost in Virugambakkam?",
      answer:
        "Our pest control services in Virugambakkam start from ₹999, with the final cost depending on factors such as property size, type of pest infestation, severity of the problem, and treatment method required. We provide transparent pricing with no hidden charges and offer free inspections to provide accurate quotes before beginning any work.",
    },
    {
      question: "Are your pest control treatments safe for children and pets in Virugambakkam homes?",
      answer:
        "Yes, we prioritize safety in all our Virugambakkam pest control treatments. We use eco-friendly, low-toxicity products that are effective against pests while being safe for your family and pets when used as directed. Our technicians are trained to apply treatments in a manner that minimizes exposure to non-target organisms, and we provide clear instructions on post-treatment precautions.",
    },
    {
      question: "How quickly can you respond to pest emergencies in Virugambakkam?",
      answer:
        "We offer same-day or next-day emergency pest control services throughout Virugambakkam. Our dedicated team understands that pest infestations can be distressing and require immediate attention. Contact our 24/7 helpline at +91 7558108600 for rapid response to your pest emergency.",
    },
    {
      question: "Do you provide commercial pest control services in Virugambakkam?",
      answer:
        "We provide specialized commercial pest control services for businesses in Virugambakkam including restaurants, hotels, offices, warehouses, and retail establishments. Our commercial pest management programs are discreet, effective, and designed to comply with industry regulations while minimizing disruption to your business operations.",
    },
  ]

  return (
    <>
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-2/3">
              <AnimatedSection animation="fadeIn">
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Link href="/" className="hover:text-light-green">
                    Home
                  </Link>
                  <ChevronRight className="h-4 w-4 mx-1" />
                  <Link href="/service-areas" className="hover:text-light-green">
                    Service Areas
                  </Link>
                  <ChevronRight className="h-4 w-4 mx-1" />
                  <span>Virugambakkam</span>
                </div>

                <h1 className="text-3xl md:text-4xl font-bold mb-6">
                  Professional Pest Control Services in Virugambakkam, Chennai
                </h1>

                <div className="flex items-center mb-6">
                  <MapPin className="h-5 w-5 text-light-green mr-2" />
                  <span className="text-gray-600">Serving all areas in Virugambakkam, Chennai - 600092</span>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg mb-8 flex items-center justify-between">
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-light-green mr-2" />
                    <span className="font-medium">For Immediate Pest Control in Virugambakkam:</span>
                  </div>
                  <a
                    href="tel:+917558108600"
                    className="bg-light-green text-white px-4 py-2 rounded-md hover:bg-dark-green transition-colors"
                  >
                    Call +91 7558108600
                  </a>
                </div>

                <div className="prose max-w-none mb-8">
                  <p>
                    Welcome to No.1 Quality Pest Control, your trusted pest management partner in Virugambakkam,
                    Chennai. We understand that Virugambakkam's residential neighborhoods and commercial establishments
                    face unique pest challenges, from termite infestations in older buildings to cockroach problems in
                    food establishments.
                  </p>

                  <p>
                    Our team of certified pest control experts has been serving the Virugambakkam community for over 45
                    years, providing effective and affordable solutions to keep homes and businesses pest-free. We
                    combine our deep knowledge of local pest behavior with advanced treatment methods to deliver
                    long-lasting results.
                  </p>

                  <h2>Common Pest Problems in Virugambakkam</h2>

                  <p>
                    Virugambakkam residents often encounter several pest issues due to the area's mix of residential and
                    commercial spaces. Some common pest problems include:
                  </p>

                  <ul>
                    <li>
                      <strong>Termite infestations</strong> in residential buildings and wooden structures
                    </li>
                    <li>
                      <strong>Cockroach problems</strong> in apartments and food establishments
                    </li>
                    <li>
                      <strong>Rodent issues</strong> near commercial areas and markets
                    </li>
                    <li>
                      <strong>Mosquito breeding</strong> in stagnant water during monsoon seasons
                    </li>
                    <li>
                      <strong>Bed bug infestations</strong> in residential properties
                    </li>
                  </ul>

                  <p>
                    Our comprehensive pest control services in Virugambakkam are designed to address these specific
                    challenges with targeted treatments that ensure complete elimination while being safe for your
                    family, pets, and the environment.
                  </p>

                  <h2>Why Virugambakkam Residents Choose Us</h2>

                  <ul>
                    <li>
                      <strong>Local expertise:</strong> Our technicians understand Virugambakkam's unique pest patterns
                      and challenges
                    </li>
                    <li>
                      <strong>Customized solutions:</strong> Tailored pest control plans for residential and commercial
                      properties
                    </li>
                    <li>
                      <strong>Eco-friendly treatments:</strong> Safe for families, pets, and the environment
                    </li>
                    <li>
                      <strong>Affordable pricing:</strong> Competitive rates with no compromise on quality
                    </li>
                    <li>
                      <strong>Emergency response:</strong> Quick service for urgent pest problems
                    </li>
                  </ul>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold mb-4">Our Service Commitment in Virugambakkam</h3>
                  <ul className="space-y-3">
                    {[
                      "Same-day inspection for urgent pest problems",
                      "Transparent pricing with no hidden charges",
                      "Certified and trained pest control technicians",
                      "Follow-up visits to ensure complete pest elimination",
                      "Preventive advice to avoid future infestations",
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-1 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </AnimatedSection>
            </div>

            <div className="md:w-1/3">
              <AnimatedSection animation="slideUp">
                <div className="bg-white rounded-lg shadow-lg overflow-hidden sticky top-24">
                  <div className="bg-dark-green text-white p-4">
                    <h3 className="text-xl font-bold text-center">Request Pest Control Service in Virugambakkam</h3>
                  </div>
                  <div className="p-6">
                    <ContactForm location={location} />
                  </div>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>

      <ServicesList location={location} />

      <section className="py-12 md:py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-12 text-center">
              Our Pest Control Projects in Virugambakkam, Chennai
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Residential Apartment Complex",
                description:
                  "Complete termite and cockroach control treatment for a 150-unit apartment complex in Virugambakkam",
                image: "/images/projects/residential-project.jpg",
              },
              {
                title: "Commercial Restaurant",
                description:
                  "Comprehensive pest management program for a popular restaurant chain in Virugambakkam main road",
                image: "/images/projects/commercial-project.jpg",
              },
              {
                title: "Office Building",
                description: "Regular pest control maintenance for a corporate office building in Virugambakkam",
                image: "/images/projects/institutional-project.jpg",
              },
            ].map((project, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div
                  className="bg-white rounded-lg overflow-hidden shadow-md h-full"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="relative h-48">
                    <Image
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      fill
                      style={{ objectFit: "cover" }}
                      className="transition-transform duration-500 ease-in-out group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-600">{project.description}</p>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <ProcessSection location={location} />
      <BenefitsSection location={location} />
      <TestimonialsSection location={location} />

      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-12 text-center">Areas We Serve for Pest Control in Virugambakkam</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            {[
              "Virugambakkam Main Road",
              "Alwarthirunagar",
              "Arcot Road",
              "Choolaimedu",
              "Koyambedu",
              "Maduravoyal",
              "Saligramam",
              "Valasaravakkam",
              "Vadapalani",
              "Alapakkam",
              "Nesapakkam",
              "Ramapuram",
              "Porur",
              "K.K. Nagar",
              "MGR Nagar",
            ].map((area, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.05}>
                <div className="bg-gray-50 rounded-lg p-4 text-center hover:bg-light-green hover:text-white transition-colors">
                  <span>{area}</span>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <FAQSection faqs={virugambakkamFAQs} location={location} />
      <CTA location={location} />
    </>
  )
}
