import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import VirugambakkamPestControlClient from "./VirugambakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Virugambakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Virugambakkam, Chennai. Effective solutions for termites, cockroaches, bed bugs, rodents & mosquitoes. Call +91 7558108600 for same-day service!",
  alternates: {
    canonical: "https://no1qualitypestcontrol.com/service-areas/virugambakkam",
  },
}

export default function VirugambakkamPestControlPage() {
  return (
    <>
      <PageHeader
        title="Pest Control Services in Virugambakkam, Chennai"
        backgroundImage="/images/service-areas/virugambakkam-pest-control.jpg"
        subtitle="Professional & Affordable Pest Management Solutions"
      />
      <VirugambakkamPestControlClient />
    </>
  )
}
