import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Avadi | No.1 Quality Pest Control Chennai",
  description:
    "If you're searching for Pest Control in Avadi, your search ends here! We are one of the most trusted pest control companies in Avadi Chennai, offering residential and commercial pest control services with guaranteed results.",
}

export default function AvadiPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="No.1 Pest Control in Avadi" subtitle="Safe | Reliable | Affordable" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              If you're searching for Pest Control in Avadi, your search ends here! We are one of the most trusted pest
              control companies in Avadi Chennai, offering residential and commercial pest control services with
              guaranteed results.
            </p>
            <p className="text-lg">
              From cockroaches and termites to rodents and general pests, we eliminate all unwanted guests with
              eco-friendly, kid-safe, and pet-safe treatments.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Top Services in Avadi:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 General Pest Control</h3>
                <p>Comprehensive solutions for all common household pests.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Cockroach Control (Gel + Spray Treatment)</h3>
                <p>Advanced treatments for effective cockroach elimination.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Termite Control & Prevention</h3>
                <p>Complete protection against termites for your property.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Rodent & Lizard Removal</h3>
                <p>Safe and humane solutions to eliminate rodent infestations.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Bed Bug Control</h3>
                <p>Specialized treatments to eliminate bed bugs completely.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Mosquito Fogging</h3>
                <p>Effective solutions to keep mosquitoes away from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔹 Disinfection & Sanitization Services</h3>
                <p>Professional cleaning and sanitization for a healthy environment.</p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why Choose Us?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Ranked High for "Pest Control in Avadi Chennai"</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Trusted for Pest Control Services on Google, Justdial, and Sulekha</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Affordable Packages with Zero Hidden Charges</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Experienced Technicians & Verified Company</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Residential, Commercial, and Industrial Service</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Fast Response, Same-Day Service Available</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>100% Satisfaction & Long-Term Relief Guarantee</span>
              </li>
            </ul>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Service Coverage Areas in and around Avadi:</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi, Chennai</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi Railway Station Area</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi HVF Road</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Annanur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Thirumullaivoyal</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Pattabiram</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Ambattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Nearby Chennai localities</div>
            </div>
            <p className="mt-4">
              Whether you need pest control quotes, general treatment, or emergency services, we're the leading pest
              control company in Avadi ready to serve you 7 days a week.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Book Now for a Free Inspection!</h2>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Phone:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Website:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
            </div>
            <p className="mt-4">📸 Ask for photos of previous work & customer reviews!</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Avadi</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
