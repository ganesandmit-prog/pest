import type { Metadata } from "next"
import KattivakkamPestControlClient from "./KattivakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Kattivakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kattivakkam, Chennai. Effective solutions for cockroaches, mosquitoes, termites, bed bugs & more. Call us for a pest-free home!",
  keywords:
    "pest control Kattivakkam, Kattivakkam pest services, cockroach control Kattivakkam, termite treatment Kattivakkam, mosquito control Kattivakkam, bed bug treatment Kattivakkam, residential pest control Kattivakkam, commercial pest control Kattivakkam, pest management Kattivakkam, No.1 Quality Pest Control Kattivakkam",
}

export default function KattivakkamPestControlPage() {
  return <KattivakkamPestControlClient />
}
