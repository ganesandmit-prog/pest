"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KattivakkamPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Trusted Pest Control in Kattivakkam, Chennai" subtitle="Safe & Affordable Solutions" />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are you looking for pest control in Kattivakkam that's both reliable and affordable? You've come to the
                right place! Our expert team offers comprehensive pest control services across Kattivakkam, Chennai,
                designed to eliminate pests and keep your space safe and clean.
              </p>
              <p className="text-lg mb-6">
                Whether you're facing issues with cockroaches, rodents, mosquitoes, or termites – our general pest
                control treatments provide long-lasting relief using safe, eco-friendly methods. We are one of the
                top-rated services in Chennai, trusted by hundreds of homes and businesses in Tamil Nadu, India.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">🛠 Our Pest Control Services in Kattivakkam</h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent Control</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Treatment</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Treatment</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest Control</strong>
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧹</span>
                    <span>
                      <strong>Cleaning Services</strong> for post-treatment hygiene
                    </span>
                  </li>
                </ul>
                <p className="mt-4">
                  Our control services are tailored for residential apartments, villas, commercial buildings, and
                  offices in Kattivakkam and nearby areas like Kottivakkam, Chennai.
                </p>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Our Pest Control in Kattivakkam?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Experienced & Certified Technicians</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>100% Safe & Eco-Friendly Chemicals</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Budget-Friendly Packages – No Hidden Charges</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Prompt & Guaranteed Service</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Top-rated across Chennai and Tamil Nadu, India</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Professional Cleaning & Disinfection Available</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 We Also Serve:</h2>
                <p className="mb-4">
                  Kottivakkam | Thiruvanmiyur | Neelankarai | Palavakkam | Besant Nagar | Throughout Chennai, Tamil
                  Nadu, India
                </p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">📞 Book Pest Control Services in Kattivakkam Now!</h2>
                <p className="mb-2">
                  📱 Call Us:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Visit: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
                <p>📍 Available in Kattivakkam, Kottivakkam, and all of Chennai</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🛡️ Whether you need cockroach control, termite treatment, or general pest management, our team is ready
                  to provide fast, effective solutions. Contact us today for a free consultation and experience the best
                  pest control service in Kattivakkam.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Kattivakkam</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
