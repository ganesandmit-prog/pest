import type { Metadata } from "next"
import { SaligramamPestControlClient } from "./SaligramamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Saligramam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Saligramam, Chennai. We offer cockroach, termite, bed bug, and mosquito control with eco-friendly solutions. Call now!",
  keywords:
    "pest control Saligramam, Saligramam pest control services, pest control company Chennai, organic pest control Saligramam, affordable pest control",
}

export default function SaligramamPage() {
  return <SaligramamPestControlClient />
}
