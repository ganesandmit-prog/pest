"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SaligramamPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Saligramam, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Pest Control in Saligramam – Trusted Pest Control Services in Saligramam, Chennai
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for effective and affordable pest control services in Saligramam, Chennai? We are the go-to
                  pest control company providing fast, reliable, and eco-friendly solutions for homes, offices, and
                  commercial buildings. From cockroach infestations to termite threats, we offer end-to-end control
                  services to eliminate all types of pests with guaranteed results.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  🐜 Our Pest Control Services in Saligramam Include:
                </h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control – Gel & odorless spray-based treatments</li>
                  <li>🐜 Ant & Termite Control – Pre/post construction pest removal</li>
                  <li>🛏️ Bed Bug Removal – Heat & herbal solutions</li>
                  <li>🦟 Mosquito Fogging & Control – Complete area coverage</li>
                  <li>🐁 Rodent Control Services – Humane & effective solutions</li>
                  <li>🌿 Eco-Friendly & Organic Pest Solutions</li>
                  <li>🧹 Post-Treatment Cleaning Services – Make your space pest-free & hygienic</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  💡 Why Choose Our Pest Control Company in Saligramam?
                </h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Trained Experts – Certified pest technicians</li>
                  <li>✔️ Eco-Friendly Methods – Safe for kids & pets</li>
                  <li>✔️ Affordable Pricing – Transparent rates, no hidden charges</li>
                  <li>✔️ Fast Service – Same-day inspection and treatment</li>
                  <li>✔️ Top Reviews in Saligramam – 5-star rated by residents</li>
                  <li>✔️ Centrally Located – Easily accessible in Saligramam, Chennai</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 We Serve Saligramam & Nearby Areas:</h2>

                <ul className="list-none space-y-2">
                  <li>Saligramam, Chennai</li>
                  <li>Vadapalani</li>
                  <li>Virugambakkam</li>
                  <li>Kodambakkam</li>
                  <li>K.K. Nagar</li>
                  <li>Ashok Nagar</li>
                  <li>Valasaravakkam</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact the #1 Pest Control Service in Saligramam!</h3>
                  <p>
                    Don't let pests take over your home. Call the experts for Pest Control in Saligramam today and enjoy
                    a clean, safe environment.
                  </p>
                  <p className="mt-4">
                    📱 Call Now: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
