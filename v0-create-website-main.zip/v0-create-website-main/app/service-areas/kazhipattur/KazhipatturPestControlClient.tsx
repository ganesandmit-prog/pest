"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KazhipatturPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader
        title="Best Pest Control in Kazhipattur, Chennai"
        subtitle="One Stop for All Your Pest Control Needs"
      />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are you searching for pest control in Kazhipattur? Look no further! We offer pest control services that
                are fast, effective, and affordable. As trusted experts in Tamil Nadu, we deliver customized control
                services to meet all your residential and commercial pest needs.
              </p>
              <p className="text-lg mb-6">
                From termite treatment to mosquito control, our solutions are designed to ensure your space stays
                hygienic, safe, and pest-free. Whether you're facing pest issues in Chennai or nearby areas, we're your
                one stop solution for pest management.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🛠 Our Top Pest Control Services in Kazhipattur
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Treatment</strong> – Protect your property from termite damage.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Keep your surroundings mosquito-free.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Eradicate cockroaches effectively.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Treatment</strong> – Enjoy peaceful, bug-free sleep.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent Control</strong> – Eliminate rats and other rodents.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐦</span>
                    <span>
                      <strong>Pigeon Control</strong> – Installation of spikes to prevent nesting.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest Management</strong> – Tailored control services for all pest issues.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Our Pest Control Experts in Kazhipattur?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Experienced pest control experts across Tamil Nadu</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Safe, eco-friendly, and government-approved methods</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Transparent pricing – No hidden costs</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Quick, reliable, and guaranteed control services</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Residential & commercial services in Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>24/7 customer support for all your pest control needs</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 Areas We Serve Around Kazhipattur</h2>
                <p className="mb-4">
                  Padur | Navalur | Siruseri | Kelambakkam | Sholinganallur | ECR | OMR | All over Chennai
                </p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">
                  📞 Contact the Best Pest Control Services in Kazhipattur Today!
                </h2>
                <p className="mb-2">
                  📱 Call:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p>
                  🌐 Website: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🛡️ Whether it's pigeon spikes, mosquito control, or termite treatment, our experienced team is ready to
                  solve all your pest problems with professional-grade pest control services. We understand your needs
                  and deliver top-tier control services in Chennai. Choose us – your one stop solution for safe, fast,
                  and effective pest management.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Kazhipattur</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
