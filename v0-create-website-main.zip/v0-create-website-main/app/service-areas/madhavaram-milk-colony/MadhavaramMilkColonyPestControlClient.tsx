"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function MadhavaramMilkColonyPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Madhavaram Milk Colony" subtitle="Safe. Reliable. Trusted." />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Looking for the best pest control in Madhavaram Milk Colony? You've landed at the right place. At No.1
                  Quality Pest Control, we offer reliable, professional, and affordable pest control services in
                  Madhavaram Milk Colony Chennai and the surrounding areas.
                </p>
                <p className="text-lg">
                  From cockroach control to termite treatment and rodent removal, our team delivers customized solutions
                  for residential, commercial, and industrial needs in Chennai Tamil Nadu.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🛡️ Our Expert Pest Control Services Include:</h2>
                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control Services in Milk Colony</li>
                  <li>🐀 Rodent Control for Homes and Offices</li>
                  <li>🐜 Termite Control in Madhavaram Milk Colony</li>
                  <li>🦟 Mosquito Pest Management Services</li>
                  <li>🛏 Bed Bug Extermination</li>
                  <li>🕷 Spider & Ant Control</li>
                  <li>🌿 Eco-Friendly and Organic Pest Control Options</li>
                </ul>
                <p>We use only government-approved, child and pet-safe chemicals to ensure your family's safety.</p>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Areas We Serve Around Madhavaram Milk Colony:</h2>
                <ul className="list-none space-y-2">
                  <li>Madhavaram Milk Colony</li>
                  <li>Manali</li>
                  <li>Kodungaiyur</li>
                  <li>Kolathur</li>
                  <li>Retteri</li>
                  <li>Red Hills</li>
                  <li>Puzhal</li>
                </ul>
                <p>We're trusted by 100000+ clients and listed on Sulekha Chennai with verified reviews.</p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🌟 Why Choose No.1 Quality Pest Control?</h2>
                <ul className="list-none space-y-2">
                  <li>✅ 40+ Years of Trusted Service</li>
                  <li>✅ Skilled & Certified Technicians</li>
                  <li>✅ Emergency Services & Prompt Response</li>
                  <li>✅ Transparent Pricing + Free Quotes</li>
                  <li>✅ Specialized control services for homes, hostels, apartments & offices</li>
                  <li>✅ Long-Term Results</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">⭐ What Our Clients Say:</h2>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "Best pest control in Madhavaram Milk Colony – very neat work and excellent customer service!"
                  <footer className="text-right">— Dinesh R., Chennai</footer>
                </blockquote>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "They completely removed termites and gave us a 3-year warranty. Highly recommend!"
                  <footer className="text-right">— Meena V., Local Resident</footer>
                </blockquote>

                <h2 className="text-2xl font-bold mt-8 mb-4">📞 Contact Us Now – Say Goodbye to Pests!</h2>
                <ul className="list-none space-y-2">
                  <li>📍 Location: Madhavaram Milk Colony, Chennai, Tamil Nadu</li>
                  <li>
                    📞 Phone:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="https://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      https://www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">
                Contact Us for Pest Control in Madhavaram Milk Colony
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Madhavaram Milk Colony" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Madhavaram Milk
                      Colony. Contact us today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
