import type { Metadata } from "next"
import MadhavaramMilkColonyPestControlClient from "./MadhavaramMilkColonyPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Madhavaram Milk Colony | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Madhavaram Milk Colony, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Madhavaram Milk Colony, pest control services Madhavaram Milk Colony, cockroach control Madhavaram Milk Colony, termite control Madhavaram Milk Colony, rodent control Madhavaram Milk Colony, bed bug treatment Madhavaram Milk Colony, pest control Chennai, No.1 Quality Pest Control",
}

export default function MadhavaramMilkColonyPage() {
  return <MadhavaramMilkColonyPestControlClient />
}
