"use client"
import Image from "next/image"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"

export function PeramburPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Perambur, Chennai – Trusted Pest Control Services</title>
        <meta
          name="description"
          content="Looking for reliable pest control services in Perambur, Chennai? Our expert team offers comprehensive control services to keep your home and business pest-free."
        />
        <meta
          name="keywords"
          content="pest control Perambur, general pest control, cockroach control, rodent control, eco-friendly pest solutions, cleaning services"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/perambur" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Perambur",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/perambur",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Parrys",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.1066,
                "longitude": 80.2365
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹"
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Perambur"
        description="Professional & Affordable Pest Control Solutions"
      />

      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Best Pest Control in Perambur, Chennai – Trusted Pest Control Services
            </h2>
            <p className="mb-4">
              Looking for reliable pest control services in Perambur, Chennai? Our expert team offers comprehensive
              control services to keep your home and business pest-free. From general pest control to specialized
              cockroach control, we provide fast, effective, and affordable solutions tailored for Perambur residents.
            </p>
            <div className="bg-amber-100 p-4 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-2">🐜 Our Pest Control Services in Perambur:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>🐞 General Pest Control</li>
                <li>🪳 Cockroach Control</li>
                <li>🐀 Rodent Control</li>
                <li>🧹 Professional Cleaning Services</li>
                <li>🌿 Eco-Friendly Pest Solutions</li>
              </ul>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Pest Control Service in Perambur"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Why Choose Us for Pest Control in Perambur?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Professionals</h3>
              <p>Skilled technicians offering reliable control services.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Top Pest Control Solutions</h3>
              <p>Recognized as one of the top pest control companies in Perambur.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Pest Control Charges</h3>
              <p>Competitive pricing with no hidden fees.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Highly Rated Reviews</h3>
              <p>Trusted and recommended by customers across Perambur and Chennai.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Thorough Cleaning Services</h3>
              <p>Complete pest eradication combined with cleaning for lasting results.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Perambur</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Chennai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Surrounding Localities</h3>
          </div>
        </div>
      </section>

      <ProcessSection />
      <ServicesList />
      <BenefitsSection />
      <TestimonialsSection />

      <section className="container mx-auto px-4 py-12">
        <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold mb-4 text-center">Contact Us Today for Pest Control in Perambur</h2>
          <p className="text-center mb-6">
            Don't wait for pests to take over! Call us now for a free quote on the best pest control services in
            Perambur, Chennai.
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📱</span>
              <span>Phone: +91 7558108600</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📧</span>
              <span>Email: no1qualitypestcontrol@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">🌐</span>
              <span>Website: www.no1qualitypestcontrol.com</span>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
