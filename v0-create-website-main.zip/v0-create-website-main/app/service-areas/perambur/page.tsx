import type { Metadata } from "next"
import { PeramburPestControlClient } from "./PeramburPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Perambur, Chennai – Trusted Pest Control Services",
  description:
    "Looking for reliable pest control services in Perambur, Chennai? Our expert team offers comprehensive control services to keep your home and business pest-free.",
}

export default function PeramburPage() {
  return <PeramburPestControlClient />
}
