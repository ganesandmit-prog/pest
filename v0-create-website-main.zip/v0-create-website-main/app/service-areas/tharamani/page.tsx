import type { Metadata } from "next"
import { TharamaniPestControlClient } from "./TharamaniPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Tharamani, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Tharamani, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Tharamani, Tharamani pest services, pest management Tharamani, pest control near me, No.1 Quality Pest Control Tharamani, mosquito control Tharamani, termite treatment Tharamani, IT park pest control Tharamani",
}

export default function TharamaniPage() {
  return <TharamaniPestControlClient />
}
