"use client"
import { Helmet } from "react-helmet"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export default function NeelankaraiPestControlClient() {
  return (
    <div className="flex min-h-screen flex-col">
      <Helmet>
        <title>Pest Control Services in Neelankarai, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Neelankarai, Chennai. We offer termite control, rodent removal, and safe pest solutions for homes and businesses."
        />
        <meta
          name="keywords"
          content="pest control Neelankarai, termite control Neelankarai, rodent removal Chennai, pest management Neelankarai, No.1 Quality Pest Control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/neelankarai" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Neelankarai",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/neelankarai",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Neelankarai",
                "addressRegion": "Chennai",
                "postalCode": "600041",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 12.9484,
                "longitude": 80.2591
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <PageHeader
          title="Pest Control Services in Neelankarai, Chennai"
          subtitle="Fast, Safe & Effective Pest Management Solutions"
        />

        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">
              Trusted Pest Control in Neelankarai, Chennai – Fast, Safe & Effective!
            </h2>
            <p className="mt-4 text-gray-600">
              Looking for reliable pest control services in Neelankarai? At No.1 Quality Pest Control, we specialize in
              delivering top-quality pest control solutions tailored to homes and businesses in Neelankarai Chennai.
              Whether you need termite control, general pest management, or rodent removal, our expert team uses safe,
              proven methods to protect your property.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">
              Our Pest Control Services in Neelankarai Include:
            </h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Termite Control & Prevention</li>
              <li>Rodent Control Services</li>
              <li>Mosquito & Insect Management</li>
              <li>Cockroach & Ant Control</li>
              <li>Eco-Friendly & Organic Pest Control Options</li>
              <li>Bed Bug Treatment</li>
            </ul>

            <p className="mt-4 text-gray-600">
              We are committed to using government-approved chemicals ensuring safety for your family and pets.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">Serving Neelankarai and Surrounding Areas:</h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Neelankarai Chennai</li>
              <li>Injambakkam</li>
              <li>Palavakkam</li>
              <li>Thoraipakkam</li>
              <li>Old Mahabalipuram Road (OMR)</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-800">
              Why Choose No.1 Quality Pest Control in Neelankarai?
            </h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Over 10 Years of Professional Experience</li>
              <li>Certified, Skilled Pest Control Technicians</li>
              <li>Affordable Pricing & Transparent Quotes</li>
              <li>Quick Response & Hassle-Free Scheduling</li>
              <li>Long-Lasting Pest Protection</li>
            </ul>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">Customer Testimonials:</h3>
            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "Excellent termite control service in Neelankarai by No.1 Quality Pest Control. Very professional and
                effective."
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Suresh M., Neelankarai</p>
            </div>

            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "Reliable pest control services with quick response and friendly staff. Highly recommended!"
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Anita R., Chennai</p>
            </div>

            <div className="mt-6 rounded-lg bg-blue-50 p-4">
              <h4 className="font-semibold text-blue-800">Contact Us Today for Pest Control in Neelankarai!</h4>
              <p className="mt-2 text-blue-700">
                📍 Location: Neelankarai, Chennai, Tamil Nadu
                <br />📞 Call: +91 75581 08600
                <br />📧 Email: no1qualitypestcontrol@gmail.com
                <br />🌐 Website: www.no1qualitypestcontrol.com
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Our Pest Control Process in Neelankarai</h2>
          <ProcessSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Why Neelankarai Residents Choose Us</h2>
          <BenefitsSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Pest Control Services We Offer in Neelankarai</h2>
          <ServicesList />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Testimonials from Neelankarai Customers</h2>
          <TestimonialsSection location="Neelankarai" />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Contact Us for Pest Control in Neelankarai</h2>
          <div className="mt-6">
            <ContactForm location="Neelankarai" />
          </div>
        </div>
      </div>
    </div>
  )
}
