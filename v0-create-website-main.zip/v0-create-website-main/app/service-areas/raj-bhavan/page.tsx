import type { Metadata } from "next"
import { RajBhavanPestControlClient } from "./RajBhavanPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Raj Bhavan, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Raj Bhavan, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Raj Bhavan, pest services Raj Bhavan, cockroach control Raj Bhavan, termite treatment Raj Bhavan, bed bug control Raj Bhavan, mosquito control Raj Bhavan, rodent control Raj Bhavan, pest control services Raj Bhavan Chennai",
}

export default function RajBhavanPage() {
  return <RajBhavanPestControlClient />
}
