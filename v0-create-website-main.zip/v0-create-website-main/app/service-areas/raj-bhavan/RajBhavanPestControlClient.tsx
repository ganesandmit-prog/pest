"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function RajBhavanPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Raj Bhavan, Chennai"
        description="Professional & affordable pest control services in Raj Bhavan. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            ✅ Trusted Pest Control in Raj Bhavan, Chennai – Professional & Effective Pest Control Services
          </h2>

          <p>
            Looking for reliable pest control services in Raj Bhavan, Chennai? You're in the right place. Our expert
            team provides end-to-end pest control solutions to protect your home or office from cockroaches, termites,
            bed bugs, rodents, and more. Whether you need general pest control or targeted treatments, we deliver
            eco-friendly, fast, and affordable services in and around Raj Bhavan Road, Chennai.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pest Control Services in Raj Bhavan Include:</h3>

          <ul>
            <li>🪳 Cockroach Control (Gel & Spray Treatment)</li>
            <li>🛏️ Bed Bugs Treatment</li>
            <li>🐜 General Pest Control</li>
            <li>🦟 Mosquito Control</li>
            <li>🐀 Rodent Control</li>
            <li>🌿 Eco-Friendly & Child-Safe Pest Solutions</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Our Pest Control in Raj Bhavan, Chennai?</h3>

          <ul>
            <li>✔️ Experienced Pest Control Professionals – Trained and certified experts.</li>
            <li>✔️ Targeted Pest Removal – Specialized in both residential and commercial spaces.</li>
            <li>✔️ Advanced & Safe Treatments – Odor-free and environmentally friendly.</li>
            <li>✔️ Affordable Pest Control Rates – No hidden charges, best pricing in Chennai.</li>
            <li>✔️ Trusted by Locals in Raj Bhavan Road – Excellent client reviews and repeat customers.</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 Serving Raj Bhavan and Nearby Areas:</h3>

          <ul>
            <li>Raj Bhavan Road, Chennai</li>
            <li>Mount Road</li>
            <li>Nandanam</li>
            <li>Guindy</li>
            <li>Adyar</li>
            <li>Mylapore</li>
            <li>Nearby residential and commercial spaces</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">🔍 We Help You Rank for:</h3>

          <ul>
            <li>Pest Control in Raj Bhavan Chennai</li>
            <li>Raj Bhavan Road Cockroach Control</li>
            <li>General Pest Control Services in Chennai</li>
            <li>Bed Bugs Control Raj Bhavan</li>
            <li>Professional Control Services Near Me</li>
            <li>Eco-Friendly Pest Treatment Chennai</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Contact Us for Pest Control in Raj Bhavan, Chennai!</h3>
            <p>Don't wait for pests to take over — call the #1 Pest Control Service in Raj Bhavan today!</p>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
