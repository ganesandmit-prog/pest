import type { Metadata } from "next"
import TirusulamPestControlClient from "./TirusulamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Tirusulam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Tirusulam, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with 45+ years of experience.",
  keywords:
    "pest control Tirusulam, Tirusulam pest services, cockroach control Tirusulam, termite treatment Tirusulam, bed bug control Tirusulam, rodent control Tirusulam, mosquito control Tirusulam, pest management Tirusulam Chennai",
}

export default function TirusulamPestControlPage() {
  return <TirusulamPestControlClient />
}
