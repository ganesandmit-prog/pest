"use client"

import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function TirusulamPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Professional Pest Control Services in Tirusulam, Chennai"
        description="No.1 Quality Pest Control provides expert pest management solutions in Tirusulam. Our 45+ years of experience ensures your home and business remain pest-free."
      />

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <h2 className="text-3xl font-bold text-gray-900">Trusted Pest Control Services in Tirusulam</h2>

              <p className="text-lg text-gray-700">
                No.1 Quality Pest Control is Tirusulam's premier pest management provider, delivering comprehensive
                solutions to residential and commercial properties throughout the area. With over 45 years of industry
                experience, our certified technicians are equipped to handle all pest infestations with precision and
                care.
              </p>

              <p className="text-lg text-gray-700">
                Tirusulam residents face unique pest challenges due to the area's proximity to the airport and
                transportation hubs. Our locally-based team understands these specific challenges and provides
                customized treatment plans that address the root causes of infestations while ensuring the safety of
                your family, pets, and the environment.
              </p>

              <p className="text-lg text-gray-700">
                We offer same-day service throughout Tirusulam and surrounding areas, with flexible appointment times to
                accommodate your busy schedule. Our comprehensive pest control solutions include thorough inspections,
                targeted treatments, and preventative measures to ensure long-lasting results.
              </p>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                <p className="text-yellow-700">
                  <strong>Local Expertise:</strong> Our technicians are familiar with Tirusulam's specific pest patterns
                  and challenges, allowing us to provide more effective and targeted treatments.
                </p>
              </div>

              <h3 className="text-2xl font-bold text-gray-900 mt-8">
                Why Tirusulam Residents Choose Our Pest Control Services
              </h3>

              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Comprehensive pest management solutions tailored to Tirusulam's unique environment</li>
                <li>45+ years of industry experience with deep knowledge of local pest behaviors</li>
                <li>Eco-friendly and family-safe treatment options</li>
                <li>Transparent pricing with no hidden fees</li>
                <li>Fully licensed and insured professionals</li>
                <li>Emergency and same-day services available throughout Tirusulam</li>
                <li>Satisfaction guarantee on all our services</li>
              </ul>

              <p className="text-lg text-gray-700 mt-6">
                Whether you're dealing with cockroaches, rodents, termites, bed bugs, or any other pest issue in
                Tirusulam, our team is ready to help restore the comfort and safety of your property. Contact us today
                to schedule your inspection and take the first step toward a pest-free environment.
              </p>
            </div>

            <div className="lg:col-span-1 space-y-8">
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Our Tirusulam Service Area</h3>
                <p className="text-gray-700 mb-4">
                  We provide comprehensive pest control services throughout Tirusulam and nearby areas, including:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-gray-700">
                  <li>Tirusulam Main Road</li>
                  <li>Airport Vicinity</li>
                  <li>GST Road Stretch</li>
                  <li>Residential Colonies</li>
                  <li>Neighboring residential layouts</li>
                  <li>All commercial zones</li>
                </ul>
              </div>

              <div className="bg-green-50 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Tirusulam Pest Control Highlights</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <svg
                      className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Same-day service available</span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Residential & commercial expertise</span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Eco-friendly treatment options</span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Customized pest management plans</span>
                  </li>
                  <li className="flex items-start">
                    <svg
                      className="h-5 w-5 text-green-500 mr-2 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Free follow-up visits if needed</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <section className="container mx-auto px-4 py-16">
          <ContactForm location="Tirusulam" />
        </section>

        <section className="container mx-auto px-4 py-8">
          <QuickLinks />
        </section>
      </main>
    </div>
  )
}

export default TirusulamPestControlClient
