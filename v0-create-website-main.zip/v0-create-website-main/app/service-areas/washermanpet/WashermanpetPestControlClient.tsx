"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import ContactForm from "@/components/contact-form"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"

export default function WashermanpetPestControlClient() {
  return (
    <>
      <PageHeader
        title="Pest Control Services in Washermanpet, Chennai"
        backgroundImage="https://images.unsplash.com/photo-1605146768851-eda79da39897"
        subtitle="Professional & Affordable Pest Control in Washermanpet"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <h2 className="text-3xl font-bold mb-4">Best Pest Control Services in Washermanpet, Chennai</h2>
                <p className="mb-6">
                  Washermanpet, a bustling residential and commercial area in North Chennai, faces unique pest
                  challenges due to its proximity to the harbor and dense population. No.1 Quality Pest Control offers
                  specialized pest management solutions for Washermanpet residents and businesses, addressing common
                  issues like cockroach infestations in older buildings, rodent problems near commercial establishments,
                  and termite concerns in wooden structures.
                </p>

                <p className="mb-6">
                  Our team of certified pest control experts in Washermanpet provides comprehensive services including
                  termite control, cockroach treatment, bed bug elimination, rodent management, and mosquito control. We
                  use eco-friendly, child-safe methods that effectively eliminate pests while ensuring the safety of
                  your family and pets.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Complete pest protection for homes and businesses in Washermanpet</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Safe, eco-friendly treatments suitable for residential areas</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Specialized solutions for old buildings and commercial establishments</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>45+ years of experience in pest management across Chennai</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Affordable pest control services with guaranteed results</p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">Trusted by 50,000+ Happy Customers in Chennai!</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1605146768851-eda79da39897"
                  alt="Pest Control Services in Washermanpet"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ServicesList />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Pest Control Projects in Washermanpet</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1590496794008-383c8070b257"
                    alt="Residential Pest Control in Washermanpet"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Residential Pest Management</h3>
                  <p className="text-gray-600 mb-4">
                    Complete pest protection for apartments and individual homes in Washermanpet, focusing on cockroach
                    and rodent control.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1604754742629-3e0498a8211f"
                    alt="Commercial Pest Control in Washermanpet"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Commercial Pest Solutions</h3>
                  <p className="text-gray-600 mb-4">
                    Specialized pest control for shops, warehouses, and offices in Washermanpet's commercial areas.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1635340909894-1665936a1f11"
                    alt="Termite Control in Washermanpet"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Termite Treatment</h3>
                  <p className="text-gray-600 mb-4">
                    Comprehensive termite protection for older buildings and wooden structures in Washermanpet.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ProcessSection />

      <BenefitsSection />

      <TestimonialsSection />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Areas We Serve in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We provide professional pest control services across Chennai, including:
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
            {[
              "Adyar",
              "Anna Nagar",
              "Ashok Nagar",
              "Besant Nagar",
              "Chromepet",
              "Egmore",
              "Guindy",
              "KK Nagar",
              "Kodambakkam",
              "Madipakkam",
              "Mylapore",
              "Nungambakkam",
              "OMR",
              "Porur",
              "Saidapet",
              "T. Nagar",
              "Tambaram",
              "Thiruvanmiyur",
              "Vadapalani",
              "Velachery",
              "Washermanpet",
              "West Mambalam",
            ].map((area, index) => (
              <AnimatedSection key={area} animation="fadeIn" delay={index * 0.05}>
                <Link href={`/service-areas/${area.toLowerCase().replace(/\s+/g, "-")}`}>
                  <motion.div
                    className="bg-white p-3 rounded-lg shadow-sm text-center hover:bg-light-green hover:text-white transition-colors"
                    whileHover={{ y: -5 }}
                  >
                    {area}
                  </motion.div>
                </Link>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">
              Frequently Asked Questions About Pest Control in Washermanpet
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">What are the common pests found in Washermanpet, Chennai?</h3>
                <p className="text-gray-600">
                  Washermanpet commonly experiences issues with cockroaches, rodents, termites, bed bugs, and
                  mosquitoes. Due to its proximity to the harbor and older buildings, rodent and cockroach infestations
                  are particularly prevalent in this area.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">How much does pest control cost in Washermanpet?</h3>
                <p className="text-gray-600">
                  Pest control services in Washermanpet typically range from ₹1,000 to ₹10,000 depending on the type of
                  pest, severity of infestation, and property size. We offer competitive rates with free inspection and
                  customized treatment plans.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">
                  Are your pest control treatments safe for children and pets in Washermanpet homes?
                </h3>
                <p className="text-gray-600">
                  Yes, we use eco-friendly, low-toxicity products that are safe for families and pets. We recommend
                  vacating the premises for 2-4 hours after treatment as a precautionary measure, especially for
                  treatments in residential areas of Washermanpet.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">
                  How do you handle termite problems in older buildings in Washermanpet?
                </h3>
                <p className="text-gray-600">
                  For Washermanpet's older buildings, we conduct thorough inspections to identify termite entry points
                  and nesting areas. We then apply specialized termite treatments including soil treatment, wood
                  treatment, and baiting systems designed to eliminate colonies while preserving structural integrity.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Get Professional Pest Control in Washermanpet Today!</h2>
            <p className="mb-6">
              Contact No.1 Quality Pest Control for safe, effective, and affordable pest management solutions in
              Washermanpet, Chennai.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Pest Control in Washermanpet</h2>
          <ContactForm location="Washermanpet" />
        </div>
      </section>
    </>
  )
}
