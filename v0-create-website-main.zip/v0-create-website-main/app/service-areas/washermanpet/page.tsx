import type { Metadata } from "next"
import WashermanpetPestControlClient from "./WashermanpetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Washermanpet, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Washermanpet, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with safe, effective treatments. Call now!",
  keywords:
    "pest control Washermanpet, termite control Washermanpet, cockroach control Washermanpet, bed bug treatment Washermanpet, rodent control Washermanpet, mosquito control Washermanpet, pest control services Washermanpet Chennai, best pest control Washermanpet",
}

export default function WashermanpetPestControlPage() {
  return <WashermanpetPestControlClient />
}
