"use client"
import Image from "next/image"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"

export function PeerkankaranaiPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Peerkankaranai, Chennai – Trusted Pest Control Services</title>
        <meta
          name="description"
          content="Searching for reliable pest control services in Peerkankaranai, Chennai? Our expert control services provide effective pest management for both residential and commercial properties."
        />
        <meta
          name="keywords"
          content="pest control Peerkankaranai, bed bugs treatment, general pest control, rodent control, warehouse pest control, eco-friendly pest control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/peerkankaranai" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Peerkankaranai",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/peerkankaranai",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Parrys",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 12.9075,
                "longitude": 80.0617
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹"
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Peerkankaranai"
        description="Professional & Affordable Pest Control Solutions"
      />

      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Best Pest Control in Peerkankaranai, Chennai – Trusted Pest Control Services
            </h2>
            <p className="mb-4">
              Searching for reliable pest control services in Peerkankaranai, Chennai? Our expert control services
              provide effective pest management for both residential and commercial properties. From bed bugs treatment
              to warehouse pest solutions, we deliver professional, eco-friendly, and affordable pest control tailored
              for Peerkankaranai.
            </p>
            <div className="bg-amber-100 p-4 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-2">🐜 Our Pest Control Services in Peerkankaranai:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>🐞 Bed Bugs Treatment & Removal</li>
                <li>🐜 General Pest Control Solutions</li>
                <li>🐀 Rodent & Rat Control for Warehouses & Homes</li>
                <li>🧹 Professional Cleaning & Sanitization</li>
                <li>🌱 Eco-Friendly Pest Control Options</li>
                <li>🏢 Commercial & Residential Pest Control</li>
              </ul>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Pest Control Service in Peerkankaranai"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Why Choose Our Pest Control Company in Peerkankaranai?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Professionals</h3>
              <p>Skilled technicians delivering effective control services across Chennai.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Comprehensive Solutions</h3>
              <p>Tailored pest control for residential homes, warehouses, and commercial spaces.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Pricing</h3>
              <p>Competitive quotes with no hidden charges.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Trusted on Sulekha</h3>
              <p>Rated highly by customers throughout Peerkankaranai and Chennai.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Eco-Friendly & Safe</h3>
              <p>Using environment-friendly treatments safe for your family and pets.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Peerkankaranai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Chennai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Nearby Localities</h3>
          </div>
        </div>
      </section>

      <ProcessSection />
      <ServicesList />
      <BenefitsSection />
      <TestimonialsSection />

      <section className="container mx-auto px-4 py-12">
        <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold mb-4 text-center">Contact Us for Pest Control in Peerkankaranai Today!</h2>
          <p className="text-center mb-6">
            Protect your property with the best pest control services in Peerkankaranai. Call now for a free quote and
            quick, reliable control services designed to keep pests away for good!
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📱</span>
              <span>Phone: +91 7558108600</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📧</span>
              <span>Email: no1qualitypestcontrol@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">🌐</span>
              <span>Website: www.no1qualitypestcontrol.com</span>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
