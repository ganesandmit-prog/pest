import type { Metadata } from "next"
import { PeerkankaranaiPestControlClient } from "./PeerkankaranaiPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Peerkankaranai, Chennai – Trusted Pest Control Services",
  description:
    "Searching for reliable pest control services in Peerkankaranai, Chennai? Our expert control services provide effective pest management for both residential and commercial properties.",
}

export default function PeerkankaranaiPage() {
  return <PeerkankaranaiPestControlClient />
}
