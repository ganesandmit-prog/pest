import type { Metadata } from "next"
import { ThiruvanmiyurPestControlClient } from "./ThiruvanmiyurPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Thiruvanmiyur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thiruvanmiyur, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Thiruvanmiyur, Thiruvanmiyur pest services, pest management Thiruvanmiyur, pest control near me, No.1 Quality Pest Control Thiruvanmiyur, mosquito control Thiruvanmiyur, termite treatment Thiruvanmiyur, beach area pest control Thiruvanmiyur",
}

export default function ThiruvanmiyurPage() {
  return <ThiruvanmiyurPestControlClient />
}
