"use client"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function ThiruvanmiyurPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Professional Pest Control Services in Thiruvanmiyur, Chennai"
        description="No.1 Quality Pest Control provides expert pest management solutions in Thiruvanmiyur. Our 45+ years of experience ensures your home and business remain pest-free."
        keywords="pest control Thiruvanmiyur, Thiruvanmiyur pest services, pest management Thiruvanmiyur, pest control near me, No.1 Quality Pest Control Thiruvanmiyur"
        location="Thiruvanmiyur"
      />

      <main className="flex-grow">
        <section className="container mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">Pest Control Services in Thiruvanmiyur, Chennai</h2>
              <p className="mb-4">
                Thiruvanmiyur, a prime residential area in South Chennai with beautiful beaches, requires specialized
                pest control solutions to address its unique coastal and urban pest challenges. No.1 Quality Pest
                Control brings 45+ years of expertise to Thiruvanmiyur, offering comprehensive pest management services
                tailored to the specific needs of this upscale locality.
              </p>
              <p className="mb-4">
                Our team of certified pest control specialists in Thiruvanmiyur is equipped with advanced tools and
                environmentally friendly treatments to effectively eliminate pests while ensuring the safety of your
                family, employees, and customers. We understand the importance of maintaining a pest-free environment in
                both residential apartments and commercial establishments in Thiruvanmiyur.
              </p>
              <p className="mb-4">
                Whether you're dealing with mosquitoes from nearby water bodies, termites affecting your property, or
                rodents in your home, our Thiruvanmiyur pest control team provides prompt, reliable, and effective
                solutions. We serve all areas of Thiruvanmiyur including areas near the beach, ECR, and surrounding
                neighborhoods.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">Common Pest Problems in Thiruvanmiyur</h2>
              <p className="mb-4">
                Thiruvanmiyur faces several pest challenges due to its coastal location, urban development, and the
                tropical climate of Chennai. Some common pest issues in Thiruvanmiyur include:
              </p>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Mosquito Infestations:</strong> Due to proximity to the beach and water bodies, mosquito
                  control is essential in Thiruvanmiyur.
                </li>
                <li>
                  <strong>Termite Problems:</strong> Properties in Thiruvanmiyur are particularly vulnerable to termite
                  damage due to the coastal humidity.
                </li>
                <li>
                  <strong>Rodent Control:</strong> Mice and rats are frequently reported in both residential and
                  commercial areas.
                </li>
                <li>
                  <strong>Cockroach Infestations:</strong> Common in residential buildings and restaurants in
                  Thiruvanmiyur.
                </li>
                <li>
                  <strong>Bed Bug Treatments:</strong> Increasingly needed in residential apartments and service
                  apartments in the area.
                </li>
              </ul>

              <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Our Pest Control Service in Thiruvanmiyur?</h2>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Local Expertise:</strong> Our technicians understand Thiruvanmiyur's specific pest patterns
                  and challenges.
                </li>
                <li>
                  <strong>Customized Solutions:</strong> We develop tailored pest management plans for each property in
                  Thiruvanmiyur.
                </li>
                <li>
                  <strong>Eco-Friendly Approaches:</strong> We prioritize green pest control methods that are safe for
                  families and pets.
                </li>
                <li>
                  <strong>Preventive Strategies:</strong> Beyond treatment, we help Thiruvanmiyur residents prevent
                  future infestations.
                </li>
                <li>
                  <strong>Emergency Response:</strong> Quick service for urgent pest problems in Thiruvanmiyur.
                </li>
                <li>
                  <strong>Comprehensive Coverage:</strong> We handle all types of pests common to the Thiruvanmiyur
                  area.
                </li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <ContactForm location="Thiruvanmiyur" />
              <div className="mt-8">
                <QuickLinks />
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection location="Thiruvanmiyur" />
      </main>
    </div>
  )
}
