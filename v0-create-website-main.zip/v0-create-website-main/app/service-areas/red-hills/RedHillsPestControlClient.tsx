"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function RedHillsPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Red Hills, Chennai"
        description="Professional & affordable pest control services in Red Hills. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            ✅ Pest Control in Red Hills, Chennai – Trusted & Natural Pest Solutions
          </h2>

          <p>
            Searching for reliable pest control in Red Hills, Chennai? We offer professional, eco-friendly pest control
            services designed to eliminate all types of pests from your home or commercial space. Whether it's cockroach
            control, termite treatment, or red ant infestation, our certified team delivers long-lasting, safe solutions
            tailored to your needs.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pest Control Services in Red Hills Include:</h3>

          <ul>
            <li>🪳 Cockroach Control (Gel & Odorless Spray)</li>
            <li>🐜 Red Ants and General Ant Control</li>
            <li>🐀 Rodent & Mice Removal</li>
            <li>🛏️ Bed Bugs Treatment</li>
            <li>🦟 Mosquito Control (Indoor & Outdoor Fogging)</li>
            <li>🌿 Natural Pest Solutions – Child-safe, eco-based methods</li>
            <li>🧱 Termite Control for Homes & Foundations</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Us in Red Hills, Chennai?</h3>

          <ul>
            <li>✔️ Experienced & Certified Pest Experts</li>
            <li>✔️ Customized Treatment Plans for homes, apartments, and offices</li>
            <li>✔️ Natural & Eco-Friendly Solutions available on request</li>
            <li>✔️ Affordable Pricing – Transparent pest control cost in Red Hills</li>
            <li>✔️ Quick & Reliable Service – Same-day response available</li>
            <li>✔️ Excellent Reviews from Red Hills Residents</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 Areas We Serve Around Red Hills:</h3>

          <ul>
            <li>Red Hills, Chennai</li>
            <li>Puzhal</li>
            <li>Sholavaram</li>
            <li>Adayalampattu</li>
            <li>Manali</li>
            <li>Madhavaram</li>
            <li>Nearby Residential & Commercial Zones</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">🔍 Keywords We Target for Top SEO Ranking:</h3>

          <ul>
            <li>Pest Control in Red Hills</li>
            <li>Hills Pest Control Services Chennai</li>
            <li>Natural Pest Control Red Hills</li>
            <li>Red Ants Pest Solution Chennai</li>
            <li>Eco-Friendly Pest Services in Chennai</li>
            <li>Best Pest Control Near Red Hills Chennai</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">
              📞 Contact the No.1 Pest Control Service in Red Hills Today!
            </h3>
            <p>
              Don't let pests take over your space. Call the trusted pest control team in Red Hills, Chennai for fast
              relief and lasting protection!
            </p>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
