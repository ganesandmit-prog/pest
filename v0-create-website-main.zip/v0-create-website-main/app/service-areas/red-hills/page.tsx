import type { Metadata } from "next"
import { RedHillsPestControlClient } from "./RedHillsPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Red Hills, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Red Hills, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Red Hills, pest services Red Hills, cockroach control Red Hills, termite treatment Red Hills, bed bug control Red Hills, mosquito control Red Hills, rodent control Red Hills, pest control services Red Hills Chennai",
}

export default function RedHillsPage() {
  return <RedHillsPestControlClient />
}
