import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import PerungudiPestControlClient from "./PerungudiPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Perungudi Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Perungudi? No.1 Quality Pest Control offers reliable, safe, and affordable pest control services in Perungudi Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function PerungudiPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Perungudi Chennai"
        subtitle="Professional & Affordable Pest Control Services in Perungudi"
      />
      <PerungudiPestControlClient />
    </main>
  )
}
