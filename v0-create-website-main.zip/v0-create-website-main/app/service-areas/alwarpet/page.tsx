import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Alwarpet - Chennai's Trusted Experts",
  description:
    "Looking for the most effective pest control in Alwarpet? No.1 Quality Pest Control is the go-to name in general and residential pest control services in Alwarpet, Chennai 600018.",
}

export default function AlwarpetPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Alwarpet"
        subtitle="Professional & Affordable Pest Control Services in Alwarpet Chennai"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Alwarpet</h2>
            <p className="mb-4">
              Looking for the most effective pest control in Alwarpet? You've reached No.1 Quality Pest Control – the
              go-to name in general and residential pest control services in Alwarpet, Chennai 600018.
            </p>
            <p className="mb-4">
              Whether it's cockroaches, termites, ants, or rodents, we use safe and powerful solutions to protect your
              home and office from unwanted pests.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Why We Are the Best Pest Control Company in Alwarpet?
            </h2>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Advanced techniques for residential & general pest control</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Trusted by hundreds in Alwarpet Chennai 600018</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Better than Acme Pest Control or Leader Pest Control – we deliver results</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Transparent pricing & free inspection</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Rated ★★★★★ on Sulekha & Google</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Tailored treatment plans that actually work</span>
              </li>
            </ul>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Alwarpet Include:</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Cockroach Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Termite Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Rodent & Rat Removal</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Mosquito Treatment</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Bed Bug Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">General Pest Management</div>
            </div>
            <p>
              We are proud to be a top-rated pest control company in Alwarpet, focused on cleaning and controlling all
              common pests using eco-friendly & odorless methods.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Residential Pest Control in Alwarpet – Chennai</h2>
            <p className="mb-4">Need residential pest control for your home, apartment, or villa?</p>
            <p className="mb-4">We provide long-lasting, affordable protection that's:</p>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Safe for children and pets</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Designed for Chennai's climate</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Backed by service guarantee</span>
              </li>
            </ul>
            <p className="mt-4">
              From termites to cockroaches, we're the most reliable control service in Alwarpet Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Serving Alwarpet – Chennai 600018 & Nearby Areas
            </h2>
            <p className="mb-4">We proudly serve Alwarpet and surrounding locations like:</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Teynampet</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Mylapore</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Mandaveli</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Nandanam</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Gopalapuram</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Royapettah</div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.6}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Contact the Best Pest Control in Alwarpet Today</h2>
            <p className="mb-4">Protect your space with Chennai's trusted pest experts.</p>
            <p className="mb-4">
              Call us for the most professional pest control services in Alwarpet – fast, effective, and affordable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
            </div>
            <div>
              <p>
                <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
              </p>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Alwarpet
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
