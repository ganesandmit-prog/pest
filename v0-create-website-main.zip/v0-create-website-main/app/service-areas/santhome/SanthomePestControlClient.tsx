"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SanthomePestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Santhome, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Pest Control in Santhome – Trusted Pest Control Services in Santhome, Chennai
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for reliable pest control services in Santhome, Chennai? Our expert team provides efficient
                  and eco-friendly solutions to keep your home and office safe from pests. Whether it's general pest
                  control, termite elimination, or specialized treatments, we offer cost-effective and professional
                  services to ensure a pest-free environment.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐜 Our Pest Control Services in Santhome Include:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control – Safe and effective treatment options</li>
                  <li>🐜 Termite Control – Prevention and eradication of termites</li>
                  <li>🦟 Mosquito Control – Fogging and prevention services</li>
                  <li>🐀 Rodent Control – Quick and humane rodent elimination</li>
                  <li>🌿 Eco-Friendly Pest Solutions – Safe for children and pets</li>
                  <li>🧹 Post-Treatment Cleaning Services – For a pest-free and hygienic space</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  💡 Why Choose Our Pest Control Service in Santhome?
                </h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Experienced Technicians – Skilled in all types of pest control services</li>
                  <li>✔️ Fast & Efficient – Same-day pest control solutions</li>
                  <li>✔️ Affordable – Competitive pricing with no hidden fees</li>
                  <li>✔️ Customer Satisfaction – Excellent feedback from Santhome and Chennai residents</li>
                  <li>✔️ Eco-Friendly Options – Chemical-free and safe for families and pets</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 We Serve Santhome & Nearby Areas:</h2>

                <ul className="list-none space-y-2">
                  <li>Santhome, Chennai</li>
                  <li>Mylapore</li>
                  <li>R.A. Puram</li>
                  <li>Teynampet</li>
                  <li>Alwarpet</li>
                  <li>Adyar</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact Us for Pest Control in Santhome!</h3>
                  <p>
                    Ensure your home or office is safe with pest control in Santhome. Call today for a free consultation
                    and pest inspection!
                  </p>
                  <p className="mt-4">
                    📱 Call Now: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
