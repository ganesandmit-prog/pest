import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Alwarthirunagar - Trusted Services in Chennai",
  description:
    "Looking for reliable and affordable pest control in Alwarthirunagar? No.1 Quality Pest Control offers top-rated pest control services in Alwarthirunagar, Chennai—ensuring your home and office are completely pest-free.",
}

export default function AlwarthirunagarPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Alwarthirunagar"
        subtitle="Professional & Affordable Pest Control Services in Alwarthirunagar Chennai"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Alwarthirunagar</h2>
            <p className="mb-4">
              Are you searching for reliable and affordable pest control in Alwarthirunagar? Look no further! At No.1
              Quality Pest Control, we offer top-rated pest control services in Alwarthirunagar, Chennai—ensuring your
              home and office are completely pest-free.
            </p>
            <p className="mb-4">
              From cockroach infestations to termite treatment, we use safe and effective pest control methods trusted
              by hundreds across Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Why Choose Us for Pest Control Services in Alwarthirunagar?
            </h2>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>100% Odorless & Safe Chemicals</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Experienced & Certified Pest Control Company in Chennai</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Transparent Charges – No Hidden Costs</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Same-Day Inspection & Treatment</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Trusted by Homes, Villas, and Commercial Spaces</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔️</span>
                <span>Top-Rated on Sulekha and Google Reviews</span>
              </li>
            </ul>
            <p className="mt-4">
              We offer both general and deep pest control services in Alwarthirunagar and nearby areas.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Our Professional Services in Alwarthirunagar Include:
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">🪳 Cockroach Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">🐜 Ant & Termite Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">🐀 Rodent Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">🦟 Mosquito & Bed Bug Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">🧹 Cleaning and Sanitization</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">
                🏠 Residential & Commercial Pest Control
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Residential Pest Control in Alwarthirunagar</h2>
            <p className="mb-4">
              Our residential pest control services ensure that your home stays pest-free year-round. We treat walls,
              floors, corners, furniture, and water drain areas to remove all traces of cockroaches, termites, ants, and
              more.
            </p>
            <p className="mb-4">Looking for general pest control or specific termite treatment? We have you covered.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Areas We Serve Near Alwarthirunagar</h2>
            <p className="mb-4">We offer same-day services in:</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Alwarthirunagar</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Valasaravakkam</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Porur</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Virugambakkam</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">KK Nagar</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Ramapuram</div>
            </div>
            <p className="mt-4">Our pest control company is based in Chennai and serves all surrounding areas.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Best Pest Control Company in Alwarthirunagar – What Sets Us Apart?
            </h2>
            <p className="mb-4">
              While others claim, we deliver results. Our expert team knows how to control pests effectively using
              industry-approved solutions. Whether it's termites or cockroaches, our cleaning and pest control experts
              in Alwarthirunagar ensure your space stays clean, hygienic, and pest-free.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Contact Us Now – Free Inspection!</h2>
            <p className="mb-4">Get the best pest control service in Alwarthirunagar today.</p>
            <p className="mb-4">Our service comes with a guarantee of safety and satisfaction.</p>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
            </div>
            <div>
              <p>
                <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
              </p>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.8}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Alwarthirunagar
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
