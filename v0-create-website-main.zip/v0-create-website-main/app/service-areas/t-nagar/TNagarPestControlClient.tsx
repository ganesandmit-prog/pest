"use client"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function TNagarPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Professional Pest Control Services in T. Nagar, Chennai"
        description="No.1 Quality Pest Control provides expert pest management solutions in T. Nagar. Our 45+ years of experience ensures your home and business remain pest-free."
        keywords="pest control T. Nagar, T. Nagar pest services, pest management T. Nagar, pest control near me, No.1 Quality Pest Control T. Nagar"
        location="T. Nagar"
      />

      <main className="flex-grow">
        <section className="container mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">Pest Control Services in T. Nagar, Chennai</h2>
              <p className="mb-4">
                T. Nagar, Chennai's premier shopping district and a densely populated residential area, requires
                specialized pest control solutions to address its unique urban pest challenges. No.1 Quality Pest
                Control brings 45+ years of expertise to T. Nagar, offering comprehensive pest management services
                tailored to the specific needs of this bustling locality.
              </p>
              <p className="mb-4">
                Our team of certified pest control specialists in T. Nagar is equipped with advanced tools and
                environmentally friendly treatments to effectively eliminate pests while ensuring the safety of your
                family, employees, and customers. We understand the importance of maintaining a pest-free environment in
                both residential apartments and commercial establishments, including the numerous retail stores in T.
                Nagar.
              </p>
              <p className="mb-4">
                Whether you're dealing with cockroaches in your kitchen, rodents in your storage areas, or termites
                threatening your property's structure, our T. Nagar pest control team provides prompt, reliable, and
                effective solutions. We serve all areas of T. Nagar including Pondy Bazaar, Ranganathan Street, and
                surrounding neighborhoods.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">Common Pest Problems in T. Nagar</h2>
              <p className="mb-4">
                T. Nagar faces several pest challenges due to its dense urban development, high commercial activity, and
                the tropical climate of Chennai. Some common pest issues in T. Nagar include:
              </p>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Cockroach Infestations:</strong> Particularly common in residential buildings and food
                  establishments in T. Nagar.
                </li>
                <li>
                  <strong>Rodent Problems:</strong> Mice and rats are frequently reported in commercial areas and
                  markets.
                </li>
                <li>
                  <strong>Termite Damage:</strong> A significant concern for property owners in T. Nagar, especially in
                  older buildings.
                </li>
                <li>
                  <strong>Bed Bug Treatments:</strong> Increasingly needed in residential apartments and hotels in the
                  area.
                </li>
                <li>
                  <strong>Fly Control:</strong> Essential for restaurants and food businesses in this commercial hub.
                </li>
              </ul>

              <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Our Pest Control Service in T. Nagar?</h2>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Local Expertise:</strong> Our technicians understand T. Nagar's specific pest patterns and
                  challenges.
                </li>
                <li>
                  <strong>Customized Solutions:</strong> We develop tailored pest management plans for each property in
                  T. Nagar.
                </li>
                <li>
                  <strong>Eco-Friendly Approaches:</strong> We prioritize green pest control methods that are safe for
                  families and pets.
                </li>
                <li>
                  <strong>Preventive Strategies:</strong> Beyond treatment, we help T. Nagar residents prevent future
                  infestations.
                </li>
                <li>
                  <strong>Emergency Response:</strong> Quick service for urgent pest problems in T. Nagar.
                </li>
                <li>
                  <strong>Comprehensive Coverage:</strong> We handle all types of pests common to the T. Nagar area.
                </li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <ContactForm location="T. Nagar" />
              <div className="mt-8">
                <QuickLinks />
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection location="T. Nagar" />
      </main>
    </div>
  )
}
