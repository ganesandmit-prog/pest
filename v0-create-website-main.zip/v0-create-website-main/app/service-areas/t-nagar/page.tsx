import type { Metadata } from "next"
import { TNagarPestControlClient } from "./TNagarPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in T. Nagar, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in T. Nagar, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control T. Nagar, T. Nagar pest services, pest management T. Nagar, pest control near me, No.1 Quality Pest Control T. Nagar, cockroach control T. Nagar, termite treatment T. Nagar, commercial pest control T. Nagar",
}

export default function TNagarPage() {
  return <TNagarPestControlClient />
}
