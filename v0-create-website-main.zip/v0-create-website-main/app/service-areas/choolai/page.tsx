import type { Metadata } from "next"
import ChoolaiPestControlClient from "./ChoolaiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Choolai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Choolai, Chennai. Trusted by hundreds for effective pest solutions. Call us today for a free inspection!",
  keywords:
    "pest control Choolai, pest control services Choolai, Choolai pest control, cockroach control Choolai, termite control Choolai, bed bug control Choolai, rodent control Choolai",
}

export default function ChoolaiPestControl() {
  return <ChoolaiPestControlClient />
}
