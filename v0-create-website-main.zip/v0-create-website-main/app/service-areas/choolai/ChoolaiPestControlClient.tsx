"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function ChoolaiPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Choolai" subtitle="Trusted by Hundreds!" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Best Pest Control in Choolai, Chennai</h2>
                  <div className="prose max-w-none">
                    <p>
                      Looking for effective pest control services in Choolai? We provide general pest control, cockroach
                      treatment, termite solutions, and rodent control in Choolai, Chennai Tamil Nadu. Our expert
                      exterminators ensure complete safety and long-lasting protection for your home or office.
                    </p>
                    <h3>Our Top Pest Control Services:</h3>
                    <ul>
                      <li>Ant and Termite Control</li>
                      <li>Cockroach Extermination</li>
                      <li>Rodent & Rat Removal</li>
                      <li>Bed Bug Treatments</li>
                      <li>Mosquito Control Services</li>
                      <li>Deep Cleaning & Disinfection</li>
                    </ul>
                    <h3>Why We Are the #1 Pest Control Experts in Choolai?</h3>
                    <ul>
                      <li>Experienced Pest Exterminators</li>
                      <li>Verified by Top Platforms like Sulekha & Justdial</li>
                      <li>Usage of Government-Approved Chemicals</li>
                      <li>Fast Response & 100% Result Guarantee</li>
                      <li>Services Available Across Chennai, Tamil Nadu</li>
                      <li>Affordable Pricing for Residential Pest Control</li>
                    </ul>
                    <h3>Areas We Serve Around Choolai:</h3>
                    <ul>
                      <li>Egmore</li>
                      <li>Vepery</li>
                      <li>Periamet</li>
                      <li>Purasawalkam</li>
                      <li>Kilpauk</li>
                      <li>Park Town</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Choolai"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Choolai"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Choolai</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Choolai home or business? Contact No.1 Quality Pest Control
                        today for a free inspection and quote. Our team of experienced professionals is ready to help
                        you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
