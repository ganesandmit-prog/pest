"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function BesantNagarPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Besant Nagar" subtitle="Trusted by 1000+ Homes & Businesses" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Expert Pest Control in Besant Nagar, Chennai</h2>
                  <div className="prose max-w-none">
                    <p>
                      Are you searching for affordable and reliable pest control services in Besant Nagar? Look no
                      further! Our certified team delivers general pest control, termite treatments, and residential
                      pest solutions in and around Besant Nagar, Chennai.
                    </p>
                    <p>
                      Whether it's cockroaches, rodents, termites, or ants — we've got the best pest control solutions
                      to make your home or office pest-free.
                    </p>
                    <h3>Our Pest Control Services in Besant Nagar Include:</h3>
                    <ul>
                      <li>General Pest Control Services – Cockroaches, Ants, Lizards, Mosquitoes</li>
                      <li>Termite Control – Pre & Post Construction Treatments</li>
                      <li>Rodent Management – Residential & Commercial</li>
                      <li>Bed Bug & Spider Treatment</li>
                      <li>Eco-Friendly & Safe Chemicals</li>
                      <li>Same-Day Service Across Besant Nagar & Chennai</li>
                    </ul>
                    <h3>Why Choose Us?</h3>
                    <ul>
                      <li>Serving Besant Nagar Chennai for Over 10 Years</li>
                      <li>Control Services Tailored to Homes & Businesses</li>
                      <li>Rated Among the Best Pest Control Companies in Chennai</li>
                      <li>Residential Pest Experts – Safe for Kids & Pets</li>
                      <li>Transparent Pricing & Free Inspection Quotes</li>
                      <li>100% Satisfaction Guaranteed</li>
                    </ul>
                    <h3>Serving All Nearby Areas:</h3>
                    <ul>
                      <li>Besant Nagar</li>
                      <li>Adyar</li>
                      <li>Thiruvanmiyur</li>
                      <li>Indira Nagar</li>
                      <li>Elliot's Beach Road</li>
                      <li>Nagar Chennai Region</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Besant Nagar"
            benefits={[
              {
                title: "Safe & Eco-Friendly",
                description:
                  "We use environmentally friendly products that are safe for your family, pets, and the environment.",
                icon: "Shield",
              },
              {
                title: "Experienced Team",
                description:
                  "Our technicians have years of experience in handling all types of pest infestations in Besant Nagar.",
                icon: "Users",
              },
              {
                title: "Customized Solutions",
                description: "We provide tailored pest control plans based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Quick Response",
                description: "We offer same-day service for urgent pest control needs in Besant Nagar.",
                icon: "Clock",
              },
              {
                title: "Guaranteed Results",
                description: "We ensure effective pest elimination with our proven methods and follow-up services.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Besant Nagar"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Besant Nagar</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Besant Nagar home or business? Contact No.1 Quality Pest
                        Control today for a free inspection and quote. Our team of experienced professionals is ready to
                        help you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
