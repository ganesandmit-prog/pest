import type { Metadata } from "next"
import BesantNagarPestControlClient from "./BesantNagarPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Besant Nagar | No.1 Quality Pest Control",
  description:
    "Expert pest control services in Besant Nagar, Chennai. Trusted by 1000+ homes & businesses. Safe, affordable, and effective solutions for all pest problems.",
  keywords:
    "pest control Besant Nagar, pest control services Besant Nagar, Besant Nagar pest control, cockroach control Besant Nagar, termite control Besant Nagar, bed bug control Besant Nagar, rodent control Besant Nagar",
}

export default function BesantNagarPestControl() {
  return <BesantNagarPestControlClient />
}
