"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function PudupetPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Pudupet, Chennai"
        description="Professional & affordable pest control services in Pudupet. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            🛡️ Reliable Pest Control in Pudupet – Expert Services at Affordable Prices
          </h2>

          <p>
            Are you searching for trusted pest control services in Pudupet, Chennai? Look no further! Our professional
            team provides fast, safe, and effective pest solutions tailored for homes and businesses in the Pudupet
            region.
          </p>

          <p>
            From cockroach issues to termite infestations, we offer comprehensive treatment options that are
            budget-friendly and eco-conscious.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐞 Our Pest Control Services in Pudupet:</h3>

          <ul>
            <li>🪳 Cockroach Control – Eliminate disease-carrying pests from your kitchen and home.</li>
            <li>🐜 Termite Treatment – Prevent structural damage with advanced termite protection.</li>
            <li>🦟 Mosquito Control – Safe fogging and larvicide solutions for long-term relief.</li>
            <li>🛏️ Bed Bug Removal – Targeted treatments for total eradication.</li>
            <li>🐁 Rodent Control – Block entry points and remove rats/mice humanely.</li>
            <li>🌿 Eco-Friendly Cleaning & Pest Management</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Us in Pudupet?</h3>

          <ul>
            <li>✔️ Experienced Professionals – With years of expertise across Chennai localities.</li>
            <li>✔️ General Pest Control Specialists – From ants to termites, we handle it all.</li>
            <li>✔️ Affordable and Transparent Pricing – No hidden charges.</li>
            <li>✔️ Quick Response Time – Fast service in Pudupet and surrounding areas.</li>
            <li>✔️ Eco-Safe Products – Safe for kids, pets, and the environment.</li>
            <li>✔️ Post-Cleaning & Disinfection Available – Keep your space sanitized post-treatment.</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 Serving Pest Control in:</h3>

          <ul>
            <li>Pudupet</li>
            <li>Pudupet-Chennai border areas</li>
            <li>Nearby residential colonies and commercial buildings</li>
            <li>Residential Apartments & Commercial Spaces</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Contact Us Today!</h3>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
