import type { Metadata } from "next"
import { PudupetPestControlClient } from "./PudupetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Pudupet, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Pudupet, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Pudupet, pest services Pudupet, cockroach control Pudupet, termite treatment Pudupet, bed bug control Pudupet, mosquito control Pudupet, rodent control Pudupet, pest control services Pudupet Chennai",
}

export default function PudupetPage() {
  return <PudupetPestControlClient />
}
