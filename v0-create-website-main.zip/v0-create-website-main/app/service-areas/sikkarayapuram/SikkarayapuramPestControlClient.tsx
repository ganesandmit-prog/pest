"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SikkarayapuramPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Sikkarayapuram, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🐜 Pest Control in Sikkarayapuram – Trusted, Safe & Affordable
              </h1>

              <div className="prose max-w-none">
                <p>
                  Tired of pests invading your space? We offer top-rated pest control services in Sikkarayapuram,
                  Chennai, with safe, effective, and long-lasting solutions for residential and commercial spaces.
                  Whether it's cockroaches, termites, or mosquitoes, we've got you covered.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🧼 Our Sikkarayapuram Pest Control Services:</h2>

                <ul className="list-none space-y-2">
                  <li>🐜 Termite Control – Pre & Post Construction Treatment</li>
                  <li>🪳 Cockroach Removal – Odorless Gel & Spray Treatments</li>
                  <li>🦟 Mosquito Fogging</li>
                  <li>🛏️ Bed Bug Extermination</li>
                  <li>🧹 Home & Office Cleaning</li>
                  <li>🧪 Organic Pest Solutions</li>
                  <li>🏠 Residential & Commercial Packages</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">✔️ Why Choose Our Pest Control in Sikkarayapuram?</h2>

                <ul className="list-none space-y-2">
                  <li>🏆 Sharp Pest Control Techniques</li>
                  <li>✅ Sulekha Verified & Highly Reviewed</li>
                  <li>👨‍🔬 Experienced & Certified Professionals</li>
                  <li>💰 Affordable & Transparent Pricing</li>
                  <li>🧒 Child & Pet-Friendly Chemicals</li>
                  <li>🧭 Service Available in Chennai & Surrounding Areas</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Call Us Now:</h3>
                  <p className="mt-4">
                    📱 Phone: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
