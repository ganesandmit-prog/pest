"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"
import ProcessSection from "@/components/process-section"

export default function GopalapuramPestControlClient() {
  const [isFormSubmitted, setIsFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setIsFormSubmitted(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h2 className="text-3xl font-bold mb-6 text-primary">
          Best Pest Control in Gopalapuram, Chennai – Expert Pest Management Services
        </h2>
        <p className="mb-4">
          Looking for pest control services in Gopalapuram, Chennai? Our professional pest control services ensure your
          home or office is pest-free, safe, and secure. From cockroach control to termite treatments, we handle it all
          with efficiency and expertise.
        </p>

        <h3 className="text-2xl font-semibold mt-8 mb-4 text-primary">Our Pest Control Services in Gopalapuram:</h3>
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>🪳 Cockroach Control</li>
          <li>🐜 Termite Control</li>
          <li>🐀 Rodent Control</li>
          <li>🦟 Mosquito Control</li>
          <li>🛏 Bed Bug Treatment</li>
          <li>🌿 Organic Pest Control (Safe and eco-friendly solutions)</li>
          <li>💼 Commercial Pest Control (For offices, restaurants, and more)</li>
        </ul>
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">Why Choose Us for Pest Control in Gopalapuram?</h3>
        <BenefitsSection
          benefits={[
            "Certified Experts – Skilled and experienced pest control technicians",
            "Affordable Pricing – Quality services at competitive rates",
            "Safe & Effective – Eco-friendly pest control solutions for peace of mind",
            "Available 24/7 – Quick response for urgent pest issues",
            "Highly Recommended – Trusted by residents and businesses in Gopalapuram, Chennai",
          ]}
        />
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">Areas We Serve in and Around Gopalapuram, Chennai:</h3>
        <ul className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <li className="bg-gray-100 p-3 rounded-lg text-center">Gopalapuram</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Royapettah</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Teynampet</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Nungambakkam</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Chetpet</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Egmore</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Alwarpet</li>
        </ul>
      </motion.section>

      <ProcessSection />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Contact Us for Pest Control in Gopalapuram, Chennai:
        </h3>
        <div className="bg-gray-100 p-6 rounded-lg mb-8">
          <p className="mb-2">
            <strong>📱 Call:</strong> +91 7558108600
          </p>
          <p className="mb-2">
            <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
          </p>
          <p>
            <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-xl font-semibold mb-4 text-primary">Request a Free Quote</h4>
          <ContactForm onSubmitSuccess={handleFormSubmit} location="Gopalapuram" />
          {isFormSubmitted && (
            <p className="mt-4 text-green-600 font-medium">
              Thank you for your inquiry! Our team will contact you shortly with a free quote for pest control services
              in Gopalapuram.
            </p>
          )}
        </div>
      </motion.section>
    </div>
  )
}
