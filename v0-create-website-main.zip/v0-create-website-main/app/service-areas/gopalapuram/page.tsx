import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import GopalapuramPestControlClient from "./GopalapuramPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Gopalapuram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Gopalapuram, Chennai. Our expert pest management ensures your home or office is pest-free, safe, and secure. Contact us today!",
  keywords:
    "pest control Gopalapuram, Gopalapuram pest services, cockroach control Gopalapuram, termite treatment Gopalapuram, rodent control Gopalapuram, mosquito control Gopalapuram, bed bug treatment Gopalapuram, commercial pest control Gopalapuram, Chennai pest control",
}

export default function GopalapuramPage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Best Pest Control in Gopalapuram, Chennai"
        description="Expert Pest Management Services for homes and businesses in Gopalapuram"
      />
      <GopalapuramPestControlClient />
    </main>
  )
}
