import type { Metadata } from "next"
import { ThiruvallurPestControlClient } from "./ThiruvallurPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Thiruvallur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thiruvallur, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Thiruvallur, Thiruvallur pest services, pest management Thiruvallur, pest control near me, No.1 Quality Pest Control Thiruvallur, mosquito control Thiruvallur, termite treatment Thiruvallur, residential pest control Thiruvallur",
}

export default function ThiruvallurPage() {
  return <ThiruvallurPestControlClient />
}
