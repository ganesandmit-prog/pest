"use client"
import Image from "next/image"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"

export function PattaravakkamPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Pattaravakkam, Chennai – Reliable Pest Control Services & Solutions</title>
        <meta
          name="description"
          content="Searching for trusted pest control services in Pattaravakkam, Chennai? Our expert team offers tailored solutions for urban pest control, termite treatment, and commercial pest management."
        />
        <meta
          name="keywords"
          content="pest control Pattaravakkam, urban pest control, termite treatment, cockroach control, rodent control, eco-friendly pest control, commercial pest management"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/pattaravakkam" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Pattaravakkam",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pattaravakkam",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Parrys",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.1148,
                "longitude": 80.1095
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹"
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Pattaravakkam"
        description="Professional & Affordable Pest Control Solutions"
      />

      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Best Pest Control in Pattaravakkam, Chennai – Reliable Pest Control Services & Solutions
            </h2>
            <p className="mb-4">
              Are you searching for trusted pest control services in Pattaravakkam, Chennai? Our expert control services
              offer tailored solutions to protect your home or business from invasive pests. Whether you need urban pest
              control, termite treatment, or effective commercial pest management, our experienced team ensures safe and
              thorough pest elimination.
            </p>
            <div className="bg-amber-100 p-4 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-2">🐜 Our Pest Control Services in Pattaravakkam:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>🐞 Termite Treatment & Prevention</li>
                <li>🦟 Urban Pest Control Solutions</li>
                <li>🐜 General Pest Control & Control Services</li>
                <li>🪳 Cockroach & Ant Control</li>
                <li>🐀 Rodent & Rat Control</li>
                <li>🧹 Professional Cleaning & Sanitization Services</li>
                <li>🌿 Eco-Friendly & Safe Pest Control Options</li>
              </ul>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Pest Control Service in Pattaravakkam"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Why Choose Our Pest Control Company in Pattaravakkam?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Professionals</h3>
              <p>Skilled technicians delivering effective control service with guaranteed results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Comprehensive Solutions</h3>
              <p>Specialized in urban pest control and commercial pest management.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Pricing</h3>
              <p>Transparent quotes with no hidden fees.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Eco-Friendly Treatment</h3>
              <p>Safe for your family, pets, and environment.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Trusted on Sulekha</h3>
              <p>Highly rated and recommended by local customers.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Commercial Pest Control Experts</h3>
              <p>Tailored services for shops, offices, and industrial spaces.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Pattaravakkam</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Chennai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Nearby Localities</h3>
          </div>
        </div>
      </section>

      <ProcessSection />
      <ServicesList />
      <BenefitsSection />
      <TestimonialsSection />

      <section className="container mx-auto px-4 py-12">
        <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold mb-4 text-center">Contact Us Today for Pest Control in Pattaravakkam</h2>
          <p className="text-center mb-6">
            Protect your property with the best pest control services in Pattaravakkam. Call now for a free quote and
            quick, reliable control services designed to keep pests away for good!
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📱</span>
              <span>Phone: +91 7558108600</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📧</span>
              <span>Email: no1qualitypestcontrol@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">🌐</span>
              <span>Website: www.no1qualitypestcontrol.com</span>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
