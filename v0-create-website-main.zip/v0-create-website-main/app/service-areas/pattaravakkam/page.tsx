import type { Metadata } from "next"
import { PattaravakkamPestControlClient } from "./PattaravakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pattaravakkam, Chennai – Reliable Pest Control Services & Solutions",
  description:
    "Searching for trusted pest control services in Pattaravakkam, Chennai? Our expert team offers tailored solutions for urban pest control, termite treatment, and commercial pest management.",
}

export default function PattaravakkamPage() {
  return <PattaravakkamPestControlClient />
}
