import type { Metadata } from "next"
import { ThirumangalamPestControlClient } from "./ThirumangalamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Thirumangalam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thirumangalam, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Thirumangalam, Thirumangalam pest services, pest management Thirumangalam, pest control near me, No.1 Quality Pest Control Thirumangalam, cockroach control Thirumangalam, termite treatment Thirumangalam",
}

export default function ThirumangalamPage() {
  return <ThirumangalamPestControlClient />
}
