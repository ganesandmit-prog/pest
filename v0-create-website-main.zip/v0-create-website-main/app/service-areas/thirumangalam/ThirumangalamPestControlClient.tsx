"use client"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function ThirumangalamPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Professional Pest Control Services in Thirumangalam, Chennai"
        description="No.1 Quality Pest Control provides expert pest management solutions in Thirumangalam. Our 45+ years of experience ensures your home and business remain pest-free."
        keywords="pest control Thirumangalam, Thirumangalam pest services, pest management Thirumangalam, pest control near me, No.1 Quality Pest Control Thirumangalam"
        location="Thirumangalam"
      />

      <main className="flex-grow">
        <section className="container mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">Pest Control Services in Thirumangalam, Chennai</h2>
              <p className="mb-4">
                Thirumangalam, a well-developed residential and commercial area in North Chennai, requires specialized
                pest control solutions to address its unique urban pest challenges. No.1 Quality Pest Control brings 45+
                years of expertise to Thirumangalam, offering comprehensive pest management services tailored to the
                specific needs of this vibrant locality.
              </p>
              <p className="mb-4">
                Our team of certified pest control specialists in Thirumangalam is equipped with advanced tools and
                environmentally friendly treatments to effectively eliminate pests while ensuring the safety of your
                family, employees, and customers. We understand the importance of maintaining a pest-free environment in
                both residential apartments and commercial establishments in Thirumangalam.
              </p>
              <p className="mb-4">
                Whether you're dealing with cockroaches in your kitchen, rodents in your storage areas, or termites
                threatening your property's structure, our Thirumangalam pest control team provides prompt, reliable,
                and effective solutions. We serve all areas of Thirumangalam including areas near the metro station, JJ
                Nagar, and surrounding neighborhoods.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">Common Pest Problems in Thirumangalam</h2>
              <p className="mb-4">
                Thirumangalam faces several pest challenges due to its urban development, proximity to water bodies, and
                the tropical climate of Chennai. Some common pest issues in Thirumangalam include:
              </p>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Cockroach Infestations:</strong> Particularly common in residential buildings and food
                  establishments in Thirumangalam.
                </li>
                <li>
                  <strong>Rodent Problems:</strong> Mice and rats are frequently reported in older buildings and areas
                  near commercial zones.
                </li>
                <li>
                  <strong>Termite Damage:</strong> A significant concern for property owners in Thirumangalam,
                  especially during monsoon seasons.
                </li>
                <li>
                  <strong>Mosquito Control:</strong> Essential for preventing dengue and malaria in residential areas of
                  Thirumangalam.
                </li>
                <li>
                  <strong>Bed Bug Treatments:</strong> Increasingly needed in residential apartments and PG
                  accommodations in the area.
                </li>
              </ul>

              <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Our Pest Control Service in Thirumangalam?</h2>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Local Expertise:</strong> Our technicians understand Thirumangalam's specific pest patterns
                  and challenges.
                </li>
                <li>
                  <strong>Customized Solutions:</strong> We develop tailored pest management plans for each property in
                  Thirumangalam.
                </li>
                <li>
                  <strong>Eco-Friendly Approaches:</strong> We prioritize green pest control methods that are safe for
                  families and pets.
                </li>
                <li>
                  <strong>Preventive Strategies:</strong> Beyond treatment, we help Thirumangalam residents prevent
                  future infestations.
                </li>
                <li>
                  <strong>Emergency Response:</strong> Quick service for urgent pest problems in Thirumangalam.
                </li>
                <li>
                  <strong>Comprehensive Coverage:</strong> We handle all types of pests common to the Thirumangalam
                  area.
                </li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <ContactForm location="Thirumangalam" />
              <div className="mt-8">
                <QuickLinks />
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection location="Thirumangalam" />
      </main>
    </div>
  )
}
