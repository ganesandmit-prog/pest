import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Aminjikarai | No.1 Quality Pest Control Chennai",
  description:
    "Looking for pest control services in Aminjikarai that actually work? We offer professional, affordable, and long-lasting pest control solutions for homes and businesses in Aminjikarai, Chennai.",
}

export default function AminjikaraiPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control in Aminjikarai, Chennai" subtitle="Safe & Effective Solutions" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              Looking for pest control services in Aminjikarai that actually work? You're at the right place. We offer
              professional, affordable, and long-lasting pest control solutions for homes and businesses in Aminjikarai,
              Chennai.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why Choose Our Pest Control Services in Aminjikarai?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Experienced Service Provider in Chennai Tamil Nadu</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Odorless, Child-Safe & Eco-Friendly Chemicals</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Specialized in Cockroach Control, Termite, Rats, and Mosquitoes</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Trusted by 500+ Happy Customers</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Same-Day Pest Control Service in Aminjikarai</span>
              </li>
            </ul>
            <p className="mt-4">
              Whether you need residential pest control or office-based solutions, we provide complete protection using
              proven methods.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Services Include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🪳 Cockroach Control Services in Aminjikarai</h3>
                <p>Effective elimination of cockroaches from your home or business premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐜 Termite Control (Pre and Post Construction)</h3>
                <p>Comprehensive termite protection for your property and wooden furniture.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐀 Rodent Control</h3>
                <p>Safe and effective solutions to eliminate rats and mice from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🦟 Mosquito & Bed Bug Treatment</h3>
                <p>Advanced treatments to keep your home free from mosquitoes and bed bugs.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🧼 Home & Office Deep Cleaning</h3>
                <p>Professional cleaning services to maintain a hygienic environment.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🏢 Corporate Pest Management Solutions</h3>
                <p>Specialized pest control solutions for commercial spaces and offices.</p>
              </div>
            </div>
            <p className="mt-4">
              All services are handled by trained technicians using safe, high-grade control chemicals.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Pest Control Areas Covered Near Aminjikarai</h2>
            <p>We proudly serve Aminjikarai and nearby areas in Chennai Tamil Nadu, including:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Shenoy Nagar</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Arumbakkam</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Anna Nagar</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Kilpauk</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Chetpet</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Purasaiwakkam</div>
            </div>
            <p className="mt-4">If you're in or around Aminjikarai, our team can be at your doorstep the same day.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 className="text-2xl font-bold mb-4">Top Pest Control Company in Aminjikarai</h2>
            <p className="mb-4">We're recognized as one of the best pest control companies in Chennai because of:</p>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>5-Star Google Ratings</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Verified on Sulekha & Justdial</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Guaranteed Pest Removal</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Affordable Pricing & Maintenance Plans</span>
              </li>
            </ul>
            <p className="mt-4">We deliver total pest protection with excellent customer care and timely support.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Book Your Service Now – Pest Control Experts at Your Doorstep!</h2>
            <p className="mb-4">Get in touch for an instant free quote and inspection.</p>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Call:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Visit:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Aminjikarai</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
