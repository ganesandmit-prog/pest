"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function IyyapanthangalPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Iyyapanthangal" subtitle="Reliable Pest Control Solutions" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Best Pest Control in Iyyapanthangal, Chennai</h2>
                  <div className="prose max-w-none">
                    <p>
                      Looking for pest control services in Iyyapanthangal, Chennai? We offer expert pest control
                      solutions, ensuring your home and office remain free from pests. Our services include general pest
                      control, cockroach control, eco-friendly pest management, and much more.
                    </p>
                    <h3>Our Pest Control Services in Iyyapanthangal, Chennai:</h3>
                    <ul>
                      <li>Cockroach Control</li>
                      <li>Termite Control</li>
                      <li>Rodent Control</li>
                      <li>Mosquito Control</li>
                      <li>Bed Bug Treatment</li>
                      <li>Eco-Friendly Pest Solutions</li>
                      <li>Commercial Pest Control</li>
                    </ul>
                    <h3>Why Choose Us for Pest Control in Iyyapanthangal, Chennai?</h3>
                    <ul>
                      <li>Experienced Technicians – Skilled experts with years of experience.</li>
                      <li>Eco-Friendly Methods – Non-toxic, safe solutions for you and your family.</li>
                      <li>Affordable Rates – Competitive pricing for all types of pest control services.</li>
                      <li>Prompt Service – Fast response to pest control needs.</li>
                      <li>Satisfaction Guarantee – We ensure effective results with every service.</li>
                    </ul>
                    <h3>Areas We Serve in Iyyapanthangal, Chennai:</h3>
                    <ul>
                      <li>Iyyapanthangal</li>
                      <li>Kundrathur</li>
                      <li>Mount Road</li>
                      <li>Porur</li>
                      <li>Chennai</li>
                      <li>Tamil Nadu</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Iyyapanthangal"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Iyyapanthangal"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Iyyapanthangal</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Iyyapanthangal home or business? Contact No.1 Quality Pest
                        Control today for a free inspection and quote. Our team of experienced professionals is ready to
                        help you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
