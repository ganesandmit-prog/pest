import type { Metadata } from "next"
import IyyapanthangalPestControlClient from "./IyyapanthangalPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Iyyapanthangal | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Iyyapanthangal, Chennai. Reliable pest control solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Iyyapanthangal, pest control services Iyyapanthangal, Iyyapanthangal pest control, cockroach control Iyyapanthangal, termite control Iyyapanthangal, bed bug control Iyyapanthangal, rodent control Iyyapanthangal",
}

export default function IyyapanthangalPestControl() {
  return <IyyapanthangalPestControlClient />
}
