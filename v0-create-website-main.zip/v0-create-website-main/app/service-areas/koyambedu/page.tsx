import KoyambeduPestControlClient from "./KoyambeduPestControlClient"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Pest Control Services in Koyambedu, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Koyambedu, Chennai. We offer effective solutions for cockroach, termite, mosquito, and rodent control. Contact us today!",
  keywords:
    "pest control Koyambedu, termite control Koyambedu, cockroach control Koyambedu, mosquito control Koyambedu, rodent control Koyambedu, bed bug treatment Koyambedu, pest control services Koyambedu Chennai, affordable pest control Koyambedu",
}

export default function KoyambeduPage() {
  return <KoyambeduPestControlClient />
}
