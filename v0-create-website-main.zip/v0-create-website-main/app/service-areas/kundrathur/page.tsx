import KundrathurPestControlClient from "./KundrathurPestControlClient"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Pest Control Services in Kundrathur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kundrathur, Chennai. We offer biological and eco-friendly solutions for cockroach, termite, mosquito, and rodent control. Contact us today!",
  keywords:
    "pest control Kundrathur, biological pest control Kundrathur, termite control Kundrathur, cockroach control Kundrathur, mosquito control Kundrathur, rodent control Kundrathur, bed bug treatment Kundrathur, pest control services Kundrathur Chennai, affordable pest control Kundrathur",
}

export default function KundrathurPage() {
  return <KundrathurPestControlClient />
}
