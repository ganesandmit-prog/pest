import type { Metadata } from "next"
import MaduravoayalPestControlClient from "./MaduravoayalPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Maduravoyal | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Maduravoyal, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Maduravoyal, pest control services Maduravoyal, cockroach control Maduravoyal, termite control Maduravoyal, rodent control Maduravoyal, bed bug treatment Maduravoyal, pest control Chennai, No.1 Quality Pest Control",
}

export default function MaduravoayalPage() {
  return <MaduravoayalPestControlClient />
}
