"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function MaduravoayalPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Maduravoyal" subtitle="Trusted Services for a Pest-Free Life" />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Looking for the best pest control in Maduravoyal? At No.1 Quality Pest Control, we offer professional,
                  affordable, and highly effective pest control services tailored for homes and businesses in
                  Maduravoyal Chennai.
                </p>
                <p className="text-lg">
                  Say goodbye to unwanted pests with our expert control services—be it cockroach removal, termite
                  treatment, or full residential pest control. We are your go-to pest control company in Chennai with
                  over a decade of experience.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🏡 Our Maduravoyal Services Include:</h2>
                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Pest Control</li>
                  <li>🐜 Termite Control & Treatment</li>
                  <li>🐀 Rodent and Rat Control</li>
                  <li>🦟 Mosquito and Fly Control</li>
                  <li>🛏️ Bed Bug Elimination</li>
                  <li>🧼 Cleaning Services for Pest-Prone Areas</li>
                  <li>🌿 Eco-Friendly Residential Pest Solutions</li>
                </ul>
                <p>
                  Our team uses safe, non-toxic chemicals approved by health authorities to protect your family, pets,
                  and property.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Serving Maduravoyal and Nearby Areas:</h2>
                <ul className="list-none space-y-2">
                  <li>Maduravoyal, Chennai</li>
                  <li>Porur</li>
                  <li>Mogappair</li>
                  <li>Koyambedu</li>
                  <li>Valasaravakkam</li>
                  <li>Nerkundram</li>
                  <li>Ambattur</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">⭐ Why Choose Us?</h2>
                <ul className="list-none space-y-2">
                  <li>✔️ 10+ years in the pest control industry</li>
                  <li>✔️ Professional technicians trained in cockroach and termite control</li>
                  <li>✔️ Fast and reliable control service</li>
                  <li>✔️ Affordable pricing with no hidden charges</li>
                  <li>✔️ Expert in residential pest solutions</li>
                  <li>✔️ Trusted pest control company listed in Chennai directories</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">💬 Customer Testimonials:</h2>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "Very satisfied with their cockroach treatment in Maduravoyal. Quick response and clean service."
                  <footer className="text-right">– Manoj, Chennai</footer>
                </blockquote>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "Excellent control service. Their termite solution worked wonders in my residential property."
                  <footer className="text-right">– Priya, Maduravoyal</footer>
                </blockquote>

                <h2 className="text-2xl font-bold mt-8 mb-4">📞 Contact Us Now for Instant Pest Relief!</h2>
                <ul className="list-none space-y-2">
                  <li>📍 Location: Maduravoyal, Chennai</li>
                  <li>
                    📞 Phone:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="https://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      https://www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Maduravoyal</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Maduravoyal" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Maduravoyal. Contact
                      us today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
