"use client"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { ContactForm } from "@/components/contact-form"
import { FadeIn } from "@/components/framer-animations"

export function MylaporeControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Mylapore, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Mylapore, Chennai. Trusted, affordable & effective solutions for cockroach, termite, rodent control & more. Book now!"
        />
        <meta
          name="keywords"
          content="pest control Mylapore, Mylapore pest services, cockroach control Mylapore, termite treatment Mylapore, rodent control Mylapore, bed bug treatment Mylapore, affordable pest control Mylapore, Chennai pest control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/mylapore" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Mylapore",
              "description": "Professional pest control services in Mylapore, Chennai. We offer trusted, affordable, and effective pest control solutions for homes and businesses.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/mylapore",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Mylapore",
                "addressRegion": "Chennai",
                "postalCode": "600004",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "13.0336",
                "longitude": "80.2680"
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "07:00",
                "closes": "22:00"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹",
              "servesCuisine": "Pest Control Services"
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "serviceType": "Pest Control Service",
              "provider": {
                "@type": "ProfessionalService",
                "name": "No.1 Quality Pest Control"
              },
              "areaServed": {
                "@type": "City",
                "name": "Mylapore, Chennai"
              },
              "description": "Professional pest control services in Mylapore, Chennai including cockroach control, termite treatment, rodent control, and more.",
              "offers": {
                "@type": "Offer",
                "price": "999.00",
                "priceCurrency": "INR"
              }
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Best Pest Control Services in Mylapore, Chennai"
        description="Trusted, Affordable & Effective Pest Solutions by No.1 Quality Pest Control"
      />

      <div className="container mx-auto px-4 py-12">
        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Professional Pest Control in Mylapore</h2>
            <p className="text-gray-700 mb-4">
              Are you searching for pest control in Mylapore? Look no further! At No.1 Quality Pest Control, we offer
              premium, reliable, and eco-friendly pest control services in Mylapore Chennai tailored to protect your
              home and business. Whether you're dealing with stubborn cockroach infestations, termite damage, or need a
              full-scale general pest control service, our experts have you covered with proven solutions.
            </p>
            <p className="text-gray-700 mb-4">
              Our team of experienced professionals understands the unique pest challenges faced in Mylapore's historic
              and residential areas. We pride ourselves on using safe chemicals that protect your family, pets, and the
              environment while effectively eliminating pest problems.
            </p>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Top Pest Control Services in Mylapore</h2>
            <ul className="list-disc pl-6 mb-4 space-y-2 text-gray-700">
              <li>
                <span className="font-semibold">Cockroach Control Services</span> - Eliminate cockroach infestations
                from your home or business
              </li>
              <li>
                <span className="font-semibold">Termite Control & Prevention</span> - Protect your property from
                destructive termites
              </li>
              <li>
                <span className="font-semibold">Mosquito & Insect Control</span> - Reduce disease-carrying insects
                around your property
              </li>
              <li>
                <span className="font-semibold">Rodent Removal Solutions</span> - Comprehensive rat and mice control
              </li>
              <li>
                <span className="font-semibold">Organic & Safe Pest Control</span> - Eco-friendly options for
                environmentally conscious customers
              </li>
              <li>
                <span className="font-semibold">Spider and Ant Control</span> - Eliminate crawling insects from your
                premises
              </li>
              <li>
                <span className="font-semibold">Home & Office Disinfection Services</span> - Keep your environment clean
                and hygienic
              </li>
            </ul>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Service Areas Around Mylapore</h2>
            <p className="text-gray-700 mb-4">We proudly serve Mylapore and the surrounding areas including:</p>
            <ul className="list-disc pl-6 mb-4 space-y-1 text-gray-700">
              <li>Mylapore Chennai</li>
              <li>Alwarpet</li>
              <li>Raja Annamalaipuram (R.A. Puram)</li>
              <li>Triplicane</li>
              <li>Santhome</li>
              <li>Mandaveli</li>
            </ul>
          </div>
        </FadeIn>

        <BenefitsSection
          title="Why Choose Us for Pest Control in Mylapore?"
          benefits={[
            {
              title: "10+ Years of Experience in Chennai & Tamil Nadu",
              description: "Benefit from our decade of pest control expertise",
            },
            {
              title: "Certified Technicians & Advanced Methods",
              description: "Our team is fully trained in the latest pest control techniques",
            },
            {
              title: "Affordable Prices with Transparent Quotes",
              description: "Competitive rates with no hidden fees",
            },
            {
              title: "Highly Rated on Sulekha & Google Reviews",
              description: "Join our satisfied customers throughout Chennai",
            },
            {
              title: "Fast & Friendly Customer Service",
              description: "Quick response times and professional service",
            },
          ]}
        />

        <ProcessSection
          title="Our Pest Control Process in Mylapore"
          steps={[
            {
              title: "Inspection",
              description: "Thorough assessment of your property to identify pest issues",
            },
            {
              title: "Customized Treatment Plan",
              description: "Developing a targeted solution based on your specific pest problem",
            },
            {
              title: "Professional Application",
              description: "Using government-approved methods and products",
            },
            {
              title: "Preventive Measures",
              description: "Implementing strategies to prevent future infestations",
            },
            {
              title: "Follow-up Service",
              description: "Ensuring complete pest elimination with follow-up visits if needed",
            },
          ]}
        />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Customer Reviews from Mylapore</h2>
            <div className="space-y-4">
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Exceptional termite control service. No more damage, and very professional staff!"
                </p>
                <p className="text-gray-600 font-semibold">— Anitha R.</p>
              </div>
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Quick response and very affordable. Cockroach problem solved perfectly!"
                </p>
                <p className="text-gray-600 font-semibold">— Suresh M.</p>
              </div>
            </div>
          </div>
        </FadeIn>

        <TestimonialsSection />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-800">
                  How often should I schedule pest control service in Mylapore?
                </h3>
                <p className="text-gray-700">
                  For most homes in Mylapore, we recommend quarterly pest control treatments to maintain a pest-free
                  environment. However, this can vary based on your specific situation and the types of pests in your
                  area.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Do you offer emergency pest control services in Mylapore?
                </h3>
                <p className="text-gray-700">
                  Yes, we offer same-day emergency pest control services throughout Mylapore and surrounding areas.
                  Contact us immediately for urgent pest issues.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Are your treatments safe for the historic buildings in Mylapore?
                </h3>
                <p className="text-gray-700">
                  Yes, we use specialized treatments that are effective against pests while being gentle on historic
                  structures and materials. Our technicians are trained to work in heritage buildings.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  What makes No.1 Quality Pest Control different from other services in Mylapore?
                </h3>
                <p className="text-gray-700">
                  We combine 10+ years of local experience with certified technicians, eco-friendly options, and
                  affordable pricing. Our high customer satisfaction rate and excellent reviews set us apart in the
                  Mylapore area.
                </p>
              </div>
            </div>
          </div>
        </FadeIn>

        <ContactForm />
      </div>
    </>
  )
}
