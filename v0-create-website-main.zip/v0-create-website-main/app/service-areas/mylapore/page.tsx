import { MylaporeControlClient } from "./MylaporeControlClient"

export const metadata = {
  title: "Best Pest Control in Mylapore, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mylapore, Chennai. Trusted, affordable & effective solutions for cockroach, termite, rodent control & more. Book now!",
}

export default function MylaporePage() {
  return <MylaporeControlClient />
}
