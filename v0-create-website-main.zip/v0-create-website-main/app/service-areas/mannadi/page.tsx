import type { Metadata } from "next"
import MannadiPestControlClient from "./MannadiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Mannadi | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mannadi, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Mannadi, pest control services Mannadi, cockroach control Mannadi, termite control Mannadi, rodent control Mannadi, bed bug treatment Mannadi, pest control Chennai, No.1 Quality Pest Control",
}

export default function MannadiPage() {
  return <MannadiPestControlClient />
}
