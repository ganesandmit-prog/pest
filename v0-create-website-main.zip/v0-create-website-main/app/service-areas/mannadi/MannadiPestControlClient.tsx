"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function MannadiPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Mannadi" subtitle="Reliable Pest Control Services in Chennai, Tamil Nadu" />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Welcome to No.1 Quality Pest Control, your trusted partner for effective pest control services in
                  Mannadi, Chennai Tamil Nadu. Whether you need professional residential pest control or commercial
                  control services, we provide comprehensive and safe solutions to keep your home and office pest-free.
                </p>
                <p className="text-lg">
                  Our expert team uses advanced techniques and eco-friendly products that comply with industry
                  standards, making us the top choice for pest control Chennai and beyond.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Our Pest Control Services in Mannadi?</h2>
                <ul className="list-none space-y-2">
                  <li>✔️ Professional control services tailored for both residential and commercial properties</li>
                  <li>✔️ Certified technicians with years of experience in pest control India</li>
                  <li>✔️ Use of safe, eco-friendly products for residential pest treatment</li>
                  <li>
                    ✔️ Trusted by customers across Chennai Tamil Nadu and recognized as a reputed India Private Limited
                    pest control company
                  </li>
                  <li>✔️ Transparent pricing and guaranteed results</li>
                  <li>✔️ Fast response and reliable services Chennai</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">Our Pest Control Services Include:</h2>
                <ul className="list-none space-y-2">
                  <li>🪵 Termite Control & Treatment</li>
                  <li>🪳 Cockroach & Ant Control</li>
                  <li>🐀 Rodent & Rat Management</li>
                  <li>🛏️ Bed Bug Removal</li>
                  <li>🦟 Mosquito & Fly Control</li>
                  <li>🌿 Organic and Chemical Pest Control Solutions</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">
                  About No.1 Quality Pest Control – Your Mannadi Pest Control Experts
                </h2>
                <p>
                  As a leading private limited company in India, No.1 Quality Pest Control is committed to delivering
                  effective pest management solutions. Our service team is known for professionalism, punctuality, and
                  excellent customer care.
                </p>
                <p>
                  We proudly serve Mannadi and nearby locations with a promise to provide hassle-free and reliable pest
                  control services.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">Contact Us Today!</h2>
                <ul className="list-none space-y-2">
                  <li>
                    📞 Call us now for a free consultation and quick pest control service in Mannadi and Chennai Tamil
                    Nadu!
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Visit:{" "}
                    <a href="http://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Mannadi</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Mannadi" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Mannadi. Contact us
                      today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
