"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KeelkattalaiPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader
        title="Top Pest Control in Keelkattalai, Chennai"
        subtitle="Effective & Affordable Pest Control Services"
      />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are you tired of pests invading your home or office in Keelkattalai? We provide professional pest
                control services in Keelkattalai with advanced techniques and expert care. Our trained technicians offer
                customized control solutions to keep your space pest-free.
              </p>
              <p className="text-lg mb-6">
                We specialize in rodent control services, cockroach treatment, and full-range pest control solutions
                using safe, eco-friendly methods. Trusted by families and businesses across Chennai, we are rated among
                the best on Sulekha for reliable service.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">🛠️ Our Pest Control Services in Keelkattalai</h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐭</span>
                    <span>
                      <strong>Rodent Control</strong> – Expert rodent control services to eliminate rats and mice
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Say goodbye to cockroaches with targeted treatments
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Control</strong> – Long-lasting pest control solutions for wood protection
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Control</strong> – Quick and discreet bed bug removal
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Prevent mosquito-borne diseases
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest & Cleaning Services</strong> – Maintain a healthy and hygienic environment
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Us for Pest Control in Keelkattalai?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Customized control solutions for your specific needs</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Certified professionals offering 100% satisfaction</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Affordable pricing & prompt service</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Available on Sulekha with top-rated reviews</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Eco-friendly methods safe for kids and pets</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Serving homes, apartments, offices & industries</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Fast, reliable services in Chennai</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 We Serve Keelkattalai & Nearby Areas:</h2>
                <p className="mb-4">
                  Pallavaram | Madipakkam | Puzhuthivakkam | Velachery | Nanganallur | Medavakkam | All across Chennai
                </p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">
                  📞 Contact the Best Pest Control Experts in Keelkattalai Today!
                </h2>
                <p className="mb-2">
                  📱 Call:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Website: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
                <p>🔍 Find us on Sulekha under "Best Pest Control in Keelkattalai"</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🛡️ We understand how important a clean, pest-free environment is. That's why our pest control services
                  in Keelkattalai focus on long-term results with safe, effective control solutions. From cockroach
                  control to rodent control services, we've got your back. Choose the experts in services Chennai who
                  prioritize your peace of mind.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Keelkattalai</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
