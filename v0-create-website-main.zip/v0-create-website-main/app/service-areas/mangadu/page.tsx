import type { Metadata } from "next"
import MangaduPestControlClient from "./MangaduPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Mangadu | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mangadu, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Mangadu, pest control services Mangadu, cockroach control Mangadu, termite control Mangadu, rodent control Mangadu, bed bug treatment Mangadu, pest control Chennai, No.1 Quality Pest Control",
}

export default function MangaduPage() {
  return <MangaduPestControlClient />
}
