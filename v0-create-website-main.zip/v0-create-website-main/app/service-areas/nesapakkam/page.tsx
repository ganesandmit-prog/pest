import type { Metadata } from "next"
import NesapakkamPestControlClient from "./NesapakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nesapakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nesapakkam, Chennai. We offer termite treatment, cockroach control, and safe pest solutions for homes and businesses.",
  keywords:
    "pest control Nesapakkam, termite treatment Nesapakkam, cockroach control Chennai, pest management Nesapakkam, No.1 Quality Pest Control",
}

export default function NesapakkamPestControlPage() {
  return <NesapakkamPestControlClient />
}
