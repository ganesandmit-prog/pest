"use client"
import { Helmet } from "react-helmet"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export default function NesapakkamPestControlClient() {
  return (
    <div className="flex min-h-screen flex-col">
      <Helmet>
        <title>Pest Control Services in Nesapakkam, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Nesapakkam, Chennai. We offer termite treatment, cockroach control, and safe pest solutions for homes and businesses."
        />
        <meta
          name="keywords"
          content="pest control Nesapakkam, termite treatment Nesapakkam, cockroach control Chennai, pest management Nesapakkam, No.1 Quality Pest Control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/nesapakkam" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Nesapakkam",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/nesapakkam",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Nesapakkam",
                "addressRegion": "Chennai",
                "postalCode": "600078",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0382,
                "longitude": 80.1929
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <PageHeader
          title="Pest Control Services in Nesapakkam, Chennai"
          subtitle="Safe, Reliable & Professional Pest Management"
        />

        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Trusted Pest Control Services in Nesapakkam, Chennai</h2>
            <p className="mt-4 text-gray-600">
              Are pesky pests troubling your home or office in Nesapakkam, Chennai? At No.1 Quality Pest Control, we
              offer professional, affordable, and effective pest control services tailored for Nesapakkam residents and
              businesses.
            </p>
            <p className="mt-4 text-gray-600">
              Whether you need cockroach control, termite treatment, or full-scale pest management, our expert
              technicians provide safe, reliable solutions that guarantee long-lasting protection.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">
              Our Pest Control Services in Nesapakkam Include:
            </h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Termite Control & Treatment</li>
              <li>Rodent Control Solutions</li>
              <li>Cockroach Control Services</li>
              <li>Mosquito & Insect Control</li>
              <li>Eco-Friendly Organic Pest Control</li>
              <li>Commercial & Residential Pest Services</li>
            </ul>

            <p className="mt-4 text-gray-600">
              We use safe, government-approved chemicals to keep your family and pets protected.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">Serving Nesapakkam & Surrounding Areas:</h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Nesapakkam, Chennai 600078</li>
              <li>Alwarpet</li>
              <li>Teynampet</li>
              <li>Adyar</li>
              <li>Velachery</li>
              <li>Saidapet</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-800">Why Choose No.1 Quality Pest Control in Nesapakkam?</h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Over 10+ Years of Experience</li>
              <li>Certified Pest Control Technicians</li>
              <li>Transparent Pricing & No Hidden Charges</li>
              <li>Quick & Hassle-Free Service</li>
              <li>Customized Pest Solutions for Every Need</li>
            </ul>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">What Clients Say:</h3>
            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "Excellent pest control service in Nesapakkam! Their termite treatment was effective and safe. Highly
                recommended."
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Anita R., Nesapakkam Resident</p>
            </div>

            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "Reliable, affordable, and professional pest control team. Fixed my cockroach problem fast!"
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Suresh M., Chennai</p>
            </div>

            <div className="mt-6 rounded-lg bg-blue-50 p-4">
              <h4 className="font-semibold text-blue-800">Contact No.1 Quality Pest Control Today!</h4>
              <p className="mt-2 text-blue-700">
                📍 Location: Nesapakkam, Chennai 600078
                <br />📞 Call: +91 75581 08600
                <br />📧 Email: no1qualitypestcontrol@gmail.com
                <br />🌐 Website: www.no1qualitypestcontrol.com
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Our Pest Control Process in Nesapakkam</h2>
          <ProcessSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Why Nesapakkam Residents Choose Us</h2>
          <BenefitsSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Pest Control Services We Offer in Nesapakkam</h2>
          <ServicesList />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Testimonials from Nesapakkam Customers</h2>
          <TestimonialsSection location="Nesapakkam" />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Contact Us for Pest Control in Nesapakkam</h2>
          <div className="mt-6">
            <ContactForm location="Nesapakkam" />
          </div>
        </div>
      </div>
    </div>
  )
}
