import type { Metadata } from "next"
import VelacheryPestControlClient from "./VelacheryPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Velachery, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Velachery, Chennai. Effective solutions for mosquitoes, cockroaches, termites, bed bugs & rodents. Call +91 7558108600 for free inspection!",
  keywords:
    "pest control Velachery, mosquito control Velachery, termite control Velachery, cockroach control Velachery, bed bug treatment Velachery, rodent control Velachery, pest services Velachery Chennai, best pest control Velachery",
}

export default function VelacheryPestControlPage() {
  return <VelacheryPestControlClient />
}
