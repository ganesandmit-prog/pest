"use client"

import { useState } from "react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"
import ContactForm from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"
import Image from "next/image"
import Link from "next/link"
import { Check, MapPin, Phone, Star } from "lucide-react"

export function VelacheryPestControlClient() {
  const [location] = useState("Velachery")

  return (
    <>
      <PageHeader
        title="No.1 Quality Pest Control Services in Velachery, Chennai"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Professional & Affordable Pest Control in Velachery"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold mb-4">Expert Pest Control Services in Velachery, Chennai</h2>
              <p className="text-gray-600 mb-6">
                Velachery, a prominent residential and commercial hub in South Chennai, faces unique pest challenges due
                to its proximity to the Velachery Lake and marshy areas. No.1 Quality Pest Control offers specialized
                pest management solutions tailored to Velachery's specific environmental conditions.
              </p>
              <p className="text-gray-600 mb-6">
                With 45+ years of experience in pest control services, we've become the most trusted choice for
                residents and businesses in Velachery. Our comprehensive pest management solutions effectively eliminate
                mosquitoes, cockroaches, termites, rodents, bed bugs, and other pests common in this area.
              </p>
              <div className="bg-light-green/10 p-4 rounded-lg border border-light-green mb-6">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-light-green" />
                  Common Pest Issues in Velachery:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Severe mosquito problems due to proximity to Velachery Lake</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Termite infestations in older buildings and apartments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroach issues in residential complexes and food establishments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Rodent problems in commercial areas and near drainage systems</span>
                  </li>
                </ul>
              </div>
              <div className="flex items-center justify-start mb-6">
                <Phone className="h-5 w-5 text-light-green mr-2" />
                <span className="font-semibold">Call us at: </span>
                <a href="tel:+917558108600" className="text-light-green font-bold ml-2 hover:underline">
                  +91 7558108600
                </a>
              </div>
              <Link href="/contact-us" className="btn-primary">
                Get Free Inspection in Velachery
              </Link>
            </AnimatedSection>

            <AnimatedSection animation="fadeIn" delay={0.2}>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Pest Control Services in Velachery"
                  width={800}
                  height={600}
                  className="w-full h-auto"
                />
              </div>
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <Star className="h-5 w-5 mr-2 text-yellow-500" />
                  Why Velachery Residents Choose Us:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>45+ years of pest control expertise in Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Specialized mosquito control solutions for Velachery's lake proximity</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Eco-friendly and child-safe pest control methods</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Affordable pricing with transparent billing</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Emergency pest control services available</span>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ServicesList
        title="Our Comprehensive Pest Control Services in Velachery"
        description="We offer a wide range of pest control services to keep your home and business in Velachery pest-free."
        location="Velachery"
      />

      <ProcessSection
        title="Our Pest Control Process in Velachery"
        description="Our systematic approach ensures effective and long-lasting pest control results for Velachery residents and businesses."
      />

      <BenefitsSection
        title="Benefits of Our Pest Control Services in Velachery"
        description="Experience the advantages of choosing No.1 Quality Pest Control for your pest management needs in Velachery."
      />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Pest Control FAQs for Velachery Residents</h2>
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">How do you handle mosquito control in Velachery?</h3>
                <p className="text-gray-600">
                  For Velachery's severe mosquito problems, we implement a comprehensive approach including larvicide
                  treatments for breeding sites (especially important near Velachery Lake), fogging for adult
                  mosquitoes, and residual spraying. We also provide guidance on preventing mosquito breeding around
                  your property.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  What termite control methods do you use for Velachery properties?
                </h3>
                <p className="text-gray-600">
                  For Velachery properties, we use a combination of soil treatment, wood treatment, and baiting systems
                  for termite control. Our methods are specifically adapted to handle the high moisture levels in
                  Velachery that contribute to termite problems. We offer both pre-construction and post-construction
                  termite treatments.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  How often should Velachery residents get pest control treatments?
                </h3>
                <p className="text-gray-600">
                  Due to Velachery's unique environmental conditions, we recommend quarterly general pest control
                  treatments. However, mosquito control may require monthly treatments during monsoon seasons, and
                  termite protection should be inspected annually. We create customized schedules based on your specific
                  situation.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Do you offer commercial pest control for Velachery businesses?
                </h3>
                <p className="text-gray-600">
                  Yes, we provide specialized commercial pest control services for all types of businesses in Velachery,
                  including restaurants, offices, retail stores, and warehouses. Our commercial pest management programs
                  comply with industry regulations and can be scheduled during non-business hours to minimize
                  disruption.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <TestimonialsSection
        title="What Our Velachery Customers Say"
        description="Read testimonials from satisfied customers in Velachery who have experienced our quality pest control services."
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Pest Control in Velachery</h2>
            <ContactForm defaultLocation={location} />
          </AnimatedSection>
        </div>
      </section>

      <QuickLinks />
    </>
  )
}

export default VelacheryPestControlClient
