"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SholinganallurPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Sholinganallur, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🐞 Pest Control in Sholinganallur – Residential & Organic Pest Experts
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for residential pest control in Sholinganallur? Our services in Sholinganallur, Chennai, cover
                  everything from gel-based cockroach removal to organic pest control and pest exterminator services. We
                  are Sulekha-listed, customer-approved, and budget-friendly.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🌿 Our Services in Sholinganallur:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Gel Pest Control – No smell, no mess!</li>
                  <li>🦟 Mosquito & Fly Control</li>
                  <li>🛏️ Bed Bugs & Lizard Treatment</li>
                  <li>🐜 Termite & Wood Borer Solutions</li>
                  <li>🌱 Organic Pest Management for chemical-free homes</li>
                  <li>🧹 Cleaning & Disinfection Services</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">💡 Why Sholinganallur Trusts Us:</h2>

                <ul className="list-none space-y-2">
                  <li>🏠 Specialized Residential Pest Control</li>
                  <li>📈 Proven Results with Long-Term Protection</li>
                  <li>🔬 Safe for Kids & Pets</li>
                  <li>📞 Free Inspection + Instant Quotes</li>
                  <li>🌐 Trusted in Chennai & IT Corridor Areas</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact:</h3>
                  <p className="mt-4">
                    📱 Phone: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
