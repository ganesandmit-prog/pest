import type { Metadata } from "next"
import { SholinganallurPestControlClient } from "./SholinganallurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Sholinganallur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Sholinganallur, Chennai. We offer cockroach, termite, bed bug, and mosquito control with eco-friendly solutions. Call now!",
  keywords:
    "pest control Sholinganallur, Sholinganallur pest control services, pest control company Chennai, eco-friendly pest control Sholinganallur, affordable pest control",
}

export default function SholinganallurPage() {
  return <SholinganallurPestControlClient />
}
