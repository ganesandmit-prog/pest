"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function PuzhuthivakkamUllagaramPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Puzhuthivakkam-Ullagaram, Chennai"
        description="Professional & affordable pest control services in Puzhuthivakkam-Ullagaram. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            Best Pest Control in Puzhuthivakkam, Chennai – Safe, Fast & Reliable
          </h2>

          <p>
            Are unwanted pests troubling your peace of mind? Our professional pest control services in Puzhuthivakkam
            offer fast, safe, and affordable solutions tailored for both homes and businesses. From termites to
            cockroaches, we provide effective treatments that last.
          </p>

          <h3 className="text-2xl font-bold text-primary">Our Pest Control Services in Puzhuthivakkam:</h3>

          <ul>
            <li>Termite Control – Safe & Odorless Treatments</li>
            <li>Cockroach & Ant Control</li>
            <li>Mosquito Fogging & Prevention</li>
            <li>Bed Bug Removal</li>
            <li>Deep Cleaning & Sanitization</li>
            <li>Biological & Eco-Friendly Pest Solutions</li>
            <li>Residential & Commercial Pest Management</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">Why Choose Us in Puzhuthivakkam?</h3>

          <ul>
            <li>Experienced Technicians – Trained to handle any pest.</li>
            <li>Eco-Friendly Treatments – Safe for kids and pets.</li>
            <li>Sulekha Verified Services – Trusted by thousands across Chennai.</li>
            <li>Guaranteed Results – With long-term pest prevention plans.</li>
            <li>Free Quotes – No hidden charges. Transparent pricing.</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">
            Now Serving: Puzhuthivakkam, Velachery, Pallikaranai, and nearby localities.
          </h3>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">Call Now: +91 7558108600</h3>
            <p>Email: no1qualitypestcontrol@gmail.com</p>
            <p>Visit: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm location="Puzhuthivakkam-Ullagaram" />
      <QuickLinks />
    </div>
  )
}

export default PuzhuthivakkamUllagaramPestControlClient
