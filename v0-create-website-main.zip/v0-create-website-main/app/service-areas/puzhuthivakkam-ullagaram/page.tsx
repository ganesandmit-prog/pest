import type { Metadata } from "next"
import { PuzhuthivakkamUllagaramPestControlClient } from "./PuzhuthivakkamUllagaramPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Puzhuthivakkam-Ullagaram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Puzhuthivakkam-Ullagaram, Chennai. We offer effective solutions for cockroaches, termites, bed bugs, and more. Contact us for a free quote!",
}

export default function PuzhuthivakkamUllagaramPage() {
  return <PuzhuthivakkamUllagaramPestControlClient />
}
