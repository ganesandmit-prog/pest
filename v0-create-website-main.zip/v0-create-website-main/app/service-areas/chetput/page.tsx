import type { Metadata } from "next"
import ChetputPestControlClient from "./ChetputPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Chetput | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Chetput, Chennai. Guaranteed & eco-safe solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Chetput, pest control services Chetput, Chetput pest control, cockroach control Chetput, termite control Chetput, bed bug control Chetput, rodent control Chetput",
}

export default function ChetputPestControl() {
  return <ChetputPestControlClient />
}
