"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function ChetputPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Chetput" subtitle="Guaranteed & Eco-Safe Solutions" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Best Pest Control in Chetput</h2>
                  <div className="prose max-w-none">
                    <p>
                      Searching for pest control in Chetput that delivers fast and lasting results? Look no further! We
                      are the most trusted pest control service provider in Chetput, Chennai, offering premium pest
                      treatment for homes and businesses. Say goodbye to cockroaches, termites, and all general pests
                      with our proven, chemical-safe methods.
                    </p>
                    <h3>Our Expert Pest Control Services in Chetput:</h3>
                    <ul>
                      <li>General Pest Control</li>
                      <li>Termite Control (Pre/Post Construction)</li>
                      <li>Cockroach Control</li>
                      <li>Rodent & Bed Bug Treatment</li>
                      <li>Deep Cleaning & Sanitization</li>
                      <li>Residential & Commercial Solutions</li>
                    </ul>
                    <h3>Why Clients in Chetput Trust Us:</h3>
                    <ul>
                      <li>Same-Day Service</li>
                      <li>Certified Pest Experts</li>
                      <li>100% Safe for Kids & Pets</li>
                      <li>Free Site Inspection & Quote</li>
                      <li>Affordable Plans with Assured Results</li>
                      <li>Highly Rated on Google & Justdial</li>
                    </ul>
                    <h3>Serving Chetput & Nearby Areas:</h3>
                    <ul>
                      <li>Chetput</li>
                      <li>Nungambakkam</li>
                      <li>Egmore</li>
                      <li>Kilpauk</li>
                      <li>Aminjikarai</li>
                      <li>Shenoy Nagar</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Chetput"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Chetput"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Chetput</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Chetput home or business? Contact No.1 Quality Pest Control
                        today for a free inspection and quote. Our team of experienced professionals is ready to help
                        you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
