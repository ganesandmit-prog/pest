"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function RoyapuramPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Royapuram, Chennai"
        description="Professional & affordable pest control services in Royapuram. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            ✅ Pest Control in Royapuram, Chennai – Certified Pest Control Services Near Railway Station
          </h2>

          <p>
            Searching for trusted pest control in Royapuram, Chennai? We provide safe, affordable, and effective pest
            control services in Royapuram – near Royapuram Railway Station and across surrounding residential and
            commercial areas. Whether you're dealing with cockroaches, rodents, bed bugs, termites, or mosquitoes, our
            expert team uses eco-friendly and organic pest control solutions to protect your property.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pest Control Services in Royapuram Include:</h3>

          <ul>
            <li>🪳 Cockroach Control (Gel + Spray)</li>
            <li>🐀 Rodent Control – Traps & sealing entry points</li>
            <li>🛏️ Bed Bug Removal – Heat and herbal treatments</li>
            <li>🦟 Mosquito Fogging Services – Indoor & outdoor</li>
            <li>🌿 Organic Pest Control – Herbal, chemical-free methods</li>
            <li>🧱 Termite Control – Foundation and wood treatment</li>
            <li>🧹 Post-Pest Cleaning Services – Complete hygiene restoration</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Our Pest Control Company in Royapuram?</h3>

          <ul>
            <li>✔️ Experienced & Licensed Professionals</li>
            <li>✔️ Affordable Pest Control Packages</li>
            <li>✔️ Eco-Friendly & Safe for Children</li>
            <li>✔️ Quick Service Near Royapuram Railway Station</li>
            <li>✔️ Positive Customer Reviews & High Google Ratings</li>
            <li>✔️ Free Site Inspection & Transparent Pricing</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 We Cover the Entire Royapuram Area:</h3>

          <ul>
            <li>Royapuram, Chennai</li>
            <li>Royapuram Railway Station Vicinity</li>
            <li>Washermanpet</li>
            <li>Tondiarpet</li>
            <li>Kasimedu</li>
            <li>Mint Street</li>
            <li>Old Washermanpet</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">🔍 Keywords Targeted for SEO Domination:</h3>

          <ul>
            <li>Pest Control in Royapuram</li>
            <li>Royapuram Pest Control Services</li>
            <li>Pest Control Near Royapuram Railway Station</li>
            <li>Organic Pest Control in Chennai</li>
            <li>Cleaning and Pest Service Royapuram</li>
            <li>Top Pest Control Company Royapuram</li>
            <li>Affordable Pest Service with Reviews and Address</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">
              📞 Contact the Best Pest Control Service in Royapuram, Chennai!
            </h3>
            <p>
              Take control of your space today. Get the most reliable, eco-conscious pest solutions in Royapuram.
              Trusted by hundreds of homes and businesses!
            </p>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm location="Royapuram" />
      <QuickLinks />
    </div>
  )
}

export default RoyapuramPestControlClient
