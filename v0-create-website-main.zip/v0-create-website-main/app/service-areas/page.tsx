"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { MapPin, Check } from "lucide-react"
import ContactForm from "@/components/contact-form"
import Link from "next/link"

export default function ServiceAreasPage() {
  return (
    <>
      <PageHeader
        title="No.1 Quality Pest Control Chennai – Service Areas"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Providing Pest Control Services Chennai Across All Areas"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              At No.1 Quality Pest Control Chennai, we proudly offer professional, affordable, and eco-friendly pest
              control services across North, South, East, and West Chennai, ensuring homes and businesses remain 100%
              pest-free.
            </p>
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              Whether you need cockroaches control in Anna Nagar, termite control in T. Nagar, or commercial pest
              control in OMR, our control service Chennai has you covered!
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <h2 className="text-2xl font-bold mb-8 flex items-center justify-center">
              <MapPin className="h-6 w-6 mr-2" />
              <span>Our Extensive Chennai Pest Control Service Areas Include:</span>
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <AnimatedSection animation="slideLeft">
              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-dark-green">North Chennai Pest Control Services</h3>
                <p className="mb-4">
                  North Chennai has a mix of industrial, commercial, and residential areas, often prone to rodents,
                  cockroaches, and termites. Our pest control service Chennai offers:
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Termite Control in Anna Nagar & Perambur at affordable price</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroaches Control in Royapuram & George Town</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Commercial Pest Control in Tiruvottiyur & Red Hills</span>
                  </li>
                </ul>
                <div>
                  <h4 className="font-bold mb-2">Areas Covered by Our Pest Control Services Chennai:</h4>
                  <div className="text-sm grid grid-cols-2 gap-2">
                    <Link href="/service-areas/anna-nagar" className="text-light-green hover:underline">
                      Anna Nagar
                    </Link>
                    <Link href="/service-areas/perambur" className="text-light-green hover:underline">
                      Perambur
                    </Link>
                    <Link href="/service-areas/royapuram" className="text-light-green hover:underline">
                      Royapuram
                    </Link>
                    <Link href="/service-areas/vyasarpadi" className="text-light-green hover:underline">
                      Vyasarpadi
                    </Link>
                    <Link href="/service-areas/madhavaram" className="text-light-green hover:underline">
                      Madhavaram
                    </Link>
                    <Link href="/service-areas/kodungaiyur" className="text-light-green hover:underline">
                      Kodungaiyur
                    </Link>
                    <Link href="/service-areas/tondiarpet" className="text-light-green hover:underline">
                      Tondiarpet
                    </Link>
                    <Link href="/service-areas/washermanpet" className="text-light-green hover:underline">
                      Washermanpet
                    </Link>
                    <Link href="/service-areas/manali" className="text-light-green hover:underline">
                      Manali
                    </Link>
                    <Link href="/service-areas/puzhal" className="text-light-green hover:underline">
                      Puzhal
                    </Link>
                    <Link href="/service-areas/red-hills" className="text-light-green hover:underline">
                      Red Hills
                    </Link>
                    <Link href="/service-areas/minjur" className="text-light-green hover:underline">
                      Minjur
                    </Link>
                    <Link href="/service-areas/parrys-corner" className="text-light-green hover:underline">
                      Parry's Corner
                    </Link>
                    <Link href="/service-areas/park-town" className="text-light-green hover:underline">
                      Park Town
                    </Link>
                    <Link href="/service-areas/vyasarpadi" className="text-light-green hover:underline">
                      Vyasarpadi
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideRight">
              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-dark-green">South Chennai Pest Control Services</h3>
                <p className="mb-4">
                  South Chennai is a fast-developing commercial and IT hub with apartments, villas, and corporate
                  offices that require regular pest control. Our control services Chennai include:
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Mosquito Control in Adyar & Velachery at competitive price</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Bed Bug Treatment in T. Nagar & Thiruvanmiyur</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroaches & Ant Control in Medavakkam & Sholinganallur</span>
                  </li>
                </ul>
                <div>
                  <h4 className="font-bold mb-2">Areas Covered by Our Chennai Pest Control:</h4>
                  <div className="text-sm grid grid-cols-2 gap-2">
                    <Link href="/service-areas/adyar" className="text-light-green hover:underline">
                      Adyar
                    </Link>
                    <Link href="/service-areas/t-nagar" className="text-light-green hover:underline">
                      T. Nagar
                    </Link>
                    <Link href="/service-areas/velachery" className="text-light-green hover:underline">
                      Velachery
                    </Link>
                    <Link href="/service-areas/mylapore" className="text-light-green hover:underline">
                      Mylapore
                    </Link>
                    <Link href="/service-areas/tambaram" className="text-light-green hover:underline">
                      Tambaram
                    </Link>
                    <Link href="/service-areas/medavakkam" className="text-light-green hover:underline">
                      Medavakkam
                    </Link>
                    <Link href="/service-areas/pallavaram" className="text-light-green hover:underline">
                      Pallavaram
                    </Link>
                    <Link href="/service-areas/sholinganallur" className="text-light-green hover:underline">
                      Sholinganallur
                    </Link>
                    <Link href="/service-areas/saidapet" className="text-light-green hover:underline">
                      Saidapet
                    </Link>
                    <Link href="/service-areas/alandur" className="text-light-green hover:underline">
                      Alandur
                    </Link>
                    <Link href="/service-areas/neelankarai" className="text-light-green hover:underline">
                      Neelankarai
                    </Link>
                    <Link href="/service-areas/thiruvanmiyur" className="text-light-green hover:underline">
                      Thiruvanmiyur
                    </Link>
                    <Link href="/service-areas/perungudi" className="text-light-green hover:underline">
                      Perungudi
                    </Link>
                    <Link href="/service-areas/tiruvallikeni" className="text-light-green hover:underline">
                      Tiruvallikeni
                    </Link>
                    <Link href="/service-areas/vandalur" className="text-light-green hover:underline">
                      Vandalur
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={0.2}>
              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-dark-green">West Chennai Pest Control Services</h3>
                <p className="mb-4">
                  West Chennai is rapidly growing with new residential complexes, IT parks, and commercial buildings.
                  Our pest control services Chennai provide:
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Termite Control in Porur & Mogappair</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Rat & Rodent Control in Avadi & Ambattur</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroaches & Mosquito Control in Maduravoyal & Poonamallee</span>
                  </li>
                </ul>
                <div>
                  <h4 className="font-bold mb-2">Areas Covered by Our Pest Control Service Chennai:</h4>
                  <div className="text-sm grid grid-cols-2 gap-2">
                    <Link href="/service-areas/avadi" className="text-light-green hover:underline">
                      Avadi
                    </Link>
                    <Link href="/service-areas/ambattur" className="text-light-green hover:underline">
                      Ambattur
                    </Link>
                    <Link href="/service-areas/mogappair" className="text-light-green hover:underline">
                      Mogappair
                    </Link>
                    <Link href="/service-areas/koyambedu" className="text-light-green hover:underline">
                      Koyambedu
                    </Link>
                    <Link href="/service-areas/poonamallee" className="text-light-green hover:underline">
                      Poonamallee
                    </Link>
                    <Link href="/service-areas/porur" className="text-light-green hover:underline">
                      Porur
                    </Link>
                    <Link href="/service-areas/maduravoyal" className="text-light-green hover:underline">
                      Maduravoyal
                    </Link>
                    <Link href="/service-areas/tiruverkadu" className="text-light-green hover:underline">
                      Tiruverkadu
                    </Link>
                    <Link href="/service-areas/vadapalani" className="text-light-green hover:underline">
                      Vadapalani
                    </Link>
                    <Link href="/service-areas/virugambakkam" className="text-light-green hover:underline">
                      Virugambakkam
                    </Link>
                    <Link href="/service-areas/saligramam" className="text-light-green hover:underline">
                      Saligramam
                    </Link>
                    <Link href="/service-areas/valasaravakkam" className="text-light-green hover:underline">
                      Valasaravakkam
                    </Link>
                    <Link href="/service-areas/vanagaram" className="text-light-green hover:underline">
                      Vanagaram
                    </Link>
                    <Link href="/service-areas/villivakkam" className="text-light-green hover:underline">
                      Villivakkam
                    </Link>
                    <Link href="/service-areas/velappanchavadi" className="text-light-green hover:underline">
                      Velappanchavadi
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideRight" delay={0.2}>
              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4 text-dark-green">
                  East Chennai & Coastal Areas Pest Control Services
                </h3>
                <p className="mb-4">
                  East Chennai, covering the OMR & ECR belt, is prone to mosquitoes, termites, and cockroaches due to
                  its coastal climate. Our Chennai pest control offers:
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Mosquito Control & Larvicide Treatment in OMR & ECR</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroaches & Bed Bug Control in Kelambakkam & Siruseri</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Eco-Friendly Commercial Pest Control for Beach Villas in Neelankarai & Uthandi</span>
                  </li>
                </ul>
                <div>
                  <h4 className="font-bold mb-2">Areas Covered by Our Control Services Chennai:</h4>
                  <div className="text-sm grid grid-cols-2 gap-2">
                    <Link href="/service-areas/united-india-colony" className="text-light-green hover:underline">
                      United India Colony
                    </Link>
                    <Link href="/service-areas/vallalar-nagar" className="text-light-green hover:underline">
                      Vallalar Nagar
                    </Link>
                    <Link href="/service-areas/west-mambalam" className="text-light-green hover:underline">
                      West Mambalam
                    </Link>
                    <Link href="/service-areas/thuraipakkam" className="text-light-green hover:underline">
                      Thuraipakkam
                    </Link>
                    <Link href="/service-areas/tirusulam" className="text-light-green hover:underline">
                      Tirusulam
                    </Link>
                    <Link href="/service-areas/thiruvotriyur" className="text-light-green hover:underline">
                      Thiruvotriyur
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                title: "45+ Years of Experience in Pest Control Services Chennai",
                description: "",
              },
              {
                title: "Certified Experts for Residential & Commercial Pest Control",
                description: "",
              },
              {
                title: "Child-Safe, Pet-Friendly Termite & Cockroaches Control",
                description: "",
              },
              {
                title: "Affordable Price & 100% Satisfaction for All Control Services",
                description: "",
              },
              {
                title: "Serving ALL Areas in Chennai – Call for Pest Control Service!",
                description: "",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold">{item.title}</h3>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">
              Protect Your Home & Business with Chennai Pest Control – Book Now!
            </h2>
            <p className="mb-6">
              If your area is not listed but falls within Chennai, contact us for a customized pest control plan. Our
              expert pest control solutions will keep your space safe, clean, and pest-free for the long term!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                📞 Call Now for Pest Control Services Chennai: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  📩 Get a Free Pest Control Service Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
