"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SowcarpetPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Sowcarpet, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🐜 Best Pest Control in Sowcarpet, Chennai – Safe, Fast & Reliable
              </h1>

              <div className="prose max-w-none">
                <p>
                  Are unwanted pests troubling your peace of mind? Our professional pest control services in Sowcarpet
                  offer fast, safe, and affordable solutions tailored for both homes and businesses. From termites to
                  cockroaches, we provide effective treatments that last.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">💼 Our Pest Control Services in Sowcarpet:</h2>

                <ul className="list-none space-y-2">
                  <li>🐜 Termite Control – Safe & Odorless Treatments</li>
                  <li>🪳 Cockroach & Ant Control</li>
                  <li>🦟 Mosquito Fogging & Prevention</li>
                  <li>🛏️ Bed Bug Removal</li>
                  <li>🧼 Deep Cleaning & Sanitization</li>
                  <li>🧪 Biological & Eco-Friendly Pest Solutions</li>
                  <li>🏠 Residential & Commercial Pest Management</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">✔️ Why Choose Us in Sowcarpet?</h2>

                <ul className="list-none space-y-2">
                  <li>🛠️ Experienced Technicians – Trained to handle any pest.</li>
                  <li>🌿 Eco-Friendly Treatments – Safe for kids and pets.</li>
                  <li>💡 Sulekha Verified Services – Trusted by thousands across Chennai.</li>
                  <li>📈 Guaranteed Results – With long-term pest prevention plans.</li>
                  <li>💰 Free Quotes – No hidden charges. Transparent pricing.</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Now Serving:</h2>
                <p>Sowcarpet, George Town, Parrys Corner, and nearby localities.</p>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Call Now:</h3>
                  <p className="mt-4">
                    📱 Phone: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
