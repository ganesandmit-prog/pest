"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function PuzhalPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Puzhal, Chennai"
        description="Professional & affordable pest control services in Puzhal. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            🐜 Pest Control in Puzhal – Trusted, Safe & Affordable
          </h2>

          <p>
            Tired of pests invading your space? We offer top-rated pest control services in Puzhal, Chennai, with safe,
            effective, and long-lasting solutions for residential and commercial spaces. Whether it's cockroaches,
            termites, or mosquitoes, we've got you covered.
          </p>

          <h3 className="text-2xl font-bold text-primary">🧼 Our Puzhal Pest Control Services:</h3>

          <ul>
            <li>🐜 Termite Control – Pre & Post Construction Treatment</li>
            <li>🪳 Cockroach Removal – Odorless Gel & Spray Treatments</li>
            <li>🦟 Mosquito Fogging</li>
            <li>🛏️ Bed Bug Extermination</li>
            <li>🧹 Home & Office Cleaning</li>
            <li>🧪 Organic Pest Solutions</li>
            <li>🏠 Residential & Commercial Packages</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">✔️ Why Choose Our Pest Control in Puzhal?</h3>

          <ul>
            <li>🏆 Sharp Pest Control Techniques</li>
            <li>✅ Sulekha Verified & Highly Reviewed</li>
            <li>👨‍🔬 Experienced & Certified Professionals</li>
            <li>💰 Affordable & Transparent Pricing</li>
            <li>🧒 Child & Pet-Friendly Chemicals</li>
            <li>🧭 Service Available in Chennai & Surrounding Areas</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Call Us Now: +91 7558108600</h3>
            <p>🌐 Visit: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
