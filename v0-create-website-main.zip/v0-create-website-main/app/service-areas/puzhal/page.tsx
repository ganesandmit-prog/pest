import type { Metadata } from "next"
import { PuzhalPestControlClient } from "./PuzhalPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Puzhal, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Puzhal, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Puzhal, pest services Puzhal, cockroach control Puzhal, termite treatment Puzhal, bed bug control Puzhal, mosquito control Puzhal, rodent control Puzhal, pest control services Puzhal Chennai",
}

export default function PuzhalPage() {
  return <PuzhalPestControlClient />
}
