"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Check } from "lucide-react"
import ContactForm from "@/components/contact-form"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"

export default function WestMambalamPestControlClient() {
  return (
    <>
      <PageHeader
        title="Pest Control Services in West Mambalam, Chennai"
        backgroundImage="https://images.unsplash.com/photo-1605146768851-eda79da39897"
        subtitle="Professional & Affordable Pest Control in West Mambalam"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <h2 className="text-3xl font-bold mb-4">Best Pest Control Services in West Mambalam, Chennai</h2>
                <p className="mb-6">
                  West Mambalam, a densely populated residential area in Chennai, faces unique pest challenges due to
                  its mix of old and new buildings, proximity to markets, and seasonal flooding issues. No.1 Quality
                  Pest Control offers specialized pest management solutions for West Mambalam residents, addressing
                  common problems like cockroach infestations in apartment complexes, mosquito breeding in water-prone
                  areas, and rodent issues near commercial establishments.
                </p>

                <p className="mb-6">
                  Our team of certified pest control experts in West Mambalam provides comprehensive services including
                  termite control, cockroach treatment, bed bug elimination, rodent management, and mosquito control. We
                  use eco-friendly, child-safe methods that effectively eliminate pests while ensuring the safety of
                  your family and pets.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Complete pest protection for homes and apartments in West Mambalam</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Safe, eco-friendly treatments suitable for family homes</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Specialized solutions for apartment complexes and independent houses</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>45+ years of experience in pest management across Chennai</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <p>Affordable pest control services with guaranteed results</p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-4 rounded-lg mb-6">
                  <p className="font-bold text-center">Trusted by 50,000+ Happy Customers in Chennai!</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <motion.a href="tel:+917558108600" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <button className="btn-dark">Call Now: +91 7558108600</button>
                  </motion.a>
                  <a href="https://wa.me/917558108600" target="_blank" rel="noopener noreferrer">
                    <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      WhatsApp Us
                    </motion.button>
                  </a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1605146768851-eda79da39897"
                  alt="Pest Control Services in West Mambalam"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ServicesList />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Our Pest Control Projects in West Mambalam</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1590496794008-383c8070b257"
                    alt="Apartment Pest Control in West Mambalam"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Apartment Complex Treatment</h3>
                  <p className="text-gray-600 mb-4">
                    Comprehensive pest management for apartment buildings in West Mambalam, focusing on common areas and
                    individual units.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1604754742629-3e0498a8211f"
                    alt="Mosquito Control in West Mambalam"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Mosquito Management</h3>
                  <p className="text-gray-600 mb-4">
                    Specialized mosquito control for West Mambalam's water-prone areas, preventing breeding and disease
                    spread.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white rounded-lg overflow-hidden shadow-md" whileHover={{ y: -10 }}>
                <div className="relative h-48">
                  <Image
                    src="https://images.unsplash.com/photo-1635340909894-1665936a1f11"
                    alt="Termite Control in West Mambalam"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Termite Protection</h3>
                  <p className="text-gray-600 mb-4">
                    Comprehensive termite treatment for independent houses and wooden structures in West Mambalam.
                  </p>
                </div>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ProcessSection />

      <BenefitsSection />

      <TestimonialsSection />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Areas We Serve in Chennai</h2>
            <p className="text-center text-gray-600 mb-8">
              We provide professional pest control services across Chennai, including:
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
            {[
              "Adyar",
              "Anna Nagar",
              "Ashok Nagar",
              "Besant Nagar",
              "Chromepet",
              "Egmore",
              "Guindy",
              "KK Nagar",
              "Kodambakkam",
              "Madipakkam",
              "Mylapore",
              "Nungambakkam",
              "OMR",
              "Porur",
              "Saidapet",
              "T. Nagar",
              "Tambaram",
              "Thiruvanmiyur",
              "Vadapalani",
              "Velachery",
              "Washermanpet",
              "West Mambalam",
            ].map((area, index) => (
              <AnimatedSection key={area} animation="fadeIn" delay={index * 0.05}>
                <Link href={`/service-areas/${area.toLowerCase().replace(/\s+/g, "-")}`}>
                  <motion.div
                    className="bg-white p-3 rounded-lg shadow-sm text-center hover:bg-light-green hover:text-white transition-colors"
                    whileHover={{ y: -5 }}
                  >
                    {area}
                  </motion.div>
                </Link>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">
              Frequently Asked Questions About Pest Control in West Mambalam
            </h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <AnimatedSection animation="slideUp" delay={0.1}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">What are the common pests found in West Mambalam, Chennai?</h3>
                <p className="text-gray-600">
                  West Mambalam commonly experiences issues with cockroaches, mosquitoes, rodents, termites, and bed
                  bugs. Due to its residential density and seasonal water logging, mosquito and cockroach infestations
                  are particularly prevalent in this area.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.2}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">How much does pest control cost in West Mambalam?</h3>
                <p className="text-gray-600">
                  Pest control services in West Mambalam typically range from ₹1,000 to ₹10,000 depending on the type of
                  pest, severity of infestation, and property size. We offer competitive rates with free inspection and
                  customized treatment plans for apartments and independent houses.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.3}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">
                  Do you offer annual pest control contracts for apartments in West Mambalam?
                </h3>
                <p className="text-gray-600">
                  Yes, we offer annual maintenance contracts (AMC) specifically designed for apartments and residential
                  complexes in West Mambalam. These contracts include regular inspections, preventive treatments, and
                  emergency services at discounted rates, providing year-round protection against pests.
                </p>
              </motion.div>
            </AnimatedSection>

            <AnimatedSection animation="slideUp" delay={0.4}>
              <motion.div className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                <h3 className="text-xl font-bold mb-2">
                  How do you handle mosquito problems in West Mambalam during rainy seasons?
                </h3>
                <p className="text-gray-600">
                  For West Mambalam's seasonal mosquito issues, we implement a comprehensive approach including
                  larvicide treatment in water-prone areas, fogging for adult mosquitoes, and residual spraying around
                  homes. We also provide guidance on eliminating breeding sources and installing preventive measures
                  like mosquito nets and screens.
                </p>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="py-12 bg-dark-green text-white text-center">
        <AnimatedSection animation="fadeIn">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Get Professional Pest Control in West Mambalam Today!</h2>
            <p className="mb-6">
              Contact No.1 Quality Pest Control for safe, effective, and affordable pest management solutions in West
              Mambalam, Chennai.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="tel:+917558108600"
                className="btn-white"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Call Now: +91 7558108600
              </motion.a>
              <Link href="/contact-us">
                <motion.button className="btn-white" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  Get a Free Quote
                </motion.button>
              </Link>
            </div>
          </div>
        </AnimatedSection>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Pest Control in West Mambalam</h2>
          <ContactForm location="West Mambalam" />
        </div>
      </section>
    </>
  )
}
