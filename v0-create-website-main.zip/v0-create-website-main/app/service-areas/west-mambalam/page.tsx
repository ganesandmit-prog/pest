import type { Metadata } from "next"
import WestMambalamPestControlClient from "./WestMambalamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in West Mambalam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in West Mambalam, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with safe, effective treatments. Call now!",
  keywords:
    "pest control West Mambalam, termite control West Mambalam, cockroach control West Mambalam, bed bug treatment West Mambalam, rodent control West Mambalam, mosquito control West Mambalam, pest control services West Mambalam Chennai, best pest control West Mambalam",
}

export default function WestMambalamPestControlPage() {
  return <WestMambalamPestControlClient />
}
