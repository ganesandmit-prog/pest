"use client"
import { motion } from "framer-motion"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { fadeIn } from "@/components/framer-animations"

export default function MoulivakkamPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Pest Control in Moulivakkam, Chennai - No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Moulivakkam, Chennai. Safe, reliable & affordable solutions for cockroach, termite, rodent & mosquito control. Call now!"
        />
        <meta
          name="keywords"
          content="pest control Moulivakkam, cockroach control Moulivakkam, termite treatment Moulivakkam, rodent control Chennai, mosquito control Moulivakkam, bed bug treatment Chennai, pest control services Moulivakkam"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/moulivakkam" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Moulivakkam",
              "description": "Professional pest control services in Moulivakkam, Chennai including cockroach, termite, rodent and mosquito control with eco-friendly solutions.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/moulivakkam",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Moulivakkam",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0213,
                "longitude": 80.1417
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "areaServed": ["Moulivakkam", "Chennai", "Tamil Nadu"]
            }
          `}
        </script>
      </Helmet>

      <PageHeader title="Pest Control Services in Moulivakkam" subtitle="Safe. Reliable. Professional." />

      <div className="container mx-auto px-4 py-12">
        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-6 text-center">Expert Pest Control Services in Moulivakkam, Chennai</h2>
          <p className="text-lg mb-4">
            Need expert pest control in Moulivakkam? Welcome to No.1 Quality Pest Control, your go-to team for fast,
            effective, and budget-friendly pest solutions in Moulivakkam Chennai.
          </p>
          <p className="text-lg mb-4">
            Whether it's your home, office, or commercial space — we provide 100% safe pest control services with
            certified professionals and eco-friendly options.
          </p>
        </motion.div>

        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-2xl font-bold mb-6">Say Goodbye to Pests with Our Top Services:</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🪳 Cockroach Control Services in Moulivakkam</h3>
              <p>Complete cockroach elimination using advanced techniques and safe chemicals for lasting results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🐜 Termite Treatment & Prevention</h3>
              <p>Protect your property from termite damage with our comprehensive treatment solutions.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🐀 Rodent & Rat Removal Services</h3>
              <p>Effective rodent control to eliminate mice and rats from your property with preventive measures.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🦟 Mosquito Control Solutions</h3>
              <p>Protect your family from disease-carrying mosquitoes with our specialized treatments.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🛏 Bed Bug Removal & Treatment</h3>
              <p>Complete bed bug elimination using specialized techniques for lasting results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">🌱 Organic & Herbal Pest Control Options</h3>
              <p>Eco-friendly pest control solutions that are safe for your family, pets, and the environment.</p>
            </div>
          </div>
          <p className="mt-6 text-lg">
            All treatments use government-approved chemicals to protect your health & environment.
          </p>
        </motion.div>

        <motion.div
          className="mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-2xl font-bold mb-6">Why Moulivakkam Residents Choose Us:</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Pest Professionals</h3>
              <p>Our team consists of highly trained experts with years of experience in pest control.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Safe for Kids & Pets</h3>
              <p>We use family-friendly treatments that are effective against pests but safe for your loved ones.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Fast Response, Same-Day Service</h3>
              <p>We understand pest emergencies and offer prompt service when you need it most.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Pricing & Free Quotes</h3>
              <p>Competitive pricing with no hidden charges and complimentary property assessment.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Fully Licensed & Trusted in Chennai</h3>
              <p>We are a licensed pest control provider with all necessary certifications.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ 5-Star Rated on Sulekha Chennai</h3>
              <p>Highly rated by satisfied customers across Chennai for our quality service.</p>
            </div>
          </div>
        </motion.div>

        <TestimonialsSection
          testimonials={[
            {
              quote: "Excellent cockroach control service. Very professional and on time.",
              author: "Meenakshi G., Moulivakkam",
              rating: 5,
              location: "Moulivakkam",
            },
            {
              quote: "Quick service and budget-friendly termite treatment. Highly recommend!",
              author: "Vishnu M., Resident",
              rating: 5,
              location: "Moulivakkam",
            },
          ]}
        />

        <motion.div
          className="mb-12 text-center"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-6">Call the Best Pest Control in Moulivakkam Today!</h2>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="mb-2">
              <strong>📍 Location:</strong> Moulivakkam, Chennai, Tamil Nadu
            </p>
            <p className="mb-2">
              <strong>📞 Phone:</strong>{" "}
              <a href="tel:+917558108600" className="text-blue-600 hover:underline">
                +91 75581 08600
              </a>
            </p>
            <p className="mb-2">
              <strong>📧 Email:</strong>{" "}
              <a href="mailto:no1qualitypestcontrol@gmail.com" className="text-blue-600 hover:underline">
                no1qualitypestcontrol@gmail.com
              </a>
            </p>
            <p className="mb-2">
              <strong>🌐 Website:</strong>{" "}
              <a
                href="https://www.no1qualitypestcontrol.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                www.no1qualitypestcontrol.com
              </a>
            </p>
          </div>
        </motion.div>

        <ProcessSection />
        <BenefitsSection />
        <ContactForm />
      </div>
    </>
  )
}
