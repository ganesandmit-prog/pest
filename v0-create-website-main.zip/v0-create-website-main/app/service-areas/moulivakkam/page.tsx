import type { Metadata } from "next"
import MoulivakkamPestControlClient from "./MoulivakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Moulivakkam, Chennai - No.1 Quality Pest Control",
  description:
    "Professional pest control services in Moulivakkam, Chennai. Safe, reliable & affordable solutions for cockroach, termite, rodent & mosquito control. Call now!",
}

export default function MoulivakkamPage() {
  return <MoulivakkamPestControlClient />
}
