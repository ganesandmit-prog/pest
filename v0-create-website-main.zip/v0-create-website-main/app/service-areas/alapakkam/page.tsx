import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Alapakkam - Chennai",
  description:
    "Looking for reliable pest control services in Alapakkam, Chennai? No.1 Quality Pest Control offers certified, result-driven, and affordable pest control services for homes, apartments, and commercial spaces.",
}

export default function AlapakkamPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Alapakkam"
        subtitle="Professional & Affordable Pest Control Services in Alapakkam Chennai"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Alapakkam</h2>
            <p className="mb-4">
              Looking for reliable pest control services in Alapakkam, Chennai? Welcome to No.1 Quality Pest Control,
              your trusted residential pest control service provider for homes, apartments, and commercial spaces.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Why Choose Our Pest Control in Alapakkam?</h2>
            <p className="mb-4">
              We're a certified, result-driven, and affordable pest control company in Alapakkam, offering:
            </p>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>General Pest Control</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Residential Pest Control Services</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Eco-Friendly & Odorless Treatment</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Affordable Charges</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Top Rated on Sulekha & Google Reviews</span>
              </li>
            </ul>
            <p className="mt-4">
              We understand your pest problems and offer the best pest control in Chennai, with special expertise in
              Alapakkam and nearby areas.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Alapakkam Include:</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Cockroach Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Termite Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Mosquito Control</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Rodent Removal</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Bed Bug Treatment</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">Ants & Spider Solutions</div>
            </div>
            <p>
              From villas to apartments, we provide safe and effective pest control solutions tailored to your needs.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              General & Residential Pest Control Services in Alapakkam Chennai
            </h2>
            <p className="mb-4">Our experienced technicians deliver residential pest control that is:</p>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Safe for kids & pets</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Long-lasting</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Fully herbal / organic on request</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Budget-friendly with transparent charges</span>
              </li>
            </ul>
            <p className="mt-4">
              Whether you're dealing with cockroaches, termites, or general pests, we offer the most dependable pest
              control in Alapakkam at the best price.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Trusted by Alapakkam Residents – Reviews on Sulekha & More
            </h2>
            <p className="mb-4">Don't take our word for it.</p>
            <p className="mb-4">
              We are one of the top-rated pest control companies in Alapakkam with consistent 5-star reviews on Sulekha,
              JustDial, and Google.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">✅ Professional Team</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">✅ On-Time Service</div>
              <div className="bg-light-cream p-3 rounded-lg text-center shadow-sm">✅ Visible Results</div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Service Locations Near Alapakkam, Chennai</h2>
            <p className="mb-4">We serve Alapakkam and surrounding areas like:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Valasaravakkam</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Porur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Ramapuram</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Virugambakkam</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">KK Nagar</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Ashok Nagar</div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Book the Best Pest Control in Alapakkam Today!</h2>
            <p className="mb-4">Don't wait until the pests take over.</p>
            <p className="mb-4">
              Call the No.1 Quality Pest Control team and protect your space with the best residential pest control in
              Chennai.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
            </div>
            <div>
              <p>
                <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
              </p>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.8}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Alapakkam
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
