"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PallikaranaiPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Pallikaranai",
              "description": "Professional pest control services in Pallikaranai, Chennai. We offer residential and commercial pest control, termite control, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pallikaranai",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Pallikaranai, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Termite Control", "Cockroach Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Pallikaranai?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Pallikaranai including cockroach control, termite control, mosquito control, rodent control, and general pest control for both residential and commercial properties."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Pallikaranai?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Pallikaranai start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Pallikaranai. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Pallikaranai?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Pallikaranai. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Pallikaranai, Chennai"
          description="Professional pest control solutions for homes, villas, and businesses in Pallikaranai. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Pallikaranai – Trusted Pest Control Company in Chennai
              </h2>
              <p className="text-gray-600 mb-4">
                Looking for professional pest control services in Pallikaranai, Chennai? 🏡 We offer complete pest
                management solutions including cockroach control, termite control, mosquito control, and more at the
                best prices!
              </p>
              <p className="text-gray-600 mb-4">
                Whether it's a villa, an apartment, or a commercial space, our expert pest control company ensures a
                pest-free environment with guaranteed results.
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Pallikaranai</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Cockroach Control Services – Advanced treatments to eliminate cockroaches.</li>
                <li>Termite Control Services – Complete termite extermination and prevention solutions.</li>
                <li>Mosquito Control – Specialized mosquito removal for a healthy living space.</li>
                <li>Rodent Control and Removal – Effective rodent treatment for homes and businesses.</li>
                <li>General Pest Control – Covers ants, spiders, bed bugs, and more.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Why Choose Our Pest Control Company in Pallikaranai Chennai?
              </h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Experienced Professionals – Skilled and trained pest control technicians.</li>
                <li>Eco-Friendly Treatment Options – Safe for your family, pets, and the environment.</li>
                <li>Affordable Pricing and Free Quotes – Transparent and competitive rates.</li>
                <li>Fast and Reliable Services – Immediate response and effective treatment.</li>
                <li>
                  Villa and Apartment Pest Solutions – Customized services for residential and commercial properties.
                </li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Serving All Areas in Pallikaranai Chennai</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Villas in Pallikaranai</li>
                <li>Residential Apartments</li>
                <li>Commercial Offices and Shops</li>
                <li>Restaurants, Warehouses, and Educational Institutions</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Get a Free Quote for Pest Control in Pallikaranai!</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
