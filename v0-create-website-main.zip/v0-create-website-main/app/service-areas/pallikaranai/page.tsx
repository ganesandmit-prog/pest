import type { Metadata } from "next"
import { PallikaranaiPestControlClient } from "./PallikaranaiPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pallikaranai | Trusted Pest Control Company in Chennai",
  description:
    "Looking for professional pest control services in Pallikaranai, Chennai? We offer complete pest management solutions including cockroach control, termite control, mosquito control, and more at the best prices!",
  keywords:
    "pest control Pallikaranai, pest control services Pallikaranai, Pallikaranai pest control, cockroach control Pallikaranai, termite control Pallikaranai, mosquito control Pallikaranai, rodent control Pallikaranai, general pest control Pallikaranai, villa pest control, apartment pest control, commercial pest control, pest control company Pallikaranai, affordable pest control, pest control Chennai",
}

export default function PallikaranaiPage() {
  return <PallikaranaiPestControlClient />
}
