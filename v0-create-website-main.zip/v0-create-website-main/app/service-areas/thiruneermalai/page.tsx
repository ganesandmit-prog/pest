import type { Metadata } from "next"
import { ThiruneermalaiPestControlClient } from "./ThiruneermalaiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Thiruneermalai, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thiruneermalai, Chennai. We offer cockroach, mosquito, bed bug, termite, rodent control & more. 45+ years of experience.",
  keywords:
    "pest control Thiruneermalai, cockroach control Thiruneermalai, termite treatment Thiruneermalai, bed bug control Thiruneermalai, mosquito control Thiruneermalai, rodent control Thiruneermalai, pest management Thiruneermalai Chennai, commercial pest control Thiruneermalai, residential pest control Thiruneermalai",
}

export default function ThiruneermalaiPage() {
  return <ThiruneermalaiPestControlClient />
}
