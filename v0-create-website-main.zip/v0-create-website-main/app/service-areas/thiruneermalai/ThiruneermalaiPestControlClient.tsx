"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export function ThiruneermalaiPestControlClient() {
  const [activeTab, setActiveTab] = useState("services")

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        heading="Professional Pest Control Services in Thiruneermalai, Chennai"
        subheading="No.1 Quality Pest Control provides expert pest management solutions for homes and businesses in Thiruneermalai"
      />

      <div className="container px-4 py-6 md:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Tabs defaultValue="services" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="services">Services</TabsTrigger>
                <TabsTrigger value="process">Our Process</TabsTrigger>
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
              </TabsList>
              <TabsContent value="services" className="mt-6">
                <div className="prose max-w-none">
                  <h2>Pest Control Services in Thiruneermalai</h2>
                  <p>
                    No.1 Quality Pest Control offers comprehensive pest management solutions to residents and businesses
                    in Thiruneermalai, Chennai. With over 45 years of experience, our team of certified technicians is
                    equipped to handle all types of pest infestations, from common household pests to more complex
                    commercial pest problems.
                  </p>
                  <p>
                    Thiruneermalai, being a suburban area in the southwestern part of Chennai, faces unique pest
                    challenges due to its proximity to the Adyar River and developing residential areas. Our localized
                    approach ensures that we address the specific pest issues prevalent in Thiruneermalai, providing
                    targeted and effective solutions.
                  </p>
                </div>
                <ServicesList location="Thiruneermalai" />
              </TabsContent>
              <TabsContent value="process" className="mt-6">
                <ProcessSection location="Thiruneermalai" />
              </TabsContent>
              <TabsContent value="benefits" className="mt-6">
                <BenefitsSection location="Thiruneermalai" />
              </TabsContent>
              <TabsContent value="testimonials" className="mt-6">
                <TestimonialsSection location="Thiruneermalai" />
              </TabsContent>
            </Tabs>
          </div>
          <div className="lg:col-span-1">
            <div className="sticky top-20">
              <ContactForm location="Thiruneermalai" />
              <div className="mt-6">
                <QuickLinks />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
