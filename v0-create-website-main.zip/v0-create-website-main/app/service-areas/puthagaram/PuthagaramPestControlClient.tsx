"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function PuthagaramPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Puthagaram, Chennai"
        description="Professional & affordable pest control services in Puthagaram. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            🐞 Pest Control in Puthagaram – Residential & Organic Pest Experts
          </h2>

          <p>
            Looking for residential pest control in Puthagaram? Our services in Puthagaram, Chennai, cover everything
            from gel-based cockroach removal to organic pest control and pest exterminator services. We are
            Sulekha-listed, customer-approved, and budget-friendly.
          </p>

          <h3 className="text-2xl font-bold text-primary">🌿 Our Services in Puthagaram:</h3>

          <ul>
            <li>🪳 Gel Pest Control – No smell, no mess!</li>
            <li>🦟 Mosquito & Fly Control</li>
            <li>🛏️ Bed Bugs & Lizard Treatment</li>
            <li>🐜 Termite & Wood Borer Solutions</li>
            <li>🌱 Organic Pest Management for chemical-free homes</li>
            <li>🧹 Cleaning & Disinfection Services</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Puthagaram Trusts Us:</h3>

          <ul>
            <li>🏠 Specialized Residential Pest Control</li>
            <li>📈 Proven Results with Long-Term Protection</li>
            <li>🔬 Safe for Kids & Pets</li>
            <li>📞 Free Inspection + Instant Quotes</li>
            <li>🌐 Trusted in Chennai & Vellore Areas</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Contact: +91 7558108600</h3>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
