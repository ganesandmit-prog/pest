import type { Metadata } from "next"
import { PuthagaramPestControlClient } from "./PuthagaramPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Puthagaram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Puthagaram, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Puthagaram, pest services Puthagaram, cockroach control Puthagaram, termite treatment Puthagaram, bed bug control Puthagaram, mosquito control Puthagaram, rodent control Puthagaram, pest control services Puthagaram Chennai",
}

export default function PuthagaramPage() {
  return <PuthagaramPestControlClient />
}
