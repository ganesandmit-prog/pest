import type { Metadata } from "next"
import VanagaramPestControlClient from "./VanagaramPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Vanagaram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Vanagaram, Chennai. Effective solutions for cockroaches, termites, mosquitoes, bed bugs & rodents. Call +91 7558108600 for free inspection!",
  keywords:
    "pest control Vanagaram, termite control Vanagaram, cockroach control Vanagaram, mosquito control Vanagaram, bed bug treatment Vanagaram, rodent control Vanagaram, pest services Vanagaram Chennai, best pest control Vanagaram",
}

export default function VanagaramPestControlPage() {
  return <VanagaramPestControlClient />
}
