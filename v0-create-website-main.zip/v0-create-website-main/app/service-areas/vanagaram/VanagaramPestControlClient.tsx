"use client"

import { useState } from "react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"
import ContactForm from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"
import Image from "next/image"
import Link from "next/link"
import { Check, MapPin, Phone, Star } from "lucide-react"

export function VanagaramPestControlClient() {
  const [location] = useState("Vanagaram")

  return (
    <>
      <PageHeader
        title="No.1 Quality Pest Control Services in Vanagaram, Chennai"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Professional & Affordable Pest Control in Vanagaram"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold mb-4">Expert Pest Control Services in Vanagaram, Chennai</h2>
              <p className="text-gray-600 mb-6">
                Vanagaram, a rapidly developing area in Chennai, faces unique pest challenges due to its mix of
                residential complexes, commercial establishments, and proximity to water bodies. No.1 Quality Pest
                Control offers specialized pest management solutions tailored to Vanagaram's specific needs.
              </p>
              <p className="text-gray-600 mb-6">
                Our 45+ years of experience in pest control services makes us the most trusted choice for residents and
                businesses in Vanagaram. We provide comprehensive pest management solutions that effectively eliminate
                cockroaches, termites, mosquitoes, rodents, bed bugs, and other pests common in this area.
              </p>
              <div className="bg-light-green/10 p-4 rounded-lg border border-light-green mb-6">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-light-green" />
                  Common Pest Issues in Vanagaram:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Mosquito infestations due to nearby water bodies and construction sites</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Termite problems in newly constructed buildings and apartments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Cockroach and rodent issues in commercial establishments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Bed bug infestations in residential complexes</span>
                  </li>
                </ul>
              </div>
              <div className="flex items-center justify-start mb-6">
                <Phone className="h-5 w-5 text-light-green mr-2" />
                <span className="font-semibold">Call us at: </span>
                <a href="tel:+917558108600" className="text-light-green font-bold ml-2 hover:underline">
                  +91 7558108600
                </a>
              </div>
              <Link href="/contact-us" className="btn-primary">
                Get Free Inspection in Vanagaram
              </Link>
            </AnimatedSection>

            <AnimatedSection animation="fadeIn" delay={0.2}>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Pest Control Services in Vanagaram"
                  width={800}
                  height={600}
                  className="w-full h-auto"
                />
              </div>
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <Star className="h-5 w-5 mr-2 text-yellow-500" />
                  Why Vanagaram Residents Choose Us:
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>45+ years of pest control expertise in Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Eco-friendly and child-safe pest control solutions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Customized treatment plans for Vanagaram's specific pest issues</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Affordable pricing with no hidden charges</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                    <span>Emergency pest control services available</span>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <ServicesList
        title="Our Comprehensive Pest Control Services in Vanagaram"
        description="We offer a wide range of pest control services to keep your home and business in Vanagaram pest-free."
        location="Vanagaram"
      />

      <ProcessSection
        title="Our Pest Control Process in Vanagaram"
        description="Our systematic approach ensures effective and long-lasting pest control results for Vanagaram residents and businesses."
      />

      <BenefitsSection
        title="Benefits of Our Pest Control Services in Vanagaram"
        description="Experience the advantages of choosing No.1 Quality Pest Control for your pest management needs in Vanagaram."
      />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Pest Control FAQs for Vanagaram Residents</h2>
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">What are the most common pests in Vanagaram?</h3>
                <p className="text-gray-600">
                  Vanagaram commonly experiences issues with mosquitoes (due to nearby water bodies), termites
                  (especially in newer constructions), cockroaches, rodents, and bed bugs. The area's rapid development
                  and mix of residential and commercial spaces create ideal conditions for various pest infestations.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  How often should Vanagaram residents get pest control treatments?
                </h3>
                <p className="text-gray-600">
                  For Vanagaram properties, we recommend quarterly pest control treatments for general pest management.
                  However, specific issues like termite control may require annual maintenance, while mosquito control
                  might need monthly treatments during monsoon seasons. We create customized schedules based on your
                  property's specific needs.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Do you offer emergency pest control services in Vanagaram?
                </h3>
                <p className="text-gray-600">
                  Yes, we provide emergency pest control services for Vanagaram residents and businesses. Our team can
                  respond quickly to urgent pest situations, typically within 24 hours of your call. Contact our
                  emergency line at +91 7558108600 for immediate assistance.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">
                  Are your pest control methods safe for children and pets in Vanagaram homes?
                </h3>
                <p className="text-gray-600">
                  Absolutely. We use eco-friendly, child-safe, and pet-friendly pest control solutions in Vanagaram
                  homes. Our technicians are trained to apply treatments that effectively eliminate pests while ensuring
                  the safety of your family and pets. We'll provide specific safety instructions for each treatment.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <TestimonialsSection
        title="What Our Vanagaram Customers Say"
        description="Read testimonials from satisfied customers in Vanagaram who have experienced our quality pest control services."
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Contact Us for Pest Control in Vanagaram</h2>
            <ContactForm defaultLocation={location} />
          </AnimatedSection>
        </div>
      </section>

      <QuickLinks />
    </>
  )
}

export default VanagaramPestControlClient
