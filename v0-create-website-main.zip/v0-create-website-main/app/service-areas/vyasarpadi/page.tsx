import type { Metadata } from "next"
import VyasarpadiPestControlClient from "./VyasarpadiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Vyasarpadi, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Vyasarpadi, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with safe, effective treatments. Call now!",
  keywords:
    "pest control Vyasarpadi, termite control Vyasarpadi, cockroach control Vyasarpadi, bed bug treatment Vyasarpadi, rodent control Vyasarpadi, mosquito control Vyasarpadi, pest control services Vyasarpadi Chennai, best pest control Vyasarpadi",
}

export default function VyasarpadiPestControlPage() {
  return <VyasarpadiPestControlClient />
}
