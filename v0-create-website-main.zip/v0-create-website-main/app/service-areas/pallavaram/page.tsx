import type { Metadata } from "next"
import { PallavaramPestControlClient } from "./PallavaramPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pallavaram | Expert Pest Control Services in Chennai",
  description:
    "Looking for affordable pest control services in Pallavaram, Chennai? Say goodbye to pests with our trusted pest control company specializing in cockroach control, general pest control, and more.",
  keywords:
    "pest control Pallavaram, pest control services Pallavaram, Pallavaram pest control, cockroach control Pallavaram, general pest control Pallavaram, mosquito control Pallavaram, rodent control Pallavaram, residential pest control Pallavaram, commercial pest control Pallavaram, pest control company Pallavaram, affordable pest control Pallavaram, eco-friendly pest control, pest control Chennai",
}

export default function PallavaramPage() {
  return <PallavaramPestControlClient />
}
