"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PallavaramPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Pallavaram",
              "description": "Professional pest control services in Pallavaram, Chennai. We offer residential and commercial pest control, cockroach control, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pallavaram",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Pallavaram, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Cockroach Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Pallavaram?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Pallavaram including cockroach control, general pest control, mosquito and fly control, rodent removal, and specialized services for both residential and commercial properties."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Pallavaram?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Pallavaram start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Pallavaram. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Pallavaram?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Pallavaram. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Pallavaram, Chennai"
          description="Professional pest control solutions for homes and businesses in Pallavaram. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Pallavaram – Expert Pest Control Services in Chennai
              </h2>
              <p className="text-gray-600 mb-4">
                Looking for affordable pest control services in Pallavaram, Chennai? 🏡 Say goodbye to pests with our
                trusted pest control company specializing in cockroach control, general pest control, and more.
              </p>
              <p className="text-gray-600 mb-4">
                We deliver fast, safe, and eco-friendly control services to protect your home or office at the best
                rates in Pallavaram!
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Pallavaram</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Cockroach Control Services – Effective solutions to eliminate cockroaches permanently.</li>
                <li>General Pest Control – Comprehensive control for ants, spiders, bugs, and more.</li>
                <li>Mosquito and Fly Control – Specialized treatments for a mosquito-free environment.</li>
                <li>Rodent and Rat Removal Services – Advanced rodent control methods for complete protection.</li>
                <li>
                  Residential and Commercial Pest Control – Tailored pest control for homes, offices, and businesses.
                </li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Why Choose Our Pest Control Company in Pallavaram, Chennai?
              </h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Expert Technicians – Skilled professionals trained in handling all types of pest issues.</li>
                <li>Affordable Pest Control Prices – Competitive rates with no hidden costs.</li>
                <li>Fast Response and Quick Treatment – Immediate action for urgent pest problems.</li>
                <li>Eco-Friendly Solutions – Safe for kids, pets, and the environment.</li>
                <li>Customer Satisfaction Guarantee – 100% commitment to solving your pest issues.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Areas We Cover</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Pallavaram Residential Apartments</li>
                <li>Villas and Gated Communities</li>
                <li>Commercial Offices in Pallavaram Chennai</li>
                <li>Shops, Restaurants, and Warehouses</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Get Free Pest Control Quotes in Pallavaram</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
