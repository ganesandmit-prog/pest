"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function ChintadripetPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader title="Pest Control Services in Chintadripet" subtitle="Trusted, Safe & Effective Solutions" />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Pest Control in Chintadripet</h2>
                  <div className="prose max-w-none">
                    <p>
                      Looking for pest control services in Chintadripet, Chennai? You're in the right place! We are your
                      local pest control experts offering affordable, safe, and guaranteed solutions for all types of
                      pests. Whether it's cockroaches, termites, rats, or bed bugs, we offer professional pest control
                      that residents and businesses in Chintadripet trust.
                    </p>
                    <h3>Our Specialized Services in Chintadripet:</h3>
                    <ul>
                      <li>General Pest Control</li>
                      <li>Termite Control</li>
                      <li>Cockroach Control</li>
                      <li>Rodent Treatment</li>
                      <li>Deep Cleaning & Disinfection</li>
                      <li>Pre/Post Construction Anti-Termite Service</li>
                    </ul>
                    <h3>Why Choose Us in Chintadripet?</h3>
                    <ul>
                      <li>Eco-Friendly, Odor-Free Solutions</li>
                      <li>10+ Years of Expertise</li>
                      <li>Sulekha Verified | Google Rated 4.9⭐</li>
                      <li>Same Day Emergency Visits</li>
                      <li>Serving Chennai, Tamil Nadu with Local Technicians</li>
                      <li>Free Inspection + Affordable Packages</li>
                    </ul>
                    <h3>Areas We Serve Near Chintadripet:</h3>
                    <ul>
                      <li>Egmore</li>
                      <li>Anna Salai</li>
                      <li>Chepauk</li>
                      <li>Park Town</li>
                      <li>Mount Road</li>
                      <li>Pudupet</li>
                      <li>Triplicane</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Chintadripet"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "CheckCircle",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Chintadripet"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Chintadripet</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Chintadripet home or business? Contact No.1 Quality Pest
                        Control today for a free inspection and quote. Our team of experienced professionals is ready to
                        help you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
