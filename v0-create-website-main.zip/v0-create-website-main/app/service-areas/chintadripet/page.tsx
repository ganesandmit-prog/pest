import type { Metadata } from "next"
import ChintadripetPestControlClient from "./ChintadripetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Chintadripet | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Chintadripet, Chennai. Trusted, safe & effective solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Chintadripet, pest control services Chintadripet, Chintadripet pest control, cockroach control Chintadripet, termite control Chintadripet, bed bug control Chintadripet, rodent control Chintadripet",
}

export default function ChintadripetPestControl() {
  return <ChintadripetPestControlClient />
}
