import KotturPestControlClient from "./KotturPestControlClient"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Pest Control Services in Kottur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kottur, Chennai. We offer effective solutions for cockroach, termite, mosquito, and rodent control. Contact us today!",
  keywords:
    "pest control Kottur, termite control Kottur, cockroach control Kottur, mosquito control Kottur, rodent control Kottur, bed bug treatment Kottur, pest control services Kottur Chennai, affordable pest control Kottur",
}

export default function KotturPage() {
  return <KotturPestControlClient />
}
