"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KotturPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Trusted Pest Control in Kottur, Chennai" subtitle="Fast & Affordable Services" />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are you in search of pest control services in Kottur, Chennai? Look no further! At Acme Pest Control, we
                offer effective and affordable pest control solutions to handle all your pest problems, from spider
                control to termite treatment. We ensure that your home or office remains pest-free with our expert
                services and customized solutions.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">🛠️ Our Pest Control Services in Kottur:</h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🕷️</span>
                    <span>
                      <strong>Spider Control</strong> – Get rid of spiders in your home or office
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Control</strong> – Protect your property with effective termite solutions
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Fast and efficient cockroach extermination
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Ensure a mosquito-free environment
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent & Rat Control</strong> – Quick and safe rodent removal
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🌱</span>
                    <span>
                      <strong>General Pest Control</strong> – Comprehensive pest management for all pests
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">💡 Why Choose Acme Pest Control in Kottur?</h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Experienced pest control professionals in Kottur Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Safe, eco-friendly, and non-toxic pest control methods</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Affordable pest control services with no hidden charges</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Quick and reliable service available 24/7</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Trusted by both residential and commercial clients in Kottur</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Licensed and certified experts with years of experience</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 Areas We Serve Around Kottur:</h2>
                <p className="mb-4">Kotturpuram | Saidapet | Guindy | Taramani | Alandur | Velachery</p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">📞 Contact Us for Pest Control in Kottur Today!</h2>
                <p className="mb-2">
                  📱 Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Website: <span className="font-bold">www.acmepestcontrol.com</span>
                </p>
                <p>📍 Location: Kottur, Chennai Tamil Nadu, India</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🏡 Don't let pests take over your property! Contact our expert team today for professional pest
                  control services in Kottur, Chennai. We're here to help you maintain a clean, healthy, and pest-free
                  environment.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Kottur</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
