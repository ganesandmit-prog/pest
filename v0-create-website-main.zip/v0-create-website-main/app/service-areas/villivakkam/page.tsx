import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import VillivakkamPestControlClient from "./VillivakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Villivakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Villivakkam, Chennai. Effective solutions for cockroaches, termites, bed bugs, rodents & mosquitoes. Call +91 7558108600 for same-day service!",
  alternates: {
    canonical: "https://no1qualitypestcontrol.com/service-areas/villivakkam",
  },
}

export default function VillivakkamPestControlPage() {
  return (
    <>
      <PageHeader
        title="Pest Control Services in Villivakkam, Chennai"
        backgroundImage="/images/service-areas/villivakkam-pest-control.jpg"
        subtitle="Professional & Affordable Pest Management Solutions"
      />
      <VillivakkamPestControlClient />
    </>
  )
}
