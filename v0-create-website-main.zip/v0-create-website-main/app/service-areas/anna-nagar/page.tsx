import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Anna Nagar | No.1 Quality Pest Control Chennai",
  description:
    "If you're looking for top-rated pest control services in Anna Nagar, Chennai, we're here to help. Our general pest control solutions are safe, effective, and affordable.",
}

export default function AnnaNagarPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control in Anna Nagar, Chennai" subtitle="Trusted & Affordable" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              If you're looking for top-rated pest control services in Anna Nagar, Chennai, we're here to help. Whether
              it's cockroaches, termites, mosquitoes, or rats, our general pest control solutions are safe, effective,
              and affordable.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why Choose Our Pest Control Services in Anna Nagar?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Expert Pest Control Service Providers in Anna Nagar Chennai</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Certified, Odorless, Eco-Friendly Treatments</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Professional Technicians With Years of Experience</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Same-Day Service Available in Anna Nagar & Nearby Areas</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Trusted by 500+ Clients With 5-Star Reviews</span>
              </li>
            </ul>
            <p className="mt-4">We offer customized control services for both residential and commercial properties.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Services Offered in Anna Nagar Chennai:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🪳 Cockroach Control in Anna Nagar</h3>
                <p>Effective elimination of cockroaches from your home or business premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐜 Termite Treatment (Pre & Post Construction)</h3>
                <p>Comprehensive termite protection for your property and wooden furniture.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🦟 Mosquito Control Services</h3>
                <p>Advanced treatments to keep your home free from mosquitoes.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🐀 Rodent/Rat Control</h3>
                <p>Safe and effective solutions to eliminate rats and mice from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🛏️ Bed Bug Elimination</h3>
                <p>Specialized treatments to eliminate bed bugs completely.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🧽 Deep Home Cleaning & Sanitization</h3>
                <p>Professional cleaning services to maintain a hygienic environment.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🏢 Office & Industrial Pest Solutions</h3>
                <p>Specialized pest control solutions for commercial spaces and offices.</p>
              </div>
            </div>
            <p className="mt-4">All our pest control services are designed to give long-lasting protection.</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Areas We Cover Around Anna Nagar:</h2>
            <p>We proudly serve Anna Nagar and its neighboring areas such as:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Anna Nagar East & West</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Thirumangalam</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Mogappair</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Shenoy Nagar</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Kilpauk</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Aminjikarai</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Koyambedu</div>
            </div>
            <p className="mt-4">
              We are one of the top pest control companies in Anna Nagar Chennai and our team can be at your location
              within hours of your call.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 className="text-2xl font-bold mb-4">What Makes Us the Best Pest Control Company in Anna Nagar?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Affordable Pricing & Flexible Packages</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Licensed Chemicals Approved by Govt.</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Free Inspection & Expert Consultation</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Positive Customer Reviews Across All Platforms</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Verified on Sulekha, Justdial, IndiaMART</span>
              </li>
            </ul>
            <p className="mt-4">
              We're rated as one of the most reliable and result-oriented pest control companies in the Anna Nagar
              Chennai region.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Book Your Service Today!</h2>
            <p className="mb-4">Say goodbye to pests with our control pest control services.</p>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Website:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Anna Nagar</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
