import type { Metadata } from "next"
import ThirumullaivoayalPestControlClient from "./ThirumullaivoayalPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Thirumullaivoyal, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thirumullaivoyal, Chennai. Effective solutions for cockroaches, termites, bed bugs, rodents & more. Call us today!",
  keywords:
    "pest control Thirumullaivoyal, termite control Thirumullaivoyal, cockroach control Thirumullaivoyal, bed bug treatment Thirumullaivoyal, rodent control Thirumullaivoyal, pest management Chennai, Thirumullaivoyal pest services",
}

export default function ThirumullaivoayalPestControlPage() {
  return <ThirumullaivoayalPestControlClient />
}
