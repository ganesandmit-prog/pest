"use client"

import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"

export default function ThirumullaivoayalPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Professional Pest Control Services in Thirumullaivoyal, Chennai"
        description="No.1 Quality Pest Control provides expert pest management solutions in Thirumullaivoyal. Our 45+ years of experience ensures your home and business remain pest-free."
        keywords="pest control Thirumullaivoyal, Thirumullaivoyal pest services, pest management Thirumullaivoyal, pest control near me, No.1 Quality Pest Control Thirumullaivoyal"
        location="Thirumullaivoyal"
      />

      <main className="flex-grow">
        <section className="container mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">Pest Control Services in Thirumullaivoyal, Chennai</h2>
              <p className="mb-4">
                Thirumullaivoyal, a developing residential area in the northwestern part of Chennai, requires
                specialized pest control solutions to address its unique suburban pest challenges. No.1 Quality Pest
                Control brings 45+ years of expertise to Thirumullaivoyal, offering comprehensive pest management
                services tailored to the specific needs of this growing locality.
              </p>
              <p className="mb-4">
                Our team of certified pest control specialists in Thirumullaivoyal is equipped with advanced tools and
                environmentally friendly treatments to effectively eliminate pests while ensuring the safety of your
                family, employees, and customers. We understand the importance of maintaining a pest-free environment in
                both residential properties and commercial establishments in Thirumullaivoyal.
              </p>
              <p className="mb-4">
                Whether you're dealing with mosquitoes from nearby water bodies, termites affecting new constructions,
                or rodents in your home, our Thirumullaivoyal pest control team provides prompt, reliable, and effective
                solutions. We serve all areas of Thirumullaivoyal including areas near Ambattur Industrial Estate and
                surrounding neighborhoods.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">Common Pest Problems in Thirumullaivoyal</h2>
              <p className="mb-4">
                Thirumullaivoyal faces several pest challenges due to its suburban location, ongoing development, and
                the tropical climate of Chennai. Some common pest issues in Thirumullaivoyal include:
              </p>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Mosquito Infestations:</strong> Due to proximity to open areas and water bodies, mosquito
                  control is essential in Thirumullaivoyal.
                </li>
                <li>
                  <strong>Termite Problems:</strong> New constructions in Thirumullaivoyal are particularly vulnerable
                  to termite damage.
                </li>
                <li>
                  <strong>Rodent Control:</strong> Mice and rats are frequently reported in both residential and
                  developing areas.
                </li>
                <li>
                  <strong>Cockroach Infestations:</strong> Common in residential buildings in Thirumullaivoyal.
                </li>
                <li>
                  <strong>Garden Pests:</strong> Many homes with gardens in Thirumullaivoyal face issues with garden
                  pests.
                </li>
              </ul>

              <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Our Pest Control Service in Thirumullaivoyal?</h2>
              <ul className="list-disc pl-5 mb-4 space-y-2">
                <li>
                  <strong>Local Expertise:</strong> Our technicians understand Thirumullaivoyal's specific pest patterns
                  and challenges.
                </li>
                <li>
                  <strong>Customized Solutions:</strong> We develop tailored pest management plans for each property in
                  Thirumullaivoyal.
                </li>
                <li>
                  <strong>Eco-Friendly Approaches:</strong> We prioritize green pest control methods that are safe for
                  families and pets.
                </li>
                <li>
                  <strong>Preventive Strategies:</strong> Beyond treatment, we help Thirumullaivoyal residents prevent
                  future infestations.
                </li>
                <li>
                  <strong>Emergency Response:</strong> Quick service for urgent pest problems in Thirumullaivoyal.
                </li>
                <li>
                  <strong>Comprehensive Coverage:</strong> We handle all types of pests common to the Thirumullaivoyal
                  area.
                </li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <ContactForm location="Thirumullaivoyal" />
              <div className="mt-8">
                <QuickLinks />
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection location="Thirumullaivoyal" />
      </main>
    </div>
  )
}
