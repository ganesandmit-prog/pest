"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SurapetPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Surapet, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Trusted Pest Control in Surapet, Chennai – Affordable & Effective Solutions
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for expert pest control services in Surapet, Chennai? Our certified team offers complete pest
                  solutions for homes and commercial spaces in and around Surapet. Whether it's cockroach control,
                  termite treatment, or general pest control, we provide fast, safe, and affordable pest management with
                  100% customer satisfaction.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐜 Our Pest Control Services in Surapet:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control – Gel & spray-based treatments</li>
                  <li>🐀 Rodent Control – Complete mouse and rat removal</li>
                  <li>🛏️ Bed Bugs Treatment – Odorless and safe</li>
                  <li>🦟 Mosquito Control – Indoor & outdoor fogging solutions</li>
                  <li>🐜 General Pest Control – Ants, spiders, lizards & more</li>
                  <li>🌱 Eco-Friendly Pest Control – Safe for kids and pets</li>
                  <li>🏠 Termite Control in Surapet – Long-term protection for wood and walls</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">💡 Why Choose Our Pest Control Service in Surapet?</h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Certified Professionals – Experienced in handling all pest types</li>
                  <li>✔️ Safe & Effective Methods – Child and pet-friendly solutions</li>
                  <li>✔️ Affordable Prices – No hidden costs, clear pest control service price in Surapet</li>
                  <li>✔️ Quick Response – Same-day pest control service available</li>
                  <li>✔️ Excellent Customer Reviews – Top-rated in Surapet, Chennai</li>
                  <li>✔️ Free Inspection & Quote – Honest pricing, instant contact</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Serving Surapet and Nearby Locations:</h2>

                <ul className="list-none space-y-2">
                  <li>Surapet, Chennai</li>
                  <li>Puzhal</li>
                  <li>Madhavaram</li>
                  <li>Redhills</li>
                  <li>Nearby residential and commercial areas</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Contact Us Today for Pest Control in Surapet!</h3>
                  <p>
                    Protect your space with the most reliable control services in Surapet. Call us now and get a free
                    inspection & the best price!
                  </p>
                  <p className="mt-4">
                    📱 Call: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
