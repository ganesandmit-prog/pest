import type { Metadata } from "next"
import { SurapetPestControlClient } from "./SurapetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Surapet, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Surapet, Chennai. We offer cockroach, termite, bed bug, and mosquito control with eco-friendly solutions. Call now!",
  keywords:
    "pest control Surapet, Surapet pest control services, pest control company Chennai, eco-friendly pest control Surapet, affordable pest control",
}

export default function SurapetPage() {
  return <SurapetPestControlClient />
}
