"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { CheckCircle } from "lucide-react"

export function MogappairPestControlClient() {
  const [formSubmitted, setFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setFormSubmitted(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Mogappair East & West" subtitle="Fast, Safe & Affordable" />

      <main className="flex-grow">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <FadeIn className="max-w-3xl mx-auto text-center mb-8 md:mb-12">
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                Welcome to No.1 Quality Pest Control – your local experts for reliable and professional pest control in
                Mogappair, Chennai. Whether you're in Mogappair East or Mogappair West, we offer tailored solutions to
                eliminate pests and protect your home or business.
              </p>
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                From stubborn cockroaches to sneaky termites, we've got the right solution for every pest problem! 🚫🐜
              </p>
            </FadeIn>

            <div className="max-w-3xl mx-auto">
              <FadeIn>
                <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
                  🔍 Our Pest Control Services in Mogappair:
                </h2>
              </FadeIn>

              <FadeInStagger className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🪳 Cockroach Control in Mogappair East & West</h3>
                  <p className="text-gray-700">Complete elimination of cockroaches with lasting protection.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐀 Rodent Removal & Prevention</h3>
                  <p className="text-gray-700">Effective solutions to keep rodents away from your property.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐜 Termite Control Services</h3>
                  <p className="text-gray-700">Protect your property from costly termite damage.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🕷 Spider & Ant Extermination</h3>
                  <p className="text-gray-700">Safe removal of spiders, ants and other crawling insects.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🛏️ Bed Bug Treatments</h3>
                  <p className="text-gray-700">Specialized solutions for complete bed bug elimination.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🦟 Mosquito Control</h3>
                  <p className="text-gray-700">Effective mosquito management for a healthier environment.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md col-span-1 md:col-span-2">
                  <h3 className="text-xl font-semibold mb-3">🌿 Eco-Friendly Pest Control – Safe for Kids & Pets!</h3>
                  <p className="text-gray-700">
                    We use government-approved, non-toxic solutions and ensure zero damage to your property.
                  </p>
                </FadeIn>
              </FadeInStagger>

              <FadeIn>
                <div className="bg-blue-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">📍 Why Mogappair Residents Choose Us:</h2>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>10+ Years of Field Experience</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Trained & Certified Pest Control Experts</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>100% Safe & Long-lasting Treatment</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Quick Service – We Reach You FAST!</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Transparent Pricing – No Hidden Charges</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Listed on Sulekha Chennai & Trusted by 1000+ Happy Customers</span>
                    </li>
                  </ul>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">💬 What People Say About Us:</h2>
                  <div className="space-y-6">
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "Our apartment in Mogappair East had a severe bed bug issue. These guys resolved it in one go!
                      Highly recommended!"
                      <footer className="text-right font-medium mt-2">— Priyanka R., Chennai</footer>
                    </blockquote>
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "Best pest control service in Mogappair West. Quick response and very professional."
                      <footer className="text-right font-medium mt-2">— Satish K., Mogappair Resident</footer>
                    </blockquote>
                  </div>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-green-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">
                    📞 Book Your Pest Control Service in Mogappair Today!
                  </h2>
                  <div className="space-y-2 text-center">
                    <p>
                      <strong>📍 Location:</strong> Mogappair East & West, Chennai, Tamil Nadu
                    </p>
                    <p>
                      <strong>📞 Phone:</strong> +91 75581 08600
                    </p>
                    <p>
                      <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
                    </p>
                    <p>
                      <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
                    </p>
                  </div>
                </div>
              </FadeIn>

              <FadeIn>
                <p className="text-center text-lg font-semibold mb-12">
                  ✨ Peace of Mind is Just a Call Away. Get rid of pests today and enjoy a safer, cleaner home tomorrow.
                  Trust No.1 Quality Pest Control – Mogappair's Favorite Pest Control Team! 🏠❤️
                </p>
              </FadeIn>
            </div>
          </div>
        </section>

        <ProcessSection />
        <BenefitsSection />

        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <FadeIn>
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Mogappair</h2>
            </FadeIn>
            <div className="max-w-xl mx-auto">
              <ContactForm onSubmitSuccess={handleFormSubmit} />
              {formSubmitted && (
                <div className="mt-6 p-4 bg-green-100 text-green-700 rounded-md text-center">
                  Thank you for contacting us! We'll get back to you shortly about our pest control services in
                  Mogappair.
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
