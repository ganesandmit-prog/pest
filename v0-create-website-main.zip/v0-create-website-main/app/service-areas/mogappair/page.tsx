import type { Metadata } from "next"
import { MogappairPestControlClient } from "./MogappairPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Mogappair East & West | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mogappair, Chennai. Safe, affordable solutions for cockroaches, termites, bed bugs & more. Call +91 75581 08600 for free quotes!",
  keywords:
    "pest control Mogappair, Mogappair East pest control, Mogappair West pest services, cockroach control Mogappair, termite treatment Mogappair, bed bug control Mogappair, pest control services Chennai",
}

export default function MogappairPestControlPage() {
  return <MogappairPestControlClient />
}
