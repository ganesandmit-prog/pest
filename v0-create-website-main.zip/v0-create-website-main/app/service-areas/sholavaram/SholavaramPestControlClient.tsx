"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SholavaramPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Sholavaram, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🐜 Pest Control in Sholavaram – Safe & Affordable Services
              </h1>

              <div className="prose max-w-none">
                <p>
                  Say goodbye to pests in Sholavaram, Chennai with our expert pest control services! Whether you need
                  general pest control, termite treatment, or cockroach removal, we deliver fast, affordable, and
                  eco-friendly solutions trusted by 1000+ clients and Sulekha verified.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🧼 Our Services in Sholavaram:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach & Ant Control</li>
                  <li>🦟 Mosquito Fogging & Larvicide Spraying</li>
                  <li>🐜 Termite Prevention & Wood Borer Treatment</li>
                  <li>🛏️ Bed Bug Eradication</li>
                  <li>🧼 Sanitization & Cleaning Services</li>
                  <li>🏢 Residential & Commercial Pest Control</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">✔️ Why Choose Us:</h2>

                <ul className="list-none space-y-2">
                  <li>✅ Trained Experts</li>
                  <li>✅ Same-Day Service in Sholavaram & Chennai</li>
                  <li>✅ Perfect Pest Control Solutions for Homes</li>
                  <li>✅ Affordable, Transparent Pricing</li>
                  <li>✅ Eco-Safe Chemicals</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Call Now:</h3>
                  <p className="mt-4">
                    📱 Phone: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
