"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function RamavaramPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Ramavaram, Chennai"
        description="Professional & affordable pest control services in Ramavaram. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            ✅ Trusted Pest Control in Ramavaram, Chennai – Affordable & Effective Solutions
          </h2>

          <p>
            Looking for expert pest control services in Ramavaram, Chennai? Our certified team offers complete pest
            solutions for homes and commercial spaces in and around Ramavaram. Whether it's cockroach control, termite
            treatment, or general pest control, we provide fast, safe, and affordable pest management with 100% customer
            satisfaction.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pest Control Services in Ramavaram:</h3>

          <ul>
            <li>🪳 Cockroach Control – Gel & spray-based treatments</li>
            <li>🐀 Rodent Control – Complete mouse and rat removal</li>
            <li>🛏️ Bed Bugs Treatment – Odorless and safe</li>
            <li>🦟 Mosquito Control – Indoor & outdoor fogging solutions</li>
            <li>🐜 General Pest Control – Ants, spiders, lizards & more</li>
            <li>🌱 Eco-Friendly Pest Control – Safe for kids and pets</li>
            <li>🏠 Termite Control in Ramavaram – Long-term protection for wood and walls</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Our Pest Control Service in Ramavaram?</h3>

          <ul>
            <li>✔️ Certified Professionals – Experienced in handling all pest types</li>
            <li>✔️ Safe & Effective Methods – Child and pet-friendly solutions</li>
            <li>✔️ Affordable Prices – No hidden costs, clear pest control service price in Ramavaram</li>
            <li>✔️ Quick Response – Same-day pest control service available</li>
            <li>✔️ Excellent Customer Reviews – Top-rated in Ramavaram, Chennai India</li>
            <li>✔️ Free Inspection & Quote – Honest pricing, instant contact</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 Serving Ramavaram and Nearby Locations:</h3>

          <ul>
            <li>Ramavaram, Chennai</li>
            <li>Surrounding residential areas</li>
            <li>Commercial establishments</li>
            <li>Educational institutions</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">🔍 We Help You Rank for:</h3>

          <ul>
            <li>Pest Control in Ramavaram Chennai</li>
            <li>Termite Control Ramavaram</li>
            <li>General Pest Control Services in Chennai</li>
            <li>Pest Control Price in Ramavaram</li>
            <li>Cockroach Control Services Ramavaram</li>
            <li>Pest Control Reviews Ramavaram</li>
            <li>Best Pest Control Service Near Me</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Contact Us Today for Pest Control in Ramavaram!</h3>
            <p>
              Protect your space with the most reliable control services in Ramavaram. Call us now and get a free
              inspection & the best price!
            </p>
            <p>📱 Call: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
