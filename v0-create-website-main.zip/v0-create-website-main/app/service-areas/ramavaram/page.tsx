import type { Metadata } from "next"
import { RamavaramPestControlClient } from "./RamavaramPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Ramavaram, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Ramavaram, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Ramavaram, pest services Ramavaram, cockroach control Ramavaram, termite treatment Ramavaram, bed bug control Ramavaram, mosquito control Ramavaram, rodent control Ramavaram, pest control services Ramavaram Chennai",
}

export default function RamavaramPage() {
  return <RamavaramPestControlClient />
}
