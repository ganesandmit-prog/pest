import type { Metadata } from "next"
import { PadiPestControlClient } from "./PadiPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Padi | Professional Pest Control Services",
  description:
    "Top-rated pest control services in Padi, Chennai. Expert solutions for homes, businesses & paddy fields. Affordable, eco-friendly pest management. Call now!",
  keywords:
    "pest control Padi, pest control services Padi, Padi pest control, pest management Padi, termite control Padi, cockroach control Padi, rodent control Padi, mosquito control Padi, eco-friendly pest control Padi, residential pest control Padi, commercial pest control Padi, paddy field pest control, tanaman padi, pengendalian hama",
}

export default function PadiPage() {
  return <PadiPestControlClient />
}
