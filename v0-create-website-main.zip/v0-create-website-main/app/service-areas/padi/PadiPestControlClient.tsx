"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PadiPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Padi",
              "description": "Professional pest control services in Padi, Chennai. We offer residential and commercial pest control, termite treatment, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/padi",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Padi, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Termite Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Padi?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Padi including general pest control, termite treatment, cockroach control, rodent control, mosquito management, and eco-friendly pest solutions for both residential and commercial properties."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Padi?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Padi start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Padi. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Padi?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Padi. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Padi, Chennai"
          description="Professional pest control solutions for homes, fields & businesses in Padi. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Padi – Trusted Pest Control Services
              </h2>
              <p className="text-gray-600 mb-4">
                Looking for top-rated pest control services in Padi? 🏡 Whether you're protecting your home, business,
                or tanaman padi (paddy fields), our professional team delivers powerful pest control solutions tailored
                just for you. Say goodbye to pests and hello to peace of mind!
              </p>
              <p className="text-gray-600 mb-4">
                We specialize in pest control, control services, and eco-friendly treatments for all types of properties
                — from city homes to farms facing pengendalian hama (pest management) issues. With us, Padi District
                enjoys cleaner, safer spaces!
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Specialized Pest Control Services in Padi</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>General Pest Control Services – Eradicate all pests with cutting-edge control techniques.</li>
                <li>
                  Tanaman Padi Pest Control – Shield your crops from pests like walang sangit and keong mas with expert
                  methods.
                </li>
                <li>Cockroach and Insect Control – Total removal from homes and kitchens.</li>
                <li>Rodent Control Services – Protect your building foundations from damage.</li>
                <li>Mosquito Management – Stay safe from mosquito-borne diseases.</li>
                <li>Termite Control – Defend your homes and walls from hidden threats.</li>
                <li>Eco-Friendly Solutions – Sustainable pest control for families and farmland.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Why We're #1 for Pest Control in Padi</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>District-Wide Services – We cover all of Padi District and nearby areas.</li>
                <li>Specialized Farm Protection – Advanced pest control for tanaman padi fields.</li>
                <li>Customized Control Services – Tailored solutions using the best practices in pengendalian hama.</li>
                <li>Affordable Pest Control Packages – Premium service without premium prices.</li>
                <li>Quick Response – Immediate action, from booking to pest removal.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Service Areas in and Around Padi</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Residential Apartments</li>
                <li>Commercial Properties</li>
                <li>Paddy Fields (Tanaman Padi)</li>
                <li>Industrial Zones</li>
                <li>Entire Padi District and nearby districts</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Contact the Best Pest Control Experts in Padi Today!</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
