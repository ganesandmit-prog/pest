import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Adambakkam | No.1 Quality Pest Control Chennai",
  description:
    "Looking for professional pest control in Adambakkam? No.1 Quality Pest Control offers affordable, effective, and safe pest control services in Adambakkam Chennai for homes, apartments, offices, shops, and commercial spaces.",
}

export default function AdambakkamPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Adambakkam"
        subtitle="Professional & Affordable Pest Control Services in Adambakkam Chennai"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Adambakkam</h2>
            <p className="mb-4">
              Looking for professional pest control in Adambakkam? At No.1 Quality Pest Control, we offer affordable,
              effective, and safe pest control services in Adambakkam Chennai for homes, apartments, offices, shops, and
              commercial spaces.
            </p>
            <p className="mb-4">
              Whether you're dealing with cockroaches, termites, rodents, or general pests, we're the trusted pest
              control service in Adambakkam to eliminate them at the best price.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Why Choose Our Pest Control Services in Adambakkam?
            </h2>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔</span>
                <span>
                  <strong>Expert Pest Control in Adambakkam</strong> – Advanced treatment for all pests.
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔</span>
                <span>
                  <strong>Certified Technicians</strong> – Safe and modern control services tailored for Chennai homes
                  and businesses.
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔</span>
                <span>
                  <strong>Eco-Friendly & Family Safe</strong> – Non-toxic and pet-friendly methods.
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔</span>
                <span>
                  <strong>Affordable Pricing</strong> – Quality pest control at the best price.
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✔</span>
                <span>
                  <strong>Guaranteed Satisfaction</strong> – 100% effective with follow-up support.
                </span>
              </li>
            </ul>
            <div className="mt-6 flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call Now:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
              <div className="flex items-center">
                <span className="font-bold mr-2">📲</span>
                <a href="https://wa.me/917558108600" className="text-light-green hover:underline">
                  WhatsApp Us for Quick Booking
                </a>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Our Pest Control Services in Adambakkam Chennai</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-xl font-bold text-dark-green mb-2">🪳 Cockroach Control Adambakkam</h3>
                <p>
                  We eliminate cockroach infestations from kitchens, washrooms & drains with advanced pest control
                  service.
                </p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-xl font-bold text-dark-green mb-2">🐭 Rodent Control Services</h3>
                <p>Get rid of rats and mice with our safe rodent control in Adambakkam using baits and traps.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-xl font-bold text-dark-green mb-2">🐛 Termite Control Adambakkam</h3>
                <p>Protect your home and furniture with expert termite treatment in Adambakkam Chennai.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-xl font-bold text-dark-green mb-2">🐜 Ant, Mosquito & General Pests</h3>
                <p>Complete pest control services in Adambakkam for ants, lizards, mosquitoes, and more.</p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Serving All Around Adambakkam & Chennai</h2>
            <p className="mb-4">We provide pest control in Adambakkam and nearby areas like:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Velachery</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Guindy</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Nanganallur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Madipakkam</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Pallavaram</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Saidapet</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Alandur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">T. Nagar</div>
            </div>
            <p className="mt-4">
              We are your local pest control experts offering quick, affordable, and reliable services.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Residential & Commercial Pest Control in Adambakkam
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-bold text-dark-green mb-2">Home Pest Control Services</h3>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-bold text-dark-green mb-2">Apartment & Villa Pest Management</h3>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-bold text-dark-green mb-2">Office & Shop Pest Control</h3>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="text-lg font-bold text-dark-green mb-2">Restaurant & Warehouse Pest Treatment</h3>
              </div>
            </div>
            <div className="mt-6 flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
              <div className="flex items-center">
                <span className="font-bold mr-2">💬</span>
                <a href="https://wa.me/917558108600" className="text-light-green hover:underline">
                  WhatsApp Us
                </a>
              </div>
            </div>
            <div className="mt-4">
              <p>
                <strong>📍 Location:</strong> 202 Broadway, Parrys, Chennai – 600001
              </p>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.6}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Book Now – Get the Best Pest Control Service in Adambakkam!
            </h2>
            <p className="mb-4">Want the best pest control in Adambakkam? We offer:</p>
            <ul className="list-none space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Guaranteed pest removal</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Safe treatments for your family</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>24x7 support and quick service</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Low-cost pest control packages</span>
              </li>
            </ul>
            <p className="font-bold">👉 Fill out our contact form and request a FREE quote today!</p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Adambakkam
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
