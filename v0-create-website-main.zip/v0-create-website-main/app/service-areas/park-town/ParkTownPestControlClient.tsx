"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function ParkTownPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Park Town",
              "description": "Professional pest control services in Park Town, Chennai. We offer residential and commercial pest control, cockroach control, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/park-town",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Park Town, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Cockroach Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Park Town?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Park Town including cockroach control, rodent control, mosquito treatment, general pest control, and eco-friendly solutions for both residential and commercial properties."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Park Town?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Park Town start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Park Town. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Park Town?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Park Town. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Park Town, Chennai"
          description="Professional pest control solutions for homes and businesses in Park Town. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Park Town – Trusted Experts for Safe and Swift Solutions
              </h2>
              <p className="text-gray-600 mb-4">
                Are pests causing trouble in your home or business in Park Town? Our pest control services in Park Town
                are specially designed to eliminate pests quickly, safely, and affordably. Whether it's cockroaches,
                termites, rodents, or mosquitoes, we've got the perfect solution for you!
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Park Town</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Cockroach Control – Complete eradication using modern techniques.</li>
                <li>Rodent Control – Keep rats and mice away from your property.</li>
                <li>Mosquito Treatment – Protect your family from dangerous diseases.</li>
                <li>General Pest Control Services – One-stop solution for all pests.</li>
                <li>Eco-Friendly Solutions – Safe for kids, pets, and the environment.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Why Choose Us for Pest Control in Park Town?</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Experienced Team – Trained technicians with expertise like Parkway Pest Services.</li>
                <li>Advanced Techniques – Using the latest methods seen in parks pest control companies.</li>
                <li>Fast and Reliable – Quick response with guaranteed results.</li>
                <li>Customer Reviews Matter – Highly rated with positive reviews from Park Town residents.</li>
                <li>Affordable Packages – Quality pest control without burning your pocket.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Serving Areas in and Around Park Town</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Apartments, Villas, and Independent Houses</li>
                <li>Offices, Schools, Restaurants, and Shops</li>
                <li>Hospitals, Clinics, and Industrial Spaces</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Contact Us Today for Pest Control in Park Town!</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
