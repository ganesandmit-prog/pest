import type { Metadata } from "next"
import { ParkTownPestControlClient } from "./ParkTownPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Park Town | Trusted Experts for Safe and Swift Solutions",
  description:
    "Are pests causing trouble? Our pest control services in Park Town are specially designed to eliminate pests quickly, safely, and affordably. Call us today!",
  keywords:
    "pest control Park Town, pest control services Park Town, Park Town pest control, cockroach control Park Town, rodent control Park Town, mosquito treatment Park Town, general pest control Park Town, eco-friendly pest control, pest control company Park Town, affordable pest control, pest control Chennai",
}

export default function ParkTownPage() {
  return <ParkTownPestControlClient />
}
