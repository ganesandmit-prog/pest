import type { Metadata } from "next"
import TiruverkadupestControlClient from "./TiruverkadupestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Tiruverkadu, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Tiruverkadu, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with 45+ years of experience.",
  keywords:
    "pest control Tiruverkadu, Tiruverkadu pest services, cockroach control Tiruverkadu, termite treatment Tiruverkadu, bed bug control Tiruverkadu, rodent control Tiruverkadu, mosquito control Tiruverkadu, pest management Tiruverkadu Chennai",
}

export default function TiruverkadupestControlPage() {
  return <TiruverkadupestControlClient />
}
