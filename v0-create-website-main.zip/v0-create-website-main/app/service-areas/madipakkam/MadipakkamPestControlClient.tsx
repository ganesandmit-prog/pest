"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function MadipakkamPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Madipakkam" subtitle="Safe, Affordable & Trusted Services" />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Are pests bothering your peace? Get the most reliable and affordable pest control services in
                  Madipakkam from No.1 Quality Pest Control – your trusted local pest experts in Chennai.
                </p>
                <p className="text-lg">
                  Whether you need cockroach control, termite treatment, or a complete pest control service in
                  Madipakkam Chennai, we've got you covered. We offer control services that are customized for your
                  home, office, apartment, or commercial space.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">💼 Our Madipakkam Pest Control Services Include:</h2>
                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control Services</li>
                  <li>🐜 Termite Control & Treatment</li>
                  <li>🐀 Rodent Control Services</li>
                  <li>🦟 Mosquito Pest Management</li>
                  <li>🛏️ Bed Bug Elimination</li>
                  <li>🕷 Spider, Ant, and Other Insect Control</li>
                  <li>🌿 Eco-Friendly and Organic Pest Solutions</li>
                </ul>
                <p>
                  We use safe, non-toxic, government-approved treatments to ensure the safety of your family and
                  environment.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Serving Madipakkam and Nearby Locations:</h2>
                <ul className="list-none space-y-2">
                  <li>Madipakkam Chennai</li>
                  <li>Nanganallur</li>
                  <li>Velachery</li>
                  <li>Pallikaranai</li>
                  <li>Keelkattalai</li>
                  <li>Adambakkam</li>
                  <li>Medavakkam</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">✅ Why Choose Us?</h2>
                <ul className="list-none space-y-2">
                  <li>Over 10+ years of experience in pest control service</li>
                  <li>Highly trained technicians</li>
                  <li>Fast and effective control service in Madipakkam</li>
                  <li>Affordable price with transparent quotes</li>
                  <li>Listed on Sulekha Chennai</li>
                  <li>Trusted by 1000+ customers</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">⭐ Customer Testimonials:</h2>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "Top-class pest control company in Madipakkam. Their cockroach treatment was very effective!"
                  <footer className="text-right">– Sathish, Madipakkam</footer>
                </blockquote>
                <blockquote className="italic border-l-4 border-light-green pl-4 py-2 my-4">
                  "The team arrived on time and did a thorough termite control job. Great service and fair price!"
                  <footer className="text-right">– Divya, Chennai</footer>
                </blockquote>

                <h2 className="text-2xl font-bold mt-8 mb-4">📞 Contact Us for Instant Booking!</h2>
                <ul className="list-none space-y-2">
                  <li>📍 Location: Madipakkam, Chennai, Tamil Nadu</li>
                  <li>
                    📞 Phone:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="https://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      https://www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Madipakkam</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Madipakkam" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Madipakkam. Contact
                      us today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
