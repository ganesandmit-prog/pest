import type { Metadata } from "next"
import MadipakkamPestControlClient from "./MadipakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Madipakkam | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Madipakkam, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Madipakkam, pest control services Madipakkam, cockroach control Madipakkam, termite control Madipakkam, rodent control Madipakkam, bed bug treatment Madipakkam, pest control Chennai, No.1 Quality Pest Control",
}

export default function MadipakkamPage() {
  return <MadipakkamPestControlClient />
}
