"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"
import ProcessSection from "@/components/process-section"

export default function GuduvancheriPestControlClient() {
  const [isFormSubmitted, setIsFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setIsFormSubmitted(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h2 className="text-3xl font-bold mb-6 text-primary">
          Best Pest Control in Guduvancheri, Chennai – Professional Pest Management
        </h2>
        <p className="mb-4">
          If you're looking for pest control services in Guduvancheri, Chennai, we offer efficient and eco-friendly pest
          control solutions to safeguard your home and business. Whether you're dealing with termites, cockroaches,
          ants, or any other pests, our expert team ensures a pest-free environment.
        </p>

        <h3 className="text-2xl font-semibold mt-8 mb-4 text-primary">
          Our Pest Control Services in Guduvancheri, Chennai:
        </h3>
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>🪳 Cockroach Control</li>
          <li>🐜 Termite Control</li>
          <li>🐀 Rodent Control</li>
          <li>🦟 Mosquito Control</li>
          <li>🌿 Eco-Friendly Pest Solutions</li>
          <li>🛏 Bed Bug Treatment</li>
          <li>🏢 Commercial Pest Control for offices and businesses</li>
        </ul>
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Why Choose Us for Pest Control in Guduvancheri, Chennai?
        </h3>
        <BenefitsSection
          benefits={[
            "Experienced Technicians – Trained and certified professionals for all pest issues",
            "Customized Solutions – Tailored treatments for residential, commercial, and industrial properties",
            "Safe & Eco-Friendly Methods – We prioritize non-toxic solutions for your family and pets",
            "Affordable & Timely – Competitive pricing with prompt service",
            "Guaranteed Results – 100% satisfaction with our pest control treatment",
          ]}
        />
      </motion.section>

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Areas We Serve in and Around Guduvancheri, Chennai:
        </h3>
        <ul className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <li className="bg-gray-100 p-3 rounded-lg text-center">Guduvancheri</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Singarathoppu</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Vandalur</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Tambaram</li>
          <li className="bg-gray-100 p-3 rounded-lg text-center">Chengalpattu</li>
        </ul>
      </motion.section>

      <ProcessSection />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="mb-12">
        <h3 className="text-2xl font-semibold mb-6 text-primary">
          Contact Us for Pest Control in Guduvancheri, Chennai:
        </h3>
        <div className="bg-gray-100 p-6 rounded-lg mb-8">
          <p className="mb-2">
            <strong>📱 Call:</strong> +91 7558108600
          </p>
          <p className="mb-2">
            <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
          </p>
          <p>
            <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-xl font-semibold mb-4 text-primary">Request a Free Quote</h4>
          <ContactForm onSubmitSuccess={handleFormSubmit} location="Guduvancheri" />
          {isFormSubmitted && (
            <p className="mt-4 text-green-600 font-medium">
              Thank you for your inquiry! Our team will contact you shortly with a free quote for pest control services
              in Guduvancheri.
            </p>
          )}
        </div>
      </motion.section>
    </div>
  )
}
