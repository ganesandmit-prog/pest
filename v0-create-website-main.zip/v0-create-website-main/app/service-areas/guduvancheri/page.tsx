import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import GuduvancheriPestControlClient from "./GuduvancheriPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Guduvancheri, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest management in Guduvancheri, Chennai. We offer efficient and eco-friendly pest control solutions to safeguard your home and business from all types of pests.",
  keywords:
    "pest control Guduvancheri, Guduvancheri pest services, cockroach control Guduvancheri, termite treatment Guduvancheri, rodent control Guduvancheri, mosquito control Guduvancheri, bed bug treatment Guduvancheri, commercial pest control Guduvancheri, Chennai pest control",
}

export default function GuduvancheriPage() {
  return (
    <main className="min-h-screen">
      <PageHeader
        title="Best Pest Control in Guduvancheri, Chennai"
        description="Professional Pest Management for homes and businesses"
      />
      <GuduvancheriPestControlClient />
    </main>
  )
}
