"use client"
import { Check, Shield } from "lucide-react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ServicesList from "@/components/services-list"
import ProcessSection from "@/components/process-section"
import BenefitsSection from "@/components/benefits-section"
import TestimonialsSection from "@/components/testimonials-section"
import ContactForm from "@/components/contact-form"
import FAQSection from "@/components/faq-section"
import CTA from "@/components/cta"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function TiruvallikeniPestControlClient() {
  return (
    <>
      <PageHeader
        title="Pest Control Services in Tiruvallikeni, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions in Tiruvallikeni"
        backgroundImage="https://images.unsplash.com/photo-1587162146766-e06b1189b907?q=80&w=2070"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <AnimatedSection animation="fadeIn">
                <h2 className="text-3xl font-bold mb-6 text-dark-green">
                  No.1 Quality Pest Control Services in Tiruvallikeni
                </h2>
                <p className="mb-4 text-gray-700">
                  Tiruvallikeni (also known as Triplicane), a historic neighborhood in Chennai, is known for its ancient
                  temples, cultural heritage, and proximity to Marina Beach. However, the area's high population
                  density, old buildings, and coastal climate make it particularly vulnerable to pest infestations
                  including cockroaches, termites, mosquitoes, and rodents.
                </p>
                <p className="mb-4 text-gray-700">
                  No.1 Quality Pest Control offers specialized pest management solutions for Tiruvallikeni residents and
                  businesses, addressing the unique challenges of this historic area. Our 45+ years of experience
                  ensures that your property remains pest-free while preserving the cultural and historical significance
                  of the neighborhood.
                </p>
                <p className="mb-6 text-gray-700">
                  Our eco-friendly pest control treatments are safe for families, pets, and the environment, making them
                  ideal for the densely populated residential areas of Tiruvallikeni. We provide comprehensive pest
                  management for homes, apartments, shops, restaurants, and religious institutions throughout the area.
                </p>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">
                    Common Pest Problems in Tiruvallikeni, Chennai
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Cockroach Infestations:</strong> Common in older buildings and food establishments due
                        to the area's high density
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Mosquito Problems:</strong> Prevalent due to proximity to Marina Beach and water bodies
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Termite Damage:</strong> Affects many historic wooden structures and buildings in the
                        area
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Rodent Issues:</strong> Common in residential areas and near food establishments
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Bed Bug Infestations:</strong> Affecting residential properties and lodging facilities
                      </span>
                    </li>
                  </ul>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.1}>
                <h3 className="text-2xl font-bold mb-4 text-dark-green">Our Pest Control Services in Tiruvallikeni</h3>
                <p className="mb-6 text-gray-700">
                  We offer comprehensive pest management solutions tailored to the specific needs of Tiruvallikeni
                  residents and businesses:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                  <div className="bg-white p-5 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2 text-dark-green">Residential Pest Control</h4>
                    <p className="text-sm text-gray-700">
                      Complete pest protection for homes and apartments in Tiruvallikeni, with special attention to
                      preserving historic properties and structures.
                    </p>
                  </div>
                  <div className="bg-white p-5 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2 text-dark-green">Commercial Pest Management</h4>
                    <p className="text-sm text-gray-700">
                      Specialized solutions for shops, restaurants, hotels, and religious institutions in the
                      Tiruvallikeni area, ensuring compliance with health regulations.
                    </p>
                  </div>
                  <div className="bg-white p-5 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2 text-dark-green">Termite Control & Treatment</h4>
                    <p className="text-sm text-gray-700">
                      Advanced termite protection for wooden structures and historic buildings, preventing damage to
                      cultural heritage properties.
                    </p>
                  </div>
                  <div className="bg-white p-5 rounded-lg shadow-md">
                    <h4 className="font-bold text-lg mb-2 text-dark-green">Mosquito Control Services</h4>
                    <p className="text-sm text-gray-700">
                      Effective mosquito management solutions addressing the coastal climate challenges of
                      Tiruvallikeni.
                    </p>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">
                    Why Tiruvallikeni Residents Choose Our Pest Control Services
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Shield className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Local Expertise:</strong> Our technicians understand the unique pest challenges of
                        Tiruvallikeni's historic neighborhood
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Shield className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Heritage-Friendly Treatments:</strong> Special care taken when treating historic
                        buildings and structures
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Shield className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>45+ Years Experience:</strong> Decades of pest control expertise in Chennai's oldest
                        neighborhoods
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Shield className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Eco-Friendly Solutions:</strong> Safe for families, pets, and the environment
                      </span>
                    </li>
                    <li className="flex items-start">
                      <Shield className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>
                        <strong>Affordable Pricing:</strong> Competitive rates with no compromise on quality
                      </span>
                    </li>
                  </ul>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">Areas We Serve in and around Tiruvallikeni</h3>
                  <p className="mb-4 text-gray-700">
                    Our pest control services cover all parts of Tiruvallikeni and nearby areas including:
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    <div className="bg-gray-50 p-3 rounded">Triplicane High Road</div>
                    <div className="bg-gray-50 p-3 rounded">Big Street</div>
                    <div className="bg-gray-50 p-3 rounded">Pycrofts Road</div>
                    <div className="bg-gray-50 p-3 rounded">Bells Road</div>
                    <div className="bg-gray-50 p-3 rounded">Triplicane Tank</div>
                    <div className="bg-gray-50 p-3 rounded">Ice House</div>
                    <div className="bg-gray-50 p-3 rounded">Marina Beach Road</div>
                    <div className="bg-gray-50 p-3 rounded">Chepauk</div>
                    <div className="bg-gray-50 p-3 rounded">Surrounding localities</div>
                  </div>
                </div>
              </AnimatedSection>

              <Tabs defaultValue="services" className="w-full mb-8">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="services">Services</TabsTrigger>
                  <TabsTrigger value="process">Our Process</TabsTrigger>
                  <TabsTrigger value="benefits">Benefits</TabsTrigger>
                  <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
                </TabsList>
                <TabsContent value="services" className="mt-6">
                  <ServicesList />
                </TabsContent>
                <TabsContent value="process" className="mt-6">
                  <ProcessSection />
                </TabsContent>
                <TabsContent value="benefits" className="mt-6">
                  <BenefitsSection />
                </TabsContent>
                <TabsContent value="testimonials" className="mt-6">
                  <TestimonialsSection />
                </TabsContent>
              </Tabs>

              <AnimatedSection animation="fadeIn" delay={0.3}>
                <div className="mb-8">
                  <h3 className="text-2xl font-bold mb-6 text-dark-green">
                    Recent Pest Control Projects in Tiruvallikeni
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white rounded-lg shadow-md overflow-hidden">
                      <div className="h-48 bg-gray-200"></div>
                      <div className="p-5">
                        <h4 className="font-bold text-lg mb-2 text-dark-green">Heritage Building Termite Treatment</h4>
                        <p className="text-sm text-gray-700">
                          Complete termite protection for a 100-year-old wooden structure in Triplicane High Road,
                          preserving its historical integrity while eliminating termite colonies.
                        </p>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg shadow-md overflow-hidden">
                      <div className="h-48 bg-gray-200"></div>
                      <div className="p-5">
                        <h4 className="font-bold text-lg mb-2 text-dark-green">Restaurant Pest Management Program</h4>
                        <p className="text-sm text-gray-700">
                          Comprehensive pest control solution for a popular restaurant near Marina Beach, ensuring
                          compliance with food safety regulations and maintaining a pest-free environment.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </AnimatedSection>

              <FAQSection
                title="Frequently Asked Questions About Pest Control in Tiruvallikeni"
                subtitle="Get answers to common questions about our pest control services in Tiruvallikeni"
                faqs={[
                  {
                    question: "Do you offer specialized treatments for historic buildings in Tiruvallikeni?",
                    answer:
                      "Yes, we provide specialized pest control treatments for historic buildings in Tiruvallikeni that preserve the structural integrity and cultural value while effectively eliminating pests. Our technicians are trained in heritage-friendly pest management techniques.",
                  },
                  {
                    question: "How often should I schedule pest control services for my home in Tiruvallikeni?",
                    answer:
                      "For residential properties in Tiruvallikeni, we typically recommend quarterly treatments due to the area's high humidity and pest pressure. However, this can vary based on your specific situation, property type, and pest history.",
                  },
                  {
                    question: "Are your pest control treatments safe for use around religious institutions?",
                    answer:
                      "Absolutely. We use eco-friendly, low-toxicity treatments that are safe for use around religious institutions, ensuring respect for sacred spaces while effectively managing pest issues. Our treatments are odorless and leave no visible residue.",
                  },
                  {
                    question: "How do you handle cockroach infestations in older buildings in Tiruvallikeni?",
                    answer:
                      "For older buildings in Tiruvallikeni, we implement a comprehensive approach to cockroach control that includes targeted gel baiting, crack and crevice treatment, and IGRs (Insect Growth Regulators) to break the breeding cycle, along with practical advice on sanitation and exclusion methods.",
                  },
                  {
                    question: "Do you provide emergency pest control services in Tiruvallikeni?",
                    answer:
                      "Yes, we offer emergency pest control services throughout Tiruvallikeni with same-day or next-day appointments available for urgent situations. Contact our customer service team for immediate assistance.",
                  },
                ]}
              />

              <CTA
                title="Professional Pest Control Services in Tiruvallikeni"
                description="Contact us today for effective and affordable pest management solutions tailored to Tiruvallikeni's unique needs."
                buttonText="Contact Us Now"
                buttonLink="/contact-us"
                phoneNumber="9876543210"
              />
            </div>

            <div className="lg:col-span-1">
              <AnimatedSection animation="slideRight">
                <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-8">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">Contact Us</h3>
                  <ContactForm location="Tiruvallikeni" />
                </div>

                <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-8">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">Our Service Areas</h3>
                  <p className="mb-4 text-gray-700">We provide pest control services throughout Chennai, including:</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <a href="/service-areas/adyar" className="text-dark-green hover:text-light-green">
                      Adyar
                    </a>
                    <a href="/service-areas/anna-nagar" className="text-dark-green hover:text-light-green">
                      Anna Nagar
                    </a>
                    <a href="/service-areas/besant-nagar" className="text-dark-green hover:text-light-green">
                      Besant Nagar
                    </a>
                    <a href="/service-areas/guindy" className="text-dark-green hover:text-light-green">
                      Guindy
                    </a>
                    <a href="/service-areas/mylapore" className="text-dark-green hover:text-light-green">
                      Mylapore
                    </a>
                    <a href="/service-areas/t-nagar" className="text-dark-green hover:text-light-green">
                      T. Nagar
                    </a>
                    <a href="/service-areas/velachery" className="text-dark-green hover:text-light-green">
                      Velachery
                    </a>
                    <a href="/service-areas" className="text-dark-green hover:text-light-green font-semibold">
                      View All →
                    </a>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4 text-dark-green">Why Choose Us?</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>45+ years of pest control experience</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>Eco-friendly and safe treatments</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>Trained and certified technicians</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>Customized pest management plans</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-2 mt-1" />
                      <span>Satisfaction guaranteed</span>
                    </li>
                  </ul>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default TiruvallikeniPestControlClient
