import type { Metadata } from "next"
import TiruvallikeniPestControlClient from "./TiruvallikeniPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Tiruvallikeni, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Tiruvallikeni, Chennai. Effective solutions for cockroaches, termites, mosquitoes, rodents & more. 45+ years of experience.",
  keywords:
    "pest control Tiruvallikeni, Triplicane pest control, termite control Tiruvallikeni, cockroach control Tiruvallikeni, mosquito control Tiruvallikeni, rodent control Tiruvallikeni, bed bug control Tiruvallikeni, pest management Chennai, pest control services Tiruvallikeni",
}

export default function TiruvallikeniPestControlPage() {
  return <TiruvallikeniPestControlClient />
}
