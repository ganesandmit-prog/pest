"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function PulianthopePestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Pulianthope, Chennai"
        description="Professional & affordable pest control services in Pulianthope. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            🦟 Best Pest Control in Pulianthope – Affordable & Trusted Services
          </h2>

          <p>
            Looking for professional pest control in Pulianthope, Chennai? Whether you're dealing with mosquitoes,
            termites, or general pests, our team delivers safe, effective, and eco-friendly pest solutions at the best
            prices in the market.
          </p>

          <p>
            We're rated highly across platforms like Sulekha, trusted by hundreds of homes and businesses for reliable,
            long-term pest management.
          </p>

          <h3 className="text-2xl font-bold text-primary">🐜 Our Pulianthope Pest Control Services Include:</h3>

          <ul>
            <li>🦟 Mosquito Control – Safe fogging services for home, offices & outdoors</li>
            <li>🪳 Cockroach Removal – Targeted gel and spray treatments</li>
            <li>🐜 Termite Treatment – Advanced techniques to protect wood and structures</li>
            <li>🛏️ Bed Bug Control – Fast elimination with minimal disruption</li>
            <li>🌿 Organic Pest Management – For families that prefer chemical-free care</li>
            <li>🧼 Cleaning & Disinfection – Post-treatment deep cleaning solutions</li>
            <li>📦 Customized Packages – Get free quotes tailored to your needs</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">💡 Why Choose Us for Pest Control in Pulianthope?</h3>

          <ul>
            <li>✔️ Experienced Technicians – Skilled in all pest treatment methods</li>
            <li>✔️ Eco-Friendly Treatments – Organic options for homes with children and pets</li>
            <li>✔️ Affordable Pricing – Transparent quotes with no hidden charges</li>
            <li>✔️ Fast Response – Service available throughout Pulianthope and nearby areas</li>
            <li>✔️ Sulekha Verified Company – 100% customer satisfaction</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">📍 Serving Locations:</h3>

          <ul>
            <li>Pulianthope</li>
            <li>Choolai, Washermanpet, Vyasarpadi</li>
            <li>Nearby residential colonies and commercial buildings</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Call Now for Free Quote:</h3>
            <p>📱 Phone: +91 7558108600</p>
            <p>📧 Email: no1qualitypestcontrol@gmail.com</p>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
