import type { Metadata } from "next"
import { PulianthopePestControlClient } from "./PulianthopePestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Pulianthope, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Pulianthope, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Pulianthope, pest services Pulianthope, cockroach control Pulianthope, termite treatment Pulianthope, bed bug control Pulianthope, mosquito control Pulianthope, rodent control Pulianthope, pest control services Pulianthope Chennai",
}

export default function PulianthopePage() {
  return <PulianthopePestControlClient />
}
