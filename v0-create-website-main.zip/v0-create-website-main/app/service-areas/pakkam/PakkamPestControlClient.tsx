"use client"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"

export function PakkamPestControlClient() {
  const [showContact, setShowContact] = useState(false)

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control Services in Pakkam",
              "description": "Professional pest control services in Pakkam, Chennai. We offer residential and commercial pest control, termite treatment, and more.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pakkam",
              "logo": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://twitter.com/no1qualitypest",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway Parrys",
                "addressLocality": "Chennai",
                "addressRegion": "Tamil Nadu",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 13.0827,
                "longitude": 80.2707
              },
              "telephone": "+917558108600",
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                  ],
                  "opens": "00:00",
                  "closes": "23:59"
                }
              ],
              "areaServed": {
                "@type": "City",
                "name": "Pakkam, Chennai"
              },
              "priceRange": "₹₹",
              "serviceType": ["Pest Control", "Termite Control", "Rodent Control", "Mosquito Control"]
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What pest control services do you offer in Pakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer comprehensive pest control services in Pakkam including general pest control, rodent treatment, bee and wasp removal, mosquito control, termite control, and eco-friendly urban pest solutions for both residential and commercial properties."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How much does pest control cost in Pakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our pest control services in Pakkam start from ₹1000, depending on the type of service, area size, and infestation level. We offer transparent pricing with no hidden charges and provide free quotes before beginning any work."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are your pest control methods safe for children and pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, we use eco-friendly and child-safe pest control methods in Pakkam. Our technicians are trained to use products that are effective against pests while being safe for your family, pets, and the environment."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How quickly can you respond to pest emergencies in Pakkam?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We offer same-day service for pest emergencies in Pakkam. Our team is available 24/7, and we strive to respond to all inquiries within 30 minutes to provide quick relief from pest problems."
                  }
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <FadeIn>
        <PageHeader
          title="Pest Control Services in Pakkam, Chennai"
          description="Professional pest control solutions for homes, businesses & industries in Pakkam. 45+ years of experience in eliminating pests safely and effectively."
          image="/images/thiruvottiyur-map.png"
          buttonText="Contact Us"
          buttonAction={() => setShowContact(true)}
        />
      </FadeIn>

      <div className="container mx-auto px-4 py-12">
        <FadeInStagger>
          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Best Pest Control in Pakkam – Trusted Urban Pest Control Experts
              </h2>
              <p className="text-gray-600 mb-4">
                Are you searching for reliable pest control services in Pakkam? 🏠 Look no further! Our expert pest
                control company delivers top-class treatment to homes, businesses, and industries across Chennai, Tamil
                Nadu, and nearby districts. 🏙️
              </p>
              <p className="text-gray-600 mb-4">
                We specialize in urban pest control, using modern methods and eco-friendly solutions to make your spaces
                pest-free — the right way, every time!
              </p>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Pest Control Services in Pakkam</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>General Pest Control Services – From cockroaches to ants, we control them all!</li>
                <li>Rodent and Mice Treatment – Save your property from gnawing damage.</li>
                <li>Bee and Wasp Removal Services – Safe and expert removal services.</li>
                <li>Mosquito Control Treatment – Protect your family from mosquito-borne diseases.</li>
                <li>Termite Control Services – Advanced treatment for walls, foundations, and wooden furniture.</li>
                <li>Eco-Friendly Urban Pest Control – Natural and safe pest management for your loved ones.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Why Choose Our Pest Control Company in Pakkam?</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Certified Pest Control Experts – Professionally trained technicians with years of experience.</li>
                <li>Complete Control Services – Customized plans for homes, offices, and industries.</li>
                <li>Affordable Pest Control Packages – Premium quality at competitive prices.</li>
                <li>Urban Pest Specialists – We know how to handle city-specific pests in Pakkam and Chennai.</li>
                <li>Quick Response – Immediate bookings, inspections, and treatments.</li>
              </ul>
            </div>
          </FadeIn>

          <FadeIn>
            <div className="bg-white rounded-lg shadow-md p-6 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Areas We Serve</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Homes & Apartments in Pakkam</li>
                <li>Offices, Shops & Commercial Spaces</li>
                <li>Industrial and Warehouse Facilities</li>
                <li>Urban Residences in Chennai and Tamil Nadu</li>
              </ul>
            </div>
          </FadeIn>
        </FadeInStagger>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Contact the Best Pest Control Services in Pakkam</h2>
          <ContactForm />
        </div>
      </div>
    </>
  )
}
