import type { Metadata } from "next"
import { PakkamPestControlClient } from "./PakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pakkam | Urban Pest Control Experts in Chennai",
  description:
    "Top-rated pest control services in Pakkam, Chennai. Expert pest control company offering eco-friendly control services for homes, offices, and industries. Call us today!",
  keywords:
    "pest control Pakkam, pest control services Pakkam, Pakkam pest control, urban pest control, termite control Pakkam, cockroach control Pakkam, rodent control Pakkam, mosquito control Pakkam, eco-friendly pest control Pakkam, residential pest control Pakkam, commercial pest control Pakkam, industrial pest control, pest control company Pakkam, pest control Chennai",
}

export default function PakkamPage() {
  return <PakkamPestControlClient />
}
