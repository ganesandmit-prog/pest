"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function StThomasMountPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in St. Thomas Mount, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Trusted Pest Control in St. Thomas Mount, Chennai – Professional & Effective Pest Control Services
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for reliable pest control services in St. Thomas Mount, Chennai? You're in the right place.
                  Our expert team provides end-to-end pest control solutions to protect your home or office from
                  cockroaches, termites, bed bugs, rodents, and more. Whether you need general pest control or targeted
                  treatments, we deliver eco-friendly, fast, and affordable services in and around St. Thomas Mount,
                  Chennai.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  🐜 Our Pest Control Services in St. Thomas Mount Include:
                </h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control (Gel & Spray Treatment)</li>
                  <li>🛏️ Bed Bugs Treatment</li>
                  <li>🐜 General Pest Control</li>
                  <li>🦟 Mosquito Control</li>
                  <li>🐀 Rodent Control</li>
                  <li>🌿 Eco-Friendly & Child-Safe Pest Solutions</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  💡 Why Choose Our Pest Control in St. Thomas Mount, Chennai?
                </h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Experienced Pest Control Professionals – Trained and certified experts.</li>
                  <li>✔️ Targeted Pest Removal – Specialized in both residential and commercial spaces.</li>
                  <li>✔️ Advanced & Safe Treatments – Odor-free and environmentally friendly.</li>
                  <li>✔️ Affordable Pest Control Rates – No hidden charges, best pricing in Chennai.</li>
                  <li>✔️ Trusted by Locals in St. Thomas Mount – Excellent client reviews and repeat customers.</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Serving St. Thomas Mount and Nearby Areas:</h2>

                <ul className="list-none space-y-2">
                  <li>St. Thomas Mount, Chennai</li>
                  <li>Alandur</li>
                  <li>Guindy</li>
                  <li>Adambakkam</li>
                  <li>Nanganallur</li>
                  <li>Nearby residential and commercial spaces</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">
                    📞 Contact Us for Pest Control in St. Thomas Mount, Chennai!
                  </h3>
                  <p>Don't wait for pests to take over — call the #1 Pest Control Service in St. Thomas Mount today!</p>
                  <p className="mt-4">
                    📱 Call: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
