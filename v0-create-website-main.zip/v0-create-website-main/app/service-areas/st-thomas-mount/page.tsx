import type { Metadata } from "next"
import { StThomasMountPestControlClient } from "./StThomasMountPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in St. Thomas Mount, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in St. Thomas Mount, Chennai. We offer cockroach, termite, bed bug, and mosquito control with eco-friendly solutions. Call now!",
  keywords:
    "pest control St. Thomas Mount, St. Thomas Mount pest control services, pest control company Chennai, eco-friendly pest control St. Thomas Mount, affordable pest control",
}

export default function StThomasMountPage() {
  return <StThomasMountPestControlClient />
}
