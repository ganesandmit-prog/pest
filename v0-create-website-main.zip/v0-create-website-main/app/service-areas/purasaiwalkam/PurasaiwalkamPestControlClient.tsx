"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ServicesList } from "@/components/services-list"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { motion } from "framer-motion"
import { fadeIn } from "@/components/framer-animations"

export function PurasaiwalkamPestControlClient() {
  const [isContactOpen, setIsContactOpen] = useState(false)

  return (
    <div className="relative">
      <PageHeader
        title="Pest Control Services in Purasaiwalkam, Chennai"
        description="Professional & affordable pest control services in Purasaiwalkam. We offer safe, effective solutions for all pest problems."
      />

      <motion.section initial="hidden" animate="visible" variants={fadeIn} className="container mx-auto px-4 py-12">
        <div className="prose prose-lg mx-auto max-w-4xl">
          <h2 className="text-center text-3xl font-bold text-primary">
            🐜 Pest Control in Purasaiwalkam – Safe & Affordable Services
          </h2>

          <p>
            Say goodbye to pests in Purasaiwalkam, Chennai with our expert pest control services! Whether you need
            general pest control, termite treatment, or cockroach removal, we deliver fast, affordable, and eco-friendly
            solutions trusted by 1000+ clients and Sulekha verified.
          </p>

          <h3 className="text-2xl font-bold text-primary">🧼 Our Services in Purasaiwalkam:</h3>

          <ul>
            <li>🪳 Cockroach & Ant Control</li>
            <li>🦟 Mosquito Fogging & Larvicide Spraying</li>
            <li>🐜 Termite Prevention & Wood Borer Treatment</li>
            <li>🛏️ Bed Bug Eradication</li>
            <li>🧼 Sanitization & Cleaning Services</li>
            <li>🏢 Residential & Commercial Pest Control</li>
          </ul>

          <h3 className="text-2xl font-bold text-primary">✔️ Why Choose Us:</h3>

          <ul>
            <li>✅ Trained Experts</li>
            <li>✅ Same-Day Service in Purasaiwalkam & Chennai</li>
            <li>✅ Perfect Pest Control Solutions for Homes</li>
            <li>✅ Affordable, Transparent Pricing</li>
            <li>✅ Eco-Safe Chemicals</li>
          </ul>

          <div className="mt-8 text-center">
            <h3 className="text-2xl font-bold text-primary">📞 Call Now: +91 7558108600</h3>
            <p>🌐 Website: www.no1qualitypestcontrol.com</p>
          </div>

          <div className="mt-8">
            <h3 className="text-2xl font-bold text-primary">🔍 SEO Keywords:</h3>
            <p>One Word: control, services, company, sulekha, cleaning</p>
            <p>Two Words: pest control, control services, purasawalkam chennai</p>
            <p>Three Words: pest control services, perfect pest control</p>
          </div>
        </div>
      </motion.section>

      <ServicesList />
      <ProcessSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ContactForm isOpen={isContactOpen} setIsOpen={setIsContactOpen} />
      <FloatingActionButton setIsContactOpen={setIsContactOpen} />
    </div>
  )
}
