import type { Metadata } from "next"
import { PurasaiwalkamPestControlClient } from "./PurasaiwalkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Purasaiwalkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Purasaiwalkam, Chennai. We offer safe, effective, and affordable solutions for all types of pest problems.",
  keywords:
    "pest control Purasaiwalkam, pest services Purasaiwalkam, cockroach control Purasaiwalkam, termite treatment Purasaiwalkam, bed bug control Purasaiwalkam, mosquito control Purasaiwalkam, rodent control Purasaiwalkam, pest control services Purasaiwalkam Chennai",
}

export default function PurasaiwalkamPage() {
  return <PurasaiwalkamPestControlClient />
}
