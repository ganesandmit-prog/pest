import type { Metadata } from "next"
import MathurPestControlClient from "./MathurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Mathur | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Mathur, Uttar Pradesh. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Mathur, pest control services Mathur, cockroach control Mathur, termite control Mathur, rodent control Mathur, bed bug treatment Mathur, pest control Uttar Pradesh, No.1 Quality Pest Control",
}

export default function MathurPage() {
  return <MathurPestControlClient />
}
