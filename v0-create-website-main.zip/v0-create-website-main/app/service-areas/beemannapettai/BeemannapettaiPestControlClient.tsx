"use client"

import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"
import BenefitsSection from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { AnimatePresence } from "framer-motion"
import { FadeIn } from "@/components/framer-animations"

export default function BeemannapettaiPestControlClient() {
  return (
    <AnimatePresence>
      <div className="flex flex-col min-h-screen">
        <PageHeader
          title="Pest Control Services in Beemannapettai"
          subtitle="Professional & Affordable Pest Management Solutions"
        />

        <main className="flex-grow">
          <FadeIn>
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-8">Top-Rated Pest Control in Beemannapettai</h2>
                  <div className="prose max-w-none">
                    <p>
                      Looking for reliable pest control services in Beemannapettai, Chennai? We are your go-to pest
                      control company offering premium-quality, eco-friendly, and affordable pest solutions for both
                      residential and business needs.
                    </p>
                    <p>
                      Whether it's general pest control, cockroach treatment, or termite control, we bring fast and
                      lasting solutions to protect your space.
                    </p>
                    <h3>Our Beemannapettai Pest Management Services Include:</h3>
                    <ul>
                      <li>General Pest Control – Cockroaches, Ants, Spiders, Lizards</li>
                      <li>Termite Control Services – Pre/Post Construction Treatments</li>
                      <li>Rodent Control – Mice & Rats in Homes & Offices</li>
                      <li>Commercial Pest Solutions – Shops, Restaurants, Schools</li>
                      <li>Pest Management for Businesses – Long-Term Contracts & AMC</li>
                      <li>Control Services – Eco-Safe, Certified Chemicals</li>
                      <li>Pest Solutions for Homes – Safe for Children & Pets</li>
                    </ul>
                    <h3>Why We're the Best in Beemannapettai:</h3>
                    <ul>
                      <li>Trusted by 100000+ Happy Clients Across Chennai</li>
                      <li>Featured in Business Bureau Listings</li>
                      <li>Experienced Pest Control Technicians</li>
                      <li>Same-Day Service & Instant Results</li>
                      <li>Affordable Rates with No Hidden Costs</li>
                      <li>100% Quality Assurance</li>
                    </ul>
                    <h3>Areas We Serve:</h3>
                    <ul>
                      <li>Beemannapettai</li>
                      <li>Triplicane</li>
                      <li>Mylapore</li>
                      <li>Royapettah</li>
                      <li>Egmore</li>
                      <li>Marina Area</li>
                      <li>Nearby Central Chennai Localities</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>

          <BenefitsSection
            title="Benefits of Our Pest Control in Beemannapettai"
            benefits={[
              {
                title: "Eco-Friendly Solutions",
                description:
                  "We use environmentally safe products that are effective against pests but gentle on the environment.",
                icon: "Leaf",
              },
              {
                title: "Experienced Technicians",
                description:
                  "Our team consists of highly trained professionals with years of experience in pest control.",
                icon: "Shield",
              },
              {
                title: "Customized Treatments",
                description:
                  "We provide tailored pest control solutions based on your specific needs and pest problems.",
                icon: "Settings",
              },
              {
                title: "Affordable Pricing",
                description: "Get high-quality pest control services at competitive prices with no hidden charges.",
                icon: "DollarSign",
              },
              {
                title: "Fast Response",
                description: "We offer quick service with same-day appointments available for urgent pest issues.",
                icon: "Clock",
              },
              {
                title: "Long-lasting Results",
                description: "Our treatments provide effective and long-term protection against pest infestations.",
                icon: "Shield",
              },
            ]}
          />

          <ProcessSection
            title="Our Pest Control Process in Beemannapettai"
            steps={[
              {
                title: "Inspection",
                description:
                  "Our experts thoroughly inspect your property to identify pest issues and infestation sources.",
              },
              {
                title: "Customized Plan",
                description:
                  "We develop a tailored treatment plan based on the type of pests and extent of infestation.",
              },
              {
                title: "Treatment",
                description:
                  "Our technicians apply effective and safe treatments to eliminate pests from your property.",
              },
              {
                title: "Prevention",
                description: "We implement preventive measures to keep pests from returning to your property.",
              },
              {
                title: "Follow-up",
                description: "We conduct follow-up visits to ensure the effectiveness of our pest control treatments.",
              },
            ]}
          />

          <FadeIn>
            <section className="py-12 md:py-16 bg-gray-50">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Beemannapettai</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="prose max-w-none">
                      <p>
                        Ready to get rid of pests in your Beemannapettai home or business? Contact No.1 Quality Pest
                        Control today for a free inspection and quote. Our team of experienced professionals is ready to
                        help you with all your pest control needs.
                      </p>
                      <div className="mt-6">
                        <h3>Contact Information:</h3>
                        <p>
                          <strong>Phone:</strong> +91 7558108600
                          <br />
                          <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                          <br />
                          <strong>Address:</strong> 202 Broadway Parrys, Chennai, Tamil Nadu 600108
                          <br />
                          <strong>Working Hours:</strong> Monday to Sunday, 8:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <ContactForm />
                  </div>
                </div>
              </div>
            </section>
          </FadeIn>
        </main>
      </div>
    </AnimatePresence>
  )
}
