import type { Metadata } from "next"
import BeemannapettaiPestControlClient from "./BeemannapettaiPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Beemannapettai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Beemannapettai, Chennai. Safe, affordable, and effective solutions for all pest problems. Call us today for a free inspection!",
  keywords:
    "pest control Beemannapettai, pest control services Beemannapettai, Beemannapettai pest control, cockroach control Beemannapettai, termite control Beemannapettai, bed bug control Beemannapettai, rodent control Beemannapettai",
}

export default function BeemannapettaiPestControl() {
  return <BeemannapettaiPestControlClient />
}
