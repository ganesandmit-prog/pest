import KovurPestControlClient from "./KovurPestControlClient"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Pest Control Services in Kovur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Kovur, Chennai. We offer organic and eco-friendly solutions for cockroach, termite, mosquito, and rodent control. Contact us today!",
  keywords:
    "pest control Kovur, organic pest control Kovur, termite control Kovur, cockroach control Kovur, mosquito control Kovur, rodent control Kovur, bed bug treatment Kovur, pest control services Kovur Chennai, affordable pest control Kovur",
}

export default function KovurPage() {
  return <KovurPestControlClient />
}
