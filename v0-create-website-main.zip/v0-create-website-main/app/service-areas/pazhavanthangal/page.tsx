import type { Metadata } from "next"
import { PazhavanthangalPestControlClient } from "./PazhavanthangalPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Pazhavanthangal, Chennai – Trusted Pest Control Services",
  description:
    "Looking for expert pest control services in Pazhavanthangal, Chennai? Our professional team offers the best control services to keep your home and office free from harmful pests.",
}

export default function PazhavanthangalPage() {
  return <PazhavanthangalPestControlClient />
}
