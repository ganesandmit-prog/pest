"use client"
import Image from "next/image"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"

export function PazhavanthangalPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Best Pest Control in Pazhavanthangal, Chennai – Trusted Pest Control Services</title>
        <meta
          name="description"
          content="Looking for expert pest control services in Pazhavanthangal, Chennai? Our professional team offers the best control services to keep your home and office free from harmful pests."
        />
        <meta
          name="keywords"
          content="pest control Pazhavanthangal, cockroach control, termites treatment, rodent control, eco-friendly pest control, professional cleaning"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/pazhavanthangal" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Pazhavanthangal",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/pazhavanthangal",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Parrys",
                "addressRegion": "Chennai",
                "postalCode": "600001",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 12.9975,
                "longitude": 80.1887
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹"
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Pest Control Services in Pazhavanthangal"
        description="Professional & Affordable Pest Control Solutions"
      />

      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Best Pest Control in Pazhavanthangal, Chennai – Trusted Pest Control Services
            </h2>
            <p className="mb-4">
              Looking for expert pest control services in Pazhavanthangal, Chennai? Our professional team offers the
              best control services to keep your home and office free from harmful pests. Whether you need cockroach
              control, termites treatment, or comprehensive pest management, we deliver top-quality solutions tailored
              for Pazhavanthangal residents.
            </p>
            <div className="bg-amber-100 p-4 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-2">🐜 Our Pest Control Services in Pazhavanthangal:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>🐞 Cockroach Control</li>
                <li>🐜 General Pest Control & Pests Control</li>
                <li>🐀 Rodent & Rat Control</li>
                <li>🐛 Termites Treatment & Prevention</li>
                <li>🧹 Professional Cleaning & Sanitization</li>
                <li>🌱 Eco-Friendly Pest Control Options</li>
              </ul>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Pest Control Service in Pazhavanthangal"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Why Choose Our Pest Control Company in Pazhavanthangal?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Experienced Professionals</h3>
              <p>Skilled technicians offering the most effective control services.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Reliable Pest Control</h3>
              <p>Fast, thorough, and guaranteed results.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Affordable Pricing</h3>
              <p>Transparent quotes with no hidden fees.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Eco-Friendly Treatment</h3>
              <p>Safe for your family and pets.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-3">✔️ Trusted in Chennai</h3>
              <p>Highly recommended by customers across Pazhavanthangal and greater Chennai.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Pazhavanthangal</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Chennai</h3>
          </div>
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <h3 className="font-semibold">Nearby Areas</h3>
          </div>
        </div>
      </section>

      <ProcessSection />
      <ServicesList />
      <BenefitsSection />
      <TestimonialsSection />

      <section className="container mx-auto px-4 py-12">
        <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold mb-4 text-center">Contact Us for Pest Control in Pazhavanthangal Today!</h2>
          <p className="text-center mb-6">
            Don't let pests disrupt your peace of mind. Call our experts now for a free quote on the best pest control
            services in Pazhavanthangal, Chennai.
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📱</span>
              <span>Phone: +91 7558108600</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">📧</span>
              <span>Email: no1qualitypestcontrol@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-600 text-xl">🌐</span>
              <span>Website: www.no1qualitypestcontrol.com</span>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  )
}
