"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KolathurPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader
        title="Best Pest Control in Kolathur, Chennai"
        subtitle="Reliable & Affordable Pest Control Services"
      />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are pests disturbing your peace in Kolathur? Look no further! We offer professional pest control
                services in Kolathur, Chennai, providing effective and eco-friendly solutions for general pest control
                and more. Whether it's cockroach control, termites, rodents, or bed bugs, our control services are
                tailored to meet your needs, ensuring a pest-free environment for your home or office.
              </p>
              <p className="text-lg mb-6">
                With a reputation built on trust, we are the top-rated pest control company in Chennai, delivering fast,
                reliable, and affordable pest management solutions.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">🛠️ Our Pest Control Services in Kolathur:</h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Effective treatment for kitchens and bathrooms
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Control</strong> – Protect your property from wood damage
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Stay protected from diseases
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent & Rat Control</strong> – Safe and humane rodent removal
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Treatment</strong> – Complete eradication for peaceful sleep
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest Control</strong> – For all pest problems in and around your home
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧹</span>
                    <span>
                      <strong>Cleaning Services</strong> – Post-treatment sanitation for a clean space
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Us for Pest Control in Kolathur?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Affordable and Transparent Pricing – No Hidden Fees</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Licensed & Experienced Pest Control Technicians</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Eco-Friendly and Safe Solutions for Your Family & Pets</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Fast, Reliable, and Effective Control Services</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Trusted by Homeowners and Businesses in Kolathur Chennai</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>5-Star Reviews from Satisfied Customers</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 We Serve Kolathur and Nearby Areas:</h2>
                <p className="mb-4">Perambur | Madhavaram | Korattur | Annanagar | Padi | Villivakkam</p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">📞 Contact the Leading Pest Control Company in Kolathur</h2>
                <p className="mb-2">
                  📱 Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Website: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
                <p>📍 Location: Kolathur, Chennai Tamil Nadu, India</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🏡 Whether you need general pest control or cockroach removal, our expert team ensures quick and
                  effective solutions. Trust us for all your pest control needs in Kolathur Chennai.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Kolathur</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
