"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function MGRNagarPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Pest Control in MGR Nagar"
        subtitle="Safe & Trusted Pest Control Services in Chennai, Tamil Nadu"
      />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Are you tired of unwanted pests in your home or office? 🏠🐀 Don't worry – No.1 Quality Pest Control
                  is here to rescue you with reliable and effective pest control services in MGR Nagar, Chennai! 💪
                </p>
                <p className="text-lg">
                  We are a trusted name in pest control Chennai, offering customized solutions that eliminate pests and
                  prevent them from coming back! 🚫🐛
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🌟 Why Choose Us in MGR Nagar?</h2>
                <ul className="list-none space-y-2">
                  <li>✅ Comprehensive control services – for every pest problem</li>
                  <li>✅ Specialized spider control, termite control, and more 🕷️🪳</li>
                  <li>✅ Eco-friendly treatments safe for kids and pets 🌱👶</li>
                  <li>✅ 10+ years of experience & trusted by 1000+ happy customers 💼🌟</li>
                  <li>✅ Affordable quotes, no hidden charges 💸</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">🧰 Our Services in MGR Nagar Include:</h2>
                <ul className="list-none space-y-2">
                  <li>✅ General pest control services</li>
                  <li>✅ Spider control & ant management</li>
                  <li>✅ Termite control for long-lasting protection</li>
                  <li>✅ Mosquito and cockroach treatment 🦟🪳</li>
                  <li>✅ Rodent and lizard removal</li>
                  <li>✅ Sanitization and disinfection</li>
                  <li>✅ AMC packages for commercial and residential spaces 🏢🏘️</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Service Location:</h2>
                <p>
                  We proudly serve all of MGR Nagar Chennai, Tamil Nadu – bringing expert pest control right to your
                  doorstep. Looking for a trusted pvt ltd company? We're here to help! 💼
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">📞 Get a Free Quote Today!</h2>
                <p>
                  Don't wait until pests take over – let our team of experts protect your home or office today! 👨‍🔧🔥
                </p>
                <ul className="list-none space-y-2">
                  <li>📍 Location: Chennai, Tamil Nadu</li>
                  <li>
                    📞 Phone:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="http://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in MGR Nagar</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="MGR Nagar" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in MGR Nagar. Contact us
                      today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
