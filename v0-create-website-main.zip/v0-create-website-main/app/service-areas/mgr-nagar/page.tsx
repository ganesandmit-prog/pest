import type { Metadata } from "next"
import MGRNagarPestControlClient from "./MGRNagarPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in MGR Nagar | No.1 Quality Pest Control",
  description:
    "Professional pest control services in MGR Nagar, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control MGR Nagar, pest control services MGR Nagar, cockroach control MGR Nagar, termite control MGR Nagar, rodent control MGR Nagar, bed bug treatment MGR Nagar, pest control Chennai, No.1 Quality Pest Control",
}

export default function MGRNagarPage() {
  return <MGRNagarPestControlClient />
}
