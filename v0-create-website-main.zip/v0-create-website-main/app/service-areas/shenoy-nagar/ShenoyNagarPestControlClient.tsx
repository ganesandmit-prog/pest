"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function ShenoyNagarPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Shenoy Nagar, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                🦟 Best Pest Control in Shenoy Nagar – Affordable & Trusted Services
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for professional pest control in Shenoy Nagar, Chennai? Whether you're dealing with
                  mosquitoes, termites, or general pests, our team delivers safe, effective, and eco-friendly pest
                  solutions at the best prices in the market. We're rated highly across platforms like Sulekha, trusted
                  by hundreds of homes and businesses for reliable, long-term pest management.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐜 Our Shenoy Nagar Pest Control Services Include:</h2>

                <ul className="list-none space-y-2">
                  <li>🦟 Mosquito Control – Safe fogging services for home, offices & outdoors</li>
                  <li>🪳 Cockroach Removal – Targeted gel and spray treatments</li>
                  <li>🐜 Termite Treatment – Advanced techniques to protect wood and structures</li>
                  <li>🛏️ Bed Bug Control – Fast elimination with minimal disruption</li>
                  <li>🌿 Organic Pest Management – For families that prefer chemical-free care</li>
                  <li>🧼 Cleaning & Disinfection – Post-treatment deep cleaning solutions</li>
                  <li>📦 Customized Packages – Get free quotes tailored to your needs</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">💡 Why Choose Us for Pest Control in Shenoy Nagar?</h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Experienced Technicians – Skilled in all pest treatment methods</li>
                  <li>✔️ Eco-Friendly Treatments – Organic options for homes with children and pets</li>
                  <li>✔️ Affordable Pricing – Transparent quotes with no hidden charges</li>
                  <li>✔️ Fast Response – Service available throughout Shenoy Nagar and nearby areas</li>
                  <li>✔️ Sulekha Verified Company – 100% customer satisfaction</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Serving Locations:</h2>

                <ul className="list-none space-y-2">
                  <li>Shenoy Nagar</li>
                  <li>Aminjikarai, Kilpauk, Anna Nagar</li>
                  <li>Nearby residential colonies and commercial buildings</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">📞 Call Now for Free Quote:</h3>
                  <p className="mt-4">
                    📱 Phone: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
