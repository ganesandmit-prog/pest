import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Arumbakkam | No.1 Quality Pest Control Chennai",
  description:
    "Looking for trusted pest control in Arumbakkam? We offer safe, eco-friendly, and affordable pest control services for homes and businesses across Arumbakkam, Chennai.",
}

export default function ArumbakkamPage() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Best Pest Control in Arumbakkam" subtitle="Professional & Affordable Services" />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="prose max-w-none mb-8">
            <p className="text-lg">
              Looking for trusted pest control in Arumbakkam? You're in the right place. We are a leading pest control
              company offering safe, eco-friendly, and affordable pest control services in Arumbakkam, Anna Nagar, and
              across Chennai.
            </p>
            <p className="text-lg">
              Whether it's termites, cockroaches, rats, mosquitoes, or bed bugs, our experienced team provides
              residential pest control, gel pest control, and termite control treatments with high customer satisfaction
              ratings on Sulekha, Google, and Justdial.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Professional Pest Control Services in Arumbakkam Include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 General Pest Control Services</h3>
                <p>Comprehensive solutions for all common household pests.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Gel-Based Cockroach Pest Control</h3>
                <p>Advanced gel treatments for effective cockroach elimination.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Termite Control Services (Pre & Post-Construction)</h3>
                <p>Complete protection against termites for your property.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Rodent/Rat Control</h3>
                <p>Safe and humane solutions to eliminate rodent infestations.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Bed Bug Treatment</h3>
                <p>Specialized treatments to eliminate bed bugs completely.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Mosquito Fogging & Control</h3>
                <p>Effective solutions to keep mosquitoes away from your premises.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Commercial & Industrial Pest Management</h3>
                <p>Tailored solutions for businesses and industrial spaces.</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-bold mb-2">🔸 Disinfection & Sanitization Services</h3>
                <p>Professional cleaning and sanitization for a healthy environment.</p>
              </div>
            </div>
            <p className="mt-4">
              We use non-toxic, odorless solutions with 100% safety for kids and pets. Our services are highly
              recommended on Chennai Sulekha, Google Maps, and by thousands of satisfied customers.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-light-green/10 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Why We Are the Best Pest Control Company in Arumbakkam</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Ranked Top on Google & Sulekha for "pest control Arumbakkam"</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Trusted by 1000+ Homes in Arumbakkam, Anna Nagar, and Chennai</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Offers Asian Pest Control Quality Standards</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Uses Modern Gel Pest Control Techniques</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Serves with Top Ratings & Genuine Customer Reviews</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>Certified Technicians | Guaranteed Results | Free Inspection</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✔️</span>
                <span>24x7 Emergency Services | Competitive Pricing</span>
              </li>
            </ul>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Service Locations Around Arumbakkam</h2>
            <p>
              We provide residential pest control services and commercial pest solutions not just in Arumbakkam but also
              in:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Anna Nagar</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Ambattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Villivakkam</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Avadi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Korattur</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Mogappair</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">Padi</div>
              <div className="bg-light-green/10 p-3 rounded-lg text-center">All Over Chennai</div>
            </div>
            <p className="mt-4">
              Whether you're a homeowner or a business in Arumbakkam Chennai, we've got your pest worries covered.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 className="text-2xl font-bold mb-4">Top-Rated Pest Control with Real Reviews, Ratings & Photos</h2>
            <p className="mb-4">
              With verified listings on Sulekha, Justdial, and Google, we are a leading pest control provider in Chennai
              known for reliability and quality. Explore our:
            </p>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Verified Listings with Real Photos</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Authentic Ratings & Reviews</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green mr-2">✅</span>
                <span>Advanced Treatment for Termites, Cockroaches, Bed Bugs</span>
              </li>
            </ul>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-dark-green text-white p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold mb-4">Call Now for Free Inspection & Lowest Rates!</h2>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex items-center">
                <span className="text-xl mr-2">📞</span>
                <span>
                  Phone:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">🌐</span>
                <span>
                  Website:{" "}
                  <a
                    href="https://www.no1qualitypestcontrol.com"
                    className="font-bold hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    www.no1qualitypestcontrol.com
                  </a>
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-xl mr-2">📧</span>
                <span>
                  Email:{" "}
                  <a href="mailto:no1qualitypestcontrol@gmail.com" className="font-bold hover:underline">
                    no1qualitypestcontrol@gmail.com
                  </a>
                </span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-6 text-center">Contact Us for Pest Control in Arumbakkam</h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
