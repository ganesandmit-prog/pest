"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { MapPin, Phone, Mail, Clock, CheckCircle } from "lucide-react"

import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ServicesList } from "@/components/services-list"
import { BenefitsSection } from "@/components/benefits-section"
import { AnimatedSection, FadeInStagger } from "@/components/framer-animations"

export function NungambakkamPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Pest Control Services in Nungambakkam, Chennai"
        description="Professional pest control services in Nungambakkam, Chennai. We offer termite control, cockroach control, and more at affordable prices."
      />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-gray-50 to-white py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <AnimatedSection animation="fadeIn">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold mb-4">
                    Professional Pest Control Services in Nungambakkam, Chennai
                  </h1>
                  <p className="text-lg mb-6">
                    Are pests invading your home or office in Nungambakkam, Chennai? Trust No.1 Quality Pest Control for
                    fast, effective, and affordable pest control services tailored to your specific needs.
                  </p>
                  <p className="text-lg mb-6">
                    From cockroach control to termite treatment and bed bugs elimination, we provide comprehensive pest
                    management solutions that keep your environment safe and pest-free.
                  </p>
                  <div className="flex flex-wrap gap-4 mb-8">
                    <Link href="/contact-us">
                      <motion.button className="btn-primary" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        Get Free Quote
                      </motion.button>
                    </Link>
                    <Link href="tel:+917558108600">
                      <motion.button className="btn-outline" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        Call Us Now
                      </motion.button>
                    </Link>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pest-control-nungambakkam-Yx9Ij9Ij9Ij9Ij9Ij9.jpg"
                    alt="Pest Control Service in Nungambakkam"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Our Pest Control Services in Nungambakkam Include</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FadeInStagger>
                {[
                  {
                    title: "Cockroach Control & Extermination",
                    description:
                      "Effective elimination of cockroaches using targeted treatments and preventive measures.",
                  },
                  {
                    title: "Bed Bugs Treatment",
                    description: "Specialized bed bug removal services to eliminate these persistent pests.",
                  },
                  {
                    title: "Termite Control & Prevention",
                    description:
                      "Protect your property from termite damage with our comprehensive treatment solutions.",
                  },
                  {
                    title: "Mosquito & Insect Management",
                    description: "Reduce mosquito populations and control other flying insects around your property.",
                  },
                  {
                    title: "Eco-Friendly & Organic Pest Solutions",
                    description: "Environmentally friendly pest control options that are safe for families and pets.",
                  },
                  {
                    title: "Commercial Pest Management",
                    description:
                      "Professional pest control services for offices, restaurants, and commercial establishments.",
                  },
                ].map((service, index) => (
                  <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                    <motion.div
                      className="bg-white p-6 rounded-lg shadow-md h-full"
                      whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                    >
                      <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                      <p className="text-gray-600">{service.description}</p>
                    </motion.div>
                  </AnimatedSection>
                ))}
              </FadeInStagger>
            </div>

            <AnimatedSection animation="fadeIn" delay={0.5}>
              <div className="text-center mt-8">
                <p className="text-lg mb-4">
                  We use only certified and safe chemicals, ensuring complete protection for your family and pets.
                </p>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-12">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Areas We Serve in and Around Nungambakkam</h2>
            </AnimatedSection>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              {["Nungambakkam, Chennai", "Alwarpet", "Teynampet", "Egmore", "Kodambakkam", "Chetpet"].map(
                (area, index) => (
                  <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                    <div className="bg-gray-50 p-4 rounded-lg text-center">
                      <MapPin className="h-5 w-5 mx-auto mb-2 text-dark-green" />
                      <p>{area}</p>
                    </div>
                  </AnimatedSection>
                ),
              )}
            </div>

            <AnimatedSection animation="fadeIn" delay={0.5}>
              <div className="text-center">
                <p className="text-lg">
                  Our expert team is listed and trusted on Sulekha Chennai and has helped thousands of happy clients!
                </p>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">
                Why Choose No.1 Quality Pest Control in Nungambakkam?
              </h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "40+ Years of Professional Experience",
                  description: "Benefit from our decades of expertise in pest management.",
                },
                {
                  title: "Certified Technicians & Proven Methods",
                  description: "Our technicians are trained and certified in the latest pest control methods.",
                },
                {
                  title: "Quick Response & Flexible Scheduling",
                  description: "Fast service when you need it most, with convenient scheduling options.",
                },
                {
                  title: "Affordable Prices & Free Inspections",
                  description: "Competitive pricing with no hidden charges and complimentary inspections.",
                },
                {
                  title: "Customized Pest Control Plans",
                  description: "Tailored solutions designed to address your specific pest problems.",
                },
                {
                  title: "Satisfaction Guaranteed",
                  description: "We're not satisfied until your pest problem is completely resolved.",
                },
              ].map((benefit, index) => (
                <AnimatedSection key={index} animation="fadeIn" delay={index * 0.1}>
                  <motion.div
                    className="bg-white p-6 rounded-lg shadow-md h-full"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  >
                    <div className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                        <p className="text-gray-600">{benefit.description}</p>
                      </div>
                    </div>
                  </motion.div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Hear from Our Satisfied Customers</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <AnimatedSection animation="fadeIn" delay={0.1}>
                <motion.div
                  className="bg-white p-6 rounded-lg shadow-md border-l-4 border-dark-green"
                  whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                >
                  <p className="italic mb-4">
                    "Effective termite and cockroach control service in Nungambakkam. Highly recommend!"
                  </p>
                  <p className="font-bold">— Anita S., Nungambakkam Resident</p>
                </motion.div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <motion.div
                  className="bg-white p-6 rounded-lg shadow-md border-l-4 border-dark-green"
                  whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                >
                  <p className="italic mb-4">"Great bed bug treatment with organic options. Very professional team!"</p>
                  <p className="font-bold">— Vijay P., Chennai</p>
                </motion.div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-8">Contact No.1 Quality Pest Control Today</h2>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="fadeIn" delay={0.1}>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <MapPin className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>Nungambakkam, Chennai</p>
                    </div>
                    <div className="flex items-start">
                      <Phone className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>
                        <a href="tel:+917558108600" className="hover:underline">
                          +91 75581 08600
                        </a>
                      </p>
                    </div>
                    <div className="flex items-start">
                      <Mail className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>
                        <a href="mailto:no1qualitypestcontrol@gmail.com" className="hover:underline">
                          no1qualitypestcontrol@gmail.com
                        </a>
                      </p>
                    </div>
                    <div className="flex items-start">
                      <Clock className="h-6 w-6 text-dark-green mr-2 flex-shrink-0 mt-1" />
                      <p>Available 24/7 for emergency pest control services</p>
                    </div>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection animation="fadeIn" delay={0.2}>
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </section>

        <ServicesList />
        <BenefitsSection />
        <TestimonialsSection />
      </main>
    </div>
  )
}

export default NungambakkamPestControlClient
