import type { Metadata } from "next"
import NungambakkamPestControlClient from "./NungambakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nungambakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nungambakkam, Chennai. We offer termite control, cockroach control, and more at affordable prices.",
  keywords:
    "pest control Nungambakkam, termite control Nungambakkam, cockroach control Nungambakkam, pest management Chennai, Nungambakkam pest services, residential pest control, commercial pest control",
}

export default function NungambakkamPage() {
  return <NungambakkamPestControlClient />
}
