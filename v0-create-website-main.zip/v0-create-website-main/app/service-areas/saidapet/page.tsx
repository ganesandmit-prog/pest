import type { Metadata } from "next"
import { SaidapetPestControlClient } from "./SaidapetPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Saidapet, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Saidapet, Chennai. We offer cockroach, termite, bed bug, and mosquito control with eco-friendly solutions. Call now!",
  keywords:
    "pest control Saidapet, Saidapet pest control services, pest control near Saidapet Railway Station, organic pest control Saidapet, pest control company Chennai",
}

export default function SaidapetPage() {
  return <SaidapetPestControlClient />
}
