"use client"
import { PageHeader } from "@/components/page-header"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export function SaidapetPestControlClient() {
  return (
    <div className="flex flex-col min-h-screen">
      <FloatingActionButton />

      <PageHeader
        title="Pest Control Services in Saidapet, Chennai"
        subtitle="Professional & Affordable Pest Management Solutions"
        image="/images/termite-image.png"
      />

      <main className="flex-1">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
                ✅ Pest Control in Saidapet, Chennai – Expert Services Near Saidapet Railway Station
              </h1>

              <div className="prose max-w-none">
                <p>
                  Looking for trusted and affordable pest control in Saidapet, Chennai? We are the leading pest control
                  company offering highly effective solutions for homes, offices, and commercial spaces. Located near
                  Saidapet Railway Station, our professional team handles everything from cockroach infestations to
                  termite and bed bug issues, using organic pest control techniques that are child- and pet-safe.
                </p>

                <h2 className="text-2xl font-semibold mt-8 mb-4">🐜 Our Pest Control Services in Saidapet Include:</h2>

                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control Services – Odorless gel & herbal spray</li>
                  <li>🐀 Rodent Control – Complete rat/mouse removal</li>
                  <li>🛏️ Bed Bug Treatment – Herbal & chemical-free solutions</li>
                  <li>🦟 Mosquito Fogging – Indoor & outdoor areas</li>
                  <li>🧱 Termite Control Service – Pre & post construction</li>
                  <li>🌿 Organic Pest Control – Eco-friendly & safe</li>
                  <li>🧹 Post-Pest Cleaning Services – Ensure hygiene & safety</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">
                  💡 Why We Are the Best Pest Control Company in Saidapet
                </h2>

                <ul className="list-none space-y-2">
                  <li>✔️ Licensed Experts – Certified professionals with years of experience</li>
                  <li>✔️ Eco-Friendly Solutions – Safe for kids, pets, and elders</li>
                  <li>✔️ Quick & Efficient – Same-day service available near Saidapet Railway Station</li>
                  <li>✔️ Affordable Prices – No hidden charges</li>
                  <li>✔️ Great Customer Reviews – Rated 5 stars across Saidapet</li>
                  <li>✔️ Verified Address – Easy to locate, trusted by locals</li>
                </ul>

                <h2 className="text-2xl font-semibold mt-8 mb-4">📍 Serving Saidapet & Nearby Areas:</h2>

                <ul className="list-none space-y-2">
                  <li>Saidapet Railway Station Area</li>
                  <li>Little Mount</li>
                  <li>Nandanam</li>
                  <li>West Mambalam</li>
                  <li>Guindy</li>
                  <li>T. Nagar</li>
                  <li>Anna Salai (Mount Road)</li>
                </ul>

                <div className="bg-blue-50 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-semibold mb-4">
                    📞 Contact the #1 Pest Control Service in Saidapet, Chennai!
                  </h3>
                  <p>
                    Secure your space today with Saidapet's most trusted pest control team. Call now for free inspection
                    and affordable pricing.
                  </p>
                  <p className="mt-4">
                    📱 Call: +91 7558108600
                    <br />📧 Email: no1qualitypestcontrol@gmail.com
                    <br />🌐 Website: www.no1qualitypestcontrol.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ServicesList />
        <ProcessSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ContactForm />
      </main>
    </div>
  )
}
