import type { Metadata } from "next"
import ManaliPestControlClient from "./ManaliPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Manali | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Manali, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Manali, pest control services Manali, cockroach control Manali, termite control Manali, rodent control Manali, bed bug treatment Manali, pest control Chennai, No.1 Quality Pest Control",
}

export default function ManaliPage() {
  return <ManaliPestControlClient />
}
