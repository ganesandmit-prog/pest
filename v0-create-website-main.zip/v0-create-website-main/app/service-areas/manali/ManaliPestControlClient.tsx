"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function ManaliPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Manali" subtitle="Chennai's Trusted Pest Control Services" />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Need reliable pest control in Manali, Chennai? No.1 Quality Pest Control offers top-rated control
                  services for homes, apartments, and businesses at competitive charges. Whether you're dealing with
                  cockroach infestations, termites, or general residential pest issues, we've got your back.
                </p>
                <p className="text-lg">
                  Our expert team ensures thorough, safe, and eco-friendly solutions that are customized for the Manali
                  Chennai region. We do more than just cleaning—we eliminate pests from the root!
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🏠 Services Offered in Manali:</h2>
                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control Services</li>
                  <li>🐜 Termite Control and Treatment</li>
                  <li>🛏️ Bed Bug Removal</li>
                  <li>🐀 Rodent and Rat Control</li>
                  <li>🦟 Mosquito Fogging & Fly Control</li>
                  <li>🧼 Cleaning and Disinfection of Pest Zones</li>
                  <li>🌿 Residential Pest Control Solutions</li>
                </ul>
                <p>
                  We also offer pest management packages for commercial spaces and residential apartments across Manali
                  Chennai.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Why Choose Us?</h2>
                <ul className="list-none space-y-2">
                  <li>✔️ Chennai-based pest control experts</li>
                  <li>✔️ Trusted name in residential pest control</li>
                  <li>✔️ Listed on Sulekha and local directories</li>
                  <li>✔️ Affordable service charges with guaranteed results</li>
                  <li>✔️ Trained team and advanced pest control tools</li>
                  <li>✔️ Fully safe for kids, elders, and pets</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">🌍 Areas We Serve:</h2>
                <ul className="list-none space-y-2">
                  <li>Manali</li>
                  <li>Ennore</li>
                  <li>Thiruvottiyur</li>
                  <li>Madhavaram</li>
                  <li>Royapuram</li>
                  <li>Tondiarpet</li>
                  <li>Perambur</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">📞 Book Your Pest Control Service in Manali Now!</h2>
                <ul className="list-none space-y-2">
                  <li>📍 Office: Manali, Chennai</li>
                  <li>
                    📞 Call Us:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="https://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      https://www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Manali</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Manali" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Manali. Contact us
                      today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
