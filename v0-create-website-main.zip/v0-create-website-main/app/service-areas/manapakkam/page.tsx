import type { Metadata } from "next"
import ManapakkamPestControlClient from "./ManapakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Manapakkam | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Manapakkam, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Manapakkam, pest control services Manapakkam, cockroach control Manapakkam, termite control Manapakkam, rodent control Manapakkam, bed bug treatment Manapakkam, pest control Chennai, No.1 Quality Pest Control",
}

export default function ManapakkamPage() {
  return <ManapakkamPestControlClient />
}
