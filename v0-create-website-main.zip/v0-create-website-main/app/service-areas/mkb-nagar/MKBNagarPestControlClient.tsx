"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { CheckCircle } from "lucide-react"

export function MKBNagarPestControlClient() {
  const [formSubmitted, setFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setFormSubmitted(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in MKB Nagar, Chennai" subtitle="Safe, Quick & Trusted!" />

      <main className="flex-grow">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <FadeIn className="max-w-3xl mx-auto text-center mb-8 md:mb-12">
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                Searching for affordable pest control in MKB Nagar? Look no further! At No.1 Quality Pest Control, we
                specialize in residential and warehouse pest control services across MKB Nagar Chennai and nearby
                locations.
              </p>
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                Whether it's cockroach infestations, termite damage, or rodent issues, we offer fast, eco-friendly, and
                long-lasting pest control solutions for homes, apartments, offices, and commercial spaces. 🏠🏢
              </p>
            </FadeIn>

            <div className="max-w-3xl mx-auto">
              <FadeIn>
                <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
                  🧰 Our Pest Control Services in MKB Nagar Include:
                </h2>
              </FadeIn>

              <FadeInStagger className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🪳 Cockroach Control Services</h3>
                  <p className="text-gray-700">Complete elimination of cockroaches from your home or business.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐀 Rodent & Mice Removal</h3>
                  <p className="text-gray-700">Effective solutions to keep rodents away from your property.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐜 Termite Treatment in MKB Nagar</h3>
                  <p className="text-gray-700">Protect your property from costly termite damage.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🦟 Mosquito Control & Fogging</h3>
                  <p className="text-gray-700">Effective mosquito management for a healthier environment.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🛏️ Bed Bug Removal Services</h3>
                  <p className="text-gray-700">Specialized solutions for complete bed bug elimination.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🕷 Spider & Ant Control</h3>
                  <p className="text-gray-700">Safe removal of spiders, ants and other crawling insects.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md col-span-1 md:col-span-2">
                  <h3 className="text-xl font-semibold mb-3">🌿 Eco-Friendly & Herbal Pest Treatments</h3>
                  <p className="text-gray-700">
                    We're listed on Sulekha Chennai and trusted by hundreds of happy families and businesses. ✅
                  </p>
                </FadeIn>
              </FadeInStagger>

              <FadeIn>
                <div className="bg-blue-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">📍 Why Choose Us in MKB Nagar?</h2>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Over 10 Years of Expertise</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Safe, Odorless & Government-Approved Chemicals</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Trained Professionals</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Affordable Pricing with Free Quote 📞</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Warehouse & Residential Pest Control</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Emergency Same-Day Service Available! 🚨</span>
                    </li>
                  </ul>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">💬 Real Reviews from MKB Nagar Clients:</h2>
                  <div className="space-y-6">
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "Highly efficient service for cockroach and mosquito control. Quick response too!"
                      <footer className="text-right font-medium mt-2">— Karthik V., MKB Nagar</footer>
                    </blockquote>
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "They did termite control for my warehouse. Very professional and neat service."
                      <footer className="text-right font-medium mt-2">— Lakshmi R., Business Owner</footer>
                    </blockquote>
                  </div>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-green-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">
                    📞 Contact the Best Pest Control in MKB Nagar Today!
                  </h2>
                  <div className="space-y-2 text-center">
                    <p>
                      <strong>📍 Location:</strong> MKB Nagar, Chennai, Tamil Nadu
                    </p>
                    <p>
                      <strong>📞 Phone:</strong> +91 75581 08600
                    </p>
                    <p>
                      <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
                    </p>
                    <p>
                      <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
                    </p>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        <ProcessSection />
        <BenefitsSection />

        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <FadeIn>
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in MKB Nagar</h2>
            </FadeIn>
            <div className="max-w-xl mx-auto">
              <ContactForm onSubmitSuccess={handleFormSubmit} />
              {formSubmitted && (
                <div className="mt-6 p-4 bg-green-100 text-green-700 rounded-md text-center">
                  Thank you for contacting us! We'll get back to you shortly about our pest control services in MKB
                  Nagar.
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
