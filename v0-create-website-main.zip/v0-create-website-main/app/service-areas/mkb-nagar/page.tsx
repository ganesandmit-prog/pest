import type { Metadata } from "next"
import { MKBNagarPestControlClient } from "./MKBNagarPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in MKB Nagar, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in MKB Nagar, Chennai. Safe, affordable solutions for cockroaches, termites, rodents & more. Call +91 75581 08600 for free quotes!",
  keywords:
    "pest control MKB Nagar, MKB Nagar pest services, cockroach control MKB Nagar, termite treatment MKB Nagar, rodent control MKB Nagar, pest control services Chennai, warehouse pest control",
}

export default function MKBNagarPestControlPage() {
  return <MKBNagarPestControlClient />
}
