"use client"
import { Helmet } from "react-helmet"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ServicesList } from "@/components/services-list"

export default function NanmangalamPestControlClient() {
  return (
    <div className="flex min-h-screen flex-col">
      <Helmet>
        <title>Pest Control Services in Nanmangalam, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Nanmangalam, Chennai. We offer termite control, bed bugs management, and safe pest solutions for homes and businesses."
        />
        <meta
          name="keywords"
          content="pest control Nanmangalam, termite control Nanmangalam, bed bugs treatment Chennai, pest management Nanmangalam, No.1 Quality Pest Control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/nanmangalam" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Nanmangalam",
              "image": "https://www.no1qualitypestcontrol.com/images/logo.png",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/nanmangalam",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Nanmangalam",
                "addressRegion": "Chennai",
                "postalCode": "600117",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 12.9347,
                "longitude": 80.1727
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <PageHeader
          title="Pest Control Services in Nanmangalam, Chennai"
          subtitle="Safe, Fast & Reliable Pest Management Solutions"
        />

        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">
              Expert Pest Control in Nanmangalam, Chennai – Safe, Fast & Reliable!
            </h2>
            <p className="mt-4 text-gray-600">
              Searching for trusted pest control in Nanmangalam? Look no further! At No.1 Quality Pest Control, we offer
              comprehensive and affordable pest control services tailored to your home or business needs in Nanmangalam
              Chennai. From termite control to bed bugs management, our certified professionals use safe, effective
              methods to keep your space pest-free.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">
              Our Top Pest Control Services in Nanmangalam Include:
            </h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Termite Control & Prevention</li>
              <li>Bed Bugs Control & Treatment</li>
              <li>Mosquito Management Solutions</li>
              <li>Spider & Insect Control</li>
              <li>Rodent Control Services</li>
              <li>Eco-Friendly & Safe Pest Solutions</li>
            </ul>

            <p className="mt-4 text-gray-600">
              We utilize government-approved chemicals and eco-friendly products to ensure your family and pets stay
              protected.
            </p>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">Serving Nanmangalam and Nearby Areas:</h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Nanmangalam Chennai</li>
              <li>Sholinganallur</li>
              <li>Medavakkam</li>
              <li>Velachery</li>
              <li>OMR Road</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-800">
              Why Choose No.1 Quality Pest Control in Nanmangalam?
            </h3>
            <ul className="mt-4 list-disc pl-5 text-gray-600">
              <li>Over 10 Years of Experience</li>
              <li>Certified & Trained Pest Control Experts</li>
              <li>Affordable Pricing with Transparent Quotes</li>
              <li>Quick Response & Easy Booking</li>
              <li>Proven Long-Lasting Results</li>
              <li>Highly Rated on Google and Sulekha</li>
            </ul>

            <h3 className="mt-6 text-xl font-semibold text-gray-800">Hear from Our Happy Customers:</h3>
            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "No.1 Quality Pest Control solved our bed bugs problem in Nanmangalam quickly and professionally. Highly
                recommended!"
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Lakshmi S., Nanmangalam Resident</p>
            </div>

            <div className="mt-4 rounded-lg bg-gray-50 p-4">
              <p className="italic text-gray-600">
                "Reliable termite control service with excellent customer care. Very satisfied with the results."
              </p>
              <p className="mt-2 font-semibold text-gray-700">— Arjun K., Chennai</p>
            </div>

            <div className="mt-6 rounded-lg bg-blue-50 p-4">
              <h4 className="font-semibold text-blue-800">Contact No.1 Quality Pest Control in Nanmangalam Today!</h4>
              <p className="mt-2 text-blue-700">
                📍 Location: Nanmangalam, Chennai, Tamil Nadu
                <br />📞 Call: +91 75581 08600
                <br />📧 Email: no1qualitypestcontrol@gmail.com
                <br />🌐 Website: www.no1qualitypestcontrol.com
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Our Pest Control Process in Nanmangalam</h2>
          <ProcessSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Why Nanmangalam Residents Choose Us</h2>
          <BenefitsSection />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Pest Control Services We Offer in Nanmangalam</h2>
          <ServicesList />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Testimonials from Nanmangalam Customers</h2>
          <TestimonialsSection location="Nanmangalam" />
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800">Contact Us for Pest Control in Nanmangalam</h2>
          <div className="mt-6">
            <ContactForm location="Nanmangalam" />
          </div>
        </div>
      </div>
    </div>
  )
}
