import type { Metadata } from "next"
import NanmangalamPestControlClient from "./NanmangalamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nanmangalam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nanmangalam, Chennai. We offer termite control, bed bugs management, and safe pest solutions for homes and businesses.",
  keywords:
    "pest control Nanmangalam, termite control Nanmangalam, bed bugs treatment Chennai, pest management Nanmangalam, No.1 Quality Pest Control",
}

export default function NanmangalamPestControlPage() {
  return <NanmangalamPestControlClient />
}
