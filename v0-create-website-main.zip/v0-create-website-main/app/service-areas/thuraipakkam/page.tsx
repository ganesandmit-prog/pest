import type { Metadata } from "next"
import ThuraipakkamPestControlClient from "./ThuraipakkamPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Thuraipakkam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thuraipakkam, Chennai. We offer cockroach, termite, bed bug, rodent & mosquito control with 45+ years of experience.",
  keywords:
    "pest control Thuraipakkam, Thuraipakkam pest services, cockroach control Thuraipakkam, termite treatment Thuraipakkam, bed bug control Thuraipakkam, rodent control Thuraipakkam, mosquito control Thuraipakkam, pest management Thuraipakkam Chennai",
}

export default function ThuraipakkamPestControlPage() {
  return <ThuraipakkamPestControlClient />
}
