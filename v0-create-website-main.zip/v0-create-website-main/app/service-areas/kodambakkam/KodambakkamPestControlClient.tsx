"use client"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ProcessSection from "@/components/process-section"
import ContactForm from "@/components/contact-form"

export default function KodambakkamPestControlClient() {
  return (
    <main className="flex flex-col min-h-screen">
      <PageHeader title="Reliable Pest Control in Kodambakkam, Chennai" subtitle="Safe & Effective Solutions" />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                Are you facing pest problems in your home or office? We provide the best pest control services in
                Kodambakkam, Chennai – tailored to your specific needs. Our team of trained professionals uses effective
                pest control solutions to eliminate cockroaches, termites, mosquitoes, and more.
              </p>
              <p className="text-lg mb-6">
                From general pest control to deep cleaning, we ensure your space remains hygienic, safe, and pest-free.
                Our control services are trusted across Chennai Tamil Nadu, with hundreds of happy clients.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🛠️ Our Pest Control Services in Kodambakkam Include:
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🪳</span>
                    <span>
                      <strong>Cockroach Control</strong> – Fast & safe treatment
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐜</span>
                    <span>
                      <strong>Termite Control</strong> – Long-lasting protection
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🦟</span>
                    <span>
                      <strong>Mosquito Control</strong> – Say goodbye to buzzing threats
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🐀</span>
                    <span>
                      <strong>Rodent & Rat Control</strong> – No more chewing or contamination
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🛏️</span>
                    <span>
                      <strong>Bed Bug Treatment</strong> – Sleep peacefully again
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧼</span>
                    <span>
                      <strong>General Pest Control</strong> – One-stop solution for all pest issues
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-xl mr-2">🧹</span>
                    <span>
                      <strong>Cleaning Services</strong> – Post-treatment disinfection
                    </span>
                  </li>
                </ul>
              </div>

              <p className="text-lg mb-6">
                Our expert pest control service is ideal for homes, offices, apartments, and commercial spaces in
                Kodambakkam Chennai.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  💡 Why Choose Our Pest Control Company in Kodambakkam?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Experienced & Licensed Professionals</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Safe for Children & Pets – Non-toxic Solutions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Affordable Pricing – Transparent with No Hidden Costs</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Prompt and Effective Control Service</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Trusted by Residents of Chennai Tamil Nadu</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">✔</span>
                    <span>Guaranteed Results with Follow-up Support</span>
                  </li>
                </ul>
              </div>

              <div className="my-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">📍 Areas We Cover Near Kodambakkam:</h2>
                <p className="mb-4">T. Nagar | Vadapalani | West Mambalam | Ashok Nagar | Nungambakkam | Choolaimedu</p>
              </div>

              <div className="bg-dark-green text-white p-6 rounded-lg my-8">
                <h2 className="text-2xl font-bold mb-4">
                  📞 Book the Best Pest Control Services in Kodambakkam Today!
                </h2>
                <p className="mb-2">
                  📱 Call Now:{" "}
                  <a href="tel:+917558108600" className="font-bold hover:underline">
                    +91 7558108600
                  </a>
                </p>
                <p className="mb-2">
                  📧 Email: <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </p>
                <p className="mb-2">
                  🌐 Visit: <span className="font-bold">www.no1qualitypestcontrol.com</span>
                </p>
                <p>📍 Location: Kodambakkam, Chennai Tamil Nadu</p>
              </div>

              <div className="my-8">
                <p className="text-lg">
                  🏡 From general pest control to specialized cockroach treatment, our pest control services in
                  Kodambakkam are trusted for their effectiveness, affordability, and reliability. Let our control
                  services restore safety and comfort to your space.
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <BenefitsSection />
      <ProcessSection />

      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Kodambakkam</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatedSection animation="slideRight">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Our Office</h3>
                  <p className="mb-2">202 Broadway Parrys</p>
                  <p className="mb-4">Chennai-600001, Tamil Nadu</p>
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <p className="mb-2">
                    <strong>Phone:</strong>{" "}
                    <a href="tel:+917558108600" className="hover:underline text-dark-green">
                      +91 7558108600
                    </a>
                  </p>
                  <p className="mb-2">
                    <strong>Email:</strong> no1qualitypestcontrol@gmail.com
                  </p>
                  <p className="mb-2">
                    <strong>Hours:</strong> 24/7 Emergency Service Available
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection animation="slideLeft">
                <ContactForm />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
