import type { Metadata } from "next"
import { ThiruninravurPestControlClient } from "./ThiruninravurPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Thiruninravur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Thiruninravur, Chennai. 45+ years of experience in residential & commercial pest management. Call for free inspection!",
  keywords:
    "pest control Thiruninravur, Thiruninravur pest services, pest management Thiruninravur, pest control near me, No.1 Quality Pest Control Thiruninravur, mosquito control Thiruninravur, termite treatment Thiruninravur, residential pest control Thiruninravur",
}

export default function ThiruninravurPage() {
  return <ThiruninravurPestControlClient />
}
