"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PageHeader } from "@/components/page-header"
import { ServicesList } from "@/components/services-list"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactForm } from "@/components/contact-form"
import { QuickLinks } from "@/components/quick-links"
import FAQSection from "@/components/faq-section"
import CTA from "@/components/cta"

export function ThiruninravurPestControlClient() {
  const [activeTab, setActiveTab] = useState("services")

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        heading="Professional Pest Control Services in Thiruninravur, Chennai"
        subheading="No.1 Quality Pest Control provides expert pest management solutions for homes and businesses in Thiruninravur"
      />

      <div className="container px-4 py-6 md:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Tabs defaultValue="services" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="services">Services</TabsTrigger>
                <TabsTrigger value="process">Our Process</TabsTrigger>
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
              </TabsList>
              <TabsContent value="services" className="mt-6">
                <div className="prose max-w-none">
                  <h2>Pest Control Services in Thiruninravur</h2>
                  <p>
                    No.1 Quality Pest Control offers comprehensive pest management solutions to residents and businesses
                    in Thiruninravur, Chennai. With over 45 years of experience, our team of certified technicians is
                    equipped to handle all types of pest infestations, from common household pests to more complex
                    commercial pest problems.
                  </p>
                  <p>
                    Thiruninravur, being a western suburb of Chennai, faces unique pest challenges due to its mix of
                    residential areas and natural surroundings. Our localized approach ensures that we address the
                    specific pest issues prevalent in Thiruninravur, providing targeted and effective solutions.
                  </p>
                </div>
                <ServicesList location="Thiruninravur" />
              </TabsContent>
              <TabsContent value="process" className="mt-6">
                <ProcessSection location="Thiruninravur" />
              </TabsContent>
              <TabsContent value="benefits" className="mt-6">
                <BenefitsSection />
              </TabsContent>
              <TabsContent value="testimonials" className="mt-6">
                <TestimonialsSection />
              </TabsContent>
            </Tabs>

            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Recent Pest Control Projects in Thiruninravur</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-xl font-semibold mb-2">Residential Termite Treatment</h3>
                  <p className="text-gray-600 mb-4">
                    Complete termite protection for a residential property in Thiruninravur, including pre-construction
                    treatment and perimeter barrier.
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-xl font-semibold mb-2">Commercial Pest Management</h3>
                  <p className="text-gray-600 mb-4">
                    Ongoing pest management program for a retail complex in Thiruninravur, focusing on rodent control
                    and general pest prevention.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <FAQSection
                title="Frequently Asked Questions About Pest Control in Thiruninravur"
                subtitle="Get answers to common questions about our pest control services in Thiruninravur"
                faqs={[
                  {
                    question: "How often should I schedule pest control services in Thiruninravur?",
                    answer:
                      "For most residential properties in Thiruninravur, we recommend quarterly pest control treatments to maintain a pest-free environment. However, this can vary based on specific pest pressures, property location, and seasonal factors. Our technicians can provide a customized recommendation after assessing your property.",
                  },
                  {
                    question: "Do you offer emergency pest control services in Thiruninravur?",
                    answer:
                      "Yes, we provide emergency pest control services for Thiruninravur residents and businesses. Our team can typically respond within 24-48 hours for urgent situations like rodent infestations, bed bug outbreaks, or wasp nests that pose immediate concerns.",
                  },
                  {
                    question: "Are your pest control treatments safe for children and pets?",
                    answer:
                      "Safety is our top priority. We use eco-friendly and low-toxicity products that are safe for families and pets when applied according to guidelines. Our technicians provide specific instructions on precautions to take during and after treatment, including recommended waiting periods before re-entering treated areas.",
                  },
                  {
                    question: "What types of pests are common in Thiruninravur?",
                    answer:
                      "Thiruninravur properties commonly experience issues with mosquitoes, ants, cockroaches, termites, and rodents. The area's mix of residential and natural environments creates unique pest pressures that our localized treatment approaches are designed to address.",
                  },
                ]}
              />
            </div>

            <div className="mt-12">
              <CTA
                title="Schedule Your Pest Inspection in Thiruninravur Today"
                description="Our expert technicians are ready to help you with all your pest control needs in Thiruninravur."
                buttonText="Contact Us Now"
                buttonLink="/contact-us"
                phone="9876543210"
              />
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <ContactForm location="Thiruninravur" />
            </div>

            <div className="mt-6">
              <QuickLinks />
            </div>

            <div className="mt-6 bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">Areas We Serve in Chennai</h3>
              <ul className="grid grid-cols-2 gap-2 text-sm">
                <li>
                  <a href="/service-areas/adyar" className="text-blue-600 hover:underline">
                    Adyar
                  </a>
                </li>
                <li>
                  <a href="/service-areas/anna-nagar" className="text-blue-600 hover:underline">
                    Anna Nagar
                  </a>
                </li>
                <li>
                  <a href="/service-areas/besant-nagar" className="text-blue-600 hover:underline">
                    Besant Nagar
                  </a>
                </li>
                <li>
                  <a href="/service-areas/guindy" className="text-blue-600 hover:underline">
                    Guindy
                  </a>
                </li>
                <li>
                  <a href="/service-areas/t-nagar" className="text-blue-600 hover:underline">
                    T. Nagar
                  </a>
                </li>
                <li>
                  <a href="/service-areas/velachery" className="text-blue-600 hover:underline">
                    Velachery
                  </a>
                </li>
                <li>
                  <a href="/service-areas" className="text-blue-600 hover:underline font-semibold">
                    View All Areas →
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
