import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import PoonamalleePestControlClient from "./PoonamalleePestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Poonamallee Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Poonamallee? No.1 Quality Pest Control offers reliable, safe, and affordable pest control services in Poonamallee Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function PoonamalleePestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Poonamallee Chennai"
        subtitle="Professional & Affordable Pest Control Services in Poonamallee"
      />
      <PoonamalleePestControlClient />
    </main>
  )
}
