import type { Metadata } from "next"
import ManaliNewTownPestControlClient from "./ManaliNewTownPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control in Manali New Town | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Manali New Town, Chennai. We offer cockroach control, termite treatment, rodent control and more. Call +91 7558108600 for safe and effective pest control.",
  keywords:
    "pest control Manali New Town, pest control services Manali New Town, cockroach control Manali New Town, termite control Manali New Town, rodent control Manali New Town, bed bug treatment Manali New Town, pest control Chennai, No.1 Quality Pest Control",
}

export default function ManaliNewTownPage() {
  return <ManaliNewTownPestControlClient />
}
