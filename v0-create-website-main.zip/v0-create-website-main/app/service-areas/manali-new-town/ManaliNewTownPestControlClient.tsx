"use client"
import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import BenefitsSection from "@/components/benefits-section"
import ContactForm from "@/components/contact-form"

export default function ManaliNewTownPestControlClient() {
  const [isLoading, setIsLoading] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Manali New Town" subtitle="Safe, Trusted & Affordable" />

      <main className="flex-grow">
        <section className="py-12 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="prose max-w-none">
                <p className="text-lg">
                  Looking for pest control in Manali New Town, Chennai? No.1 Quality Pest Control offers expert control
                  services to tackle all kinds of pests. From cockroaches and termites to general residential pest
                  issues, our professionals use safe and highly effective methods.
                </p>
                <p className="text-lg">
                  We serve both homes and commercial establishments in Manali New Town, delivering results that last!
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">🏠 Our Pest Control Services Include:</h2>
                <ul className="list-none space-y-2">
                  <li>🪳 Cockroach Control & Removal</li>
                  <li>🐜 Termite Control & Prevention</li>
                  <li>🐀 Rodent and Rat Management</li>
                  <li>🛏️ Bed Bug Eradication</li>
                  <li>🦟 Mosquito & Fly Control</li>
                  <li>🧼 General Cleaning and Disinfection</li>
                  <li>🏢 Residential & Commercial Pest Solutions</li>
                </ul>
                <p>
                  We cover New Town, Manali, and other Manali Chennai regions with punctual and budget-friendly
                  services.
                </p>

                <h2 className="text-2xl font-bold mt-8 mb-4">💼 Why People in Manali New Town Choose Us:</h2>
                <ul className="list-none space-y-2">
                  <li>✔️ Experienced & trained pest control professionals</li>
                  <li>✔️ Best pest control services at competitive prices</li>
                  <li>✔️ Eco-friendly and pet-safe solutions</li>
                  <li>✔️ Fast response and complete cleaning of affected areas</li>
                  <li>✔️ Local presence in Manali New Town and Manali Chennai</li>
                </ul>

                <h2 className="text-2xl font-bold mt-8 mb-4">📍 Contact Us Today</h2>
                <ul className="list-none space-y-2">
                  <li>
                    📞 Phone:{" "}
                    <a href="tel:+917558108600" className="text-light-green hover:underline">
                      +91 75581 08600
                    </a>
                  </li>
                  <li>📧 Email: no1qualitypestcontrol@gmail.com</li>
                  <li>
                    🌐 Website:{" "}
                    <a href="https://www.no1qualitypestcontrol.com" className="text-light-green hover:underline">
                      https://www.no1qualitypestcontrol.com
                    </a>
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <BenefitsSection />

        <section className="py-12 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Manali New Town</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ContactForm location="Manali New Town" setIsLoading={setIsLoading} />
                </div>
                <div className="flex items-center justify-center">
                  <div className="max-w-md">
                    <h3 className="text-2xl font-semibold mb-4">Get Professional Pest Control Services</h3>
                    <p className="mb-6">
                      Our team of experts is ready to help you with all your pest control needs in Manali New Town.
                      Contact us today for a free consultation.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Fast and Reliable Service
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Affordable Pricing
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Experienced Professionals
                      </li>
                      <li className="flex items-center">
                        <span className="bg-light-green rounded-full p-1 mr-3">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-white"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        Eco-friendly Solutions
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}
