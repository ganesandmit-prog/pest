import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Best Pest Control in Alandur - Chennai Tamil Nadu",
  description:
    "Looking for the best pest control in Alandur Chennai? No.1 Quality Pest Control offers affordable, effective, and safe pest control services in Alandur for homes, apartments, offices, and commercial spaces.",
}

export default function AlandurPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Alandur"
        subtitle="Professional & Affordable Pest Control Services in Alandur Chennai"
      />

      <div className="container mx-auto px-4 py-12">
        <AnimatedSection animation="fadeIn" delay={0.1}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Professional Pest Control in Alandur</h2>
            <p className="mb-4">
              Looking for the best pest control in Alandur Chennai? Welcome to No.1 Quality Pest Control, your most
              trusted pest control service providers in Tamil Nadu, offering professional pest control services at
              unbeatable prices!
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.2}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Residential & Commercial Pest Control Services in Alandur
            </h2>
            <p className="mb-4">We provide effective and eco-friendly pest control solutions for:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🪳 Cockroach Control</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐛 Termite Control</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐜 Ants</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐀 Rodents</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🦟 Mosquitoes</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🕷️ Spiders</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">🐞 All General Pests</div>
            </div>
            <p>
              Whether it's a villa, flat, office, or commercial space in Alandur Chennai, our pest control experts are
              ready to serve you!
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.3}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Why Choose Us for Pest Control in Alandur?</h2>
            <ul className="list-none space-y-3">
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✨</span>
                <span>100% Eco-Friendly & Green Pest Control</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✨</span>
                <span>Experienced Service Providers</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✨</span>
                <span>Safe for Kids & Pets</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✨</span>
                <span>Affordable Price Plans</span>
              </li>
              <li className="flex items-start">
                <span className="text-light-green font-bold mr-2">✨</span>
                <span>Instant Same-Day Service</span>
              </li>
            </ul>
            <p className="mt-4">
              We are your local general pest control company in Alandur Chennai Tamil Nadu delivering long-lasting
              protection with professional-grade treatments.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.4}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Cockroach & Termite Control Experts in Alandur</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <h3 className="text-xl font-bold text-dark-green mb-2">Cockroach Problem?</h3>
                <p>
                  We offer complete cockroach control with no smell and 100% effectiveness in kitchens, bathrooms, and
                  all living spaces.
                </p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <h3 className="text-xl font-bold text-dark-green mb-2">Worried About Termites?</h3>
                <p>
                  Protect your property with our professional termite control services in Alandur using industry-leading
                  solutions.
                </p>
              </div>
            </div>
            <div className="mt-6">
              <h3 className="text-xl font-bold text-dark-green mb-2">Green Pest Control Services in Alandur Chennai</h3>
              <p>
                We are pioneers in green pest control using safe and effective herbal products. Ideal for families,
                pets, and sensitive environments.
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.5}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Our Alandur Pest Control Services Cover:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Pest Control Services in Alandur</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>General Pest Control in Alandur Chennai</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Cockroach & Termite Control</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Villa Pest Control</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Cleaning and Disinfection</span>
              </div>
              <div className="flex items-start">
                <span className="text-light-green font-bold mr-2">✅</span>
                <span>Service Providers in Tamil Nadu</span>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="slideUp" delay={0.6}>
          <div className="bg-light-cream rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">Areas We Serve Near Alandur Chennai</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Alandur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">St. Thomas Mount</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Guindy</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Nanganallur</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Saidapet</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Ekkatuthangal</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Tirusulam</div>
              <div className="bg-white p-3 rounded-lg text-center shadow-sm">Velachery</div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.7}>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-dark-green mb-4">
              Contact the No.1 Pest Control Company in Alandur
            </h2>
            <p className="mb-4">✅ Best Price | ✅ Guaranteed Results | ✅ Safe Solutions</p>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex items-center">
                <span className="font-bold mr-2">📞 Call Us Now:</span>
                <a href="tel:+917558108600" className="text-light-green hover:underline">
                  +91 7558108600
                </a>
              </div>
            </div>
            <div>
              <p>
                <strong>📍 Location:</strong> Alandur, Chennai, Tamil Nadu
              </p>
              <p>
                <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
              </p>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fadeIn" delay={0.8}>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-dark-green mb-6 text-center">
              Contact Us for Pest Control in Alandur
            </h2>
            <ContactForm />
          </div>
        </AnimatedSection>
      </div>
    </main>
  )
}
