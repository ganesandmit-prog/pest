import type { Metadata } from "next"
import NemilicheryPestControlClient from "./NemilicheryPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Nemilichery, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nemilichery, Chennai. We offer termite treatment, cockroach control, and safe pest solutions for homes and businesses.",
  keywords:
    "pest control Nemilichery, termite treatment Nemilichery, cockroach control Chennai, pest management Nemilichery, No.1 Quality Pest Control",
}

export default function NemilicheryPestControlPage() {
  return <NemilicheryPestControlClient />
}
