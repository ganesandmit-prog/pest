"use client"
import { Helmet } from "react-helmet"

import { PageHeader } from "@/components/page-header"
import { TestimonialsSection } from "@/components/testimonials-section"
import { BenefitsSection } from "@/components/benefits-section"
import { ProcessSection } from "@/components/process-section"
import { ContactForm } from "@/components/contact-form"
import { FadeIn } from "@/components/framer-animations"

export function NandanamPestControlClient() {
  return (
    <>
      <Helmet>
        <title>Trusted Pest Control in Nandanam, Chennai | No.1 Quality Pest Control</title>
        <meta
          name="description"
          content="Professional pest control services in Nandanam, Chennai. Effective & affordable solutions for cockroach, termite, rodent control & more. Book now!"
        />
        <meta
          name="keywords"
          content="pest control Nandanam, Nandanam pest services, cockroach control Nandanam, termite treatment Nandanam, rodent control Nandanam, pest management Nandanam, affordable pest control Nandanam, Chennai pest control"
        />
        <link rel="canonical" href="https://www.no1qualitypestcontrol.com/service-areas/nandanam" />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "No.1 Quality Pest Control - Nandanam",
              "description": "Professional pest control services in Nandanam, Chennai. We offer effective, quick, and safe pest control solutions for homes, offices, and villas.",
              "url": "https://www.no1qualitypestcontrol.com/service-areas/nandanam",
              "telephone": "+917558108600",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "202 Broadway",
                "addressLocality": "Nandanam",
                "addressRegion": "Chennai",
                "postalCode": "600035",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "13.0279",
                "longitude": "80.2406"
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                  "Sunday"
                ],
                "opens": "07:00",
                "closes": "22:00"
              },
              "sameAs": [
                "https://www.facebook.com/no1qualitypestcontrol",
                "https://www.instagram.com/no1qualitypestcontrol"
              ],
              "priceRange": "₹₹",
              "servesCuisine": "Pest Control Services"
            }
          `}
        </script>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "serviceType": "Pest Control Service",
              "provider": {
                "@type": "ProfessionalService",
                "name": "No.1 Quality Pest Control"
              },
              "areaServed": {
                "@type": "City",
                "name": "Nandanam, Chennai"
              },
              "description": "Professional pest control services in Nandanam, Chennai including cockroach control, termite treatment, rodent control, and more.",
              "offers": {
                "@type": "Offer",
                "price": "999.00",
                "priceCurrency": "INR"
              }
            }
          `}
        </script>
      </Helmet>

      <PageHeader
        title="Trusted Pest Control Services in Nandanam, Chennai"
        description="Effective & Affordable Pest Solutions by No.1 Quality Pest Control"
      />

      <div className="container mx-auto px-4 py-12">
        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Professional Pest Control in Nandanam</h2>
            <p className="text-gray-700 mb-4">
              Looking for reliable pest control in Nandanam? At No.1 Quality Pest Control, we offer expert, quick, and
              safe pest control services tailored to protect your home, office, or villa from unwanted pests. From
              stubborn cockroach control to thorough termite control services, our experienced team in Nandanam Chennai
              uses eco-friendly solutions that guarantee long-lasting results.
            </p>
            <p className="text-gray-700 mb-4">
              Our team of certified technicians specializes in identifying and eliminating pest problems specific to the
              Nandanam area. We ensure top-quality service with government-approved chemicals for your family's safety
              while effectively addressing your pest concerns.
            </p>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Expert Pest Control Services in Nandanam</h2>
            <ul className="list-disc pl-6 mb-4 space-y-2 text-gray-700">
              <li>
                <span className="font-semibold">Cockroach Control Services</span> - Eliminate cockroach infestations
                from your home or office
              </li>
              <li>
                <span className="font-semibold">Termite Control & Prevention</span> - Protect your property from
                destructive termites
              </li>
              <li>
                <span className="font-semibold">Rodent Control Solutions</span> - Comprehensive rat and mice control
              </li>
              <li>
                <span className="font-semibold">Mosquito & Insect Control</span> - Reduce disease-carrying insects
                around your property
              </li>
              <li>
                <span className="font-semibold">Eco-Friendly & Safe Pest Control</span> - Environmentally conscious pest
                management options
              </li>
              <li>
                <span className="font-semibold">Spider & Ant Control</span> - Eliminate crawling insects from your
                premises
              </li>
            </ul>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Areas We Serve Near Nandanam</h2>
            <p className="text-gray-700 mb-4">We proudly serve Nandanam and the surrounding areas including:</p>
            <ul className="list-disc pl-6 mb-4 space-y-1 text-gray-700">
              <li>Nandanam Chennai</li>
              <li>Teynampet</li>
              <li>Adyar</li>
              <li>Alwarpet</li>
              <li>Mylapore</li>
            </ul>
          </div>
        </FadeIn>

        <BenefitsSection
          title="Why Choose No.1 Quality Pest Control in Nandanam?"
          benefits={[
            {
              title: "Over 10+ Years of Experience",
              description: "Benefit from our decade of pest control expertise in Chennai",
            },
            {
              title: "Skilled & Certified Technicians",
              description: "Our team is fully trained in the latest pest control methods",
            },
            {
              title: "Affordable Pricing with Transparent Quotes",
              description: "Competitive rates with no hidden fees",
            },
            {
              title: "Quick Response & Easy Booking",
              description: "Fast service when you need pest control urgently",
            },
            {
              title: "Highly Rated on Sulekha & Google Reviews",
              description: "Join our satisfied customers throughout Chennai",
            },
          ]}
        />

        <ProcessSection
          title="Our Pest Control Process in Nandanam"
          steps={[
            {
              title: "Inspection",
              description: "Thorough assessment of your property to identify pest issues",
            },
            {
              title: "Customized Treatment Plan",
              description: "Developing a targeted solution based on your specific pest problem",
            },
            {
              title: "Professional Application",
              description: "Using government-approved methods and products",
            },
            {
              title: "Preventive Measures",
              description: "Implementing strategies to prevent future infestations",
            },
            {
              title: "Follow-up Service",
              description: "Ensuring complete pest elimination with follow-up visits if needed",
            },
          ]}
        />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">What Our Clients Say</h2>
            <div className="space-y-4">
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Excellent termite control in my villa at Nandanam. Professional and trustworthy service!"
                </p>
                <p className="text-gray-600 font-semibold">— Lakshmi V., Nandanam</p>
              </div>
              <div className="border-l-4 border-blue-500 pl-4 italic">
                <p className="text-gray-700 mb-2">
                  "Fast and effective cockroach control. Highly recommend No.1 Quality Pest Control."
                </p>
                <p className="text-gray-600 font-semibold">— Arun K., Chennai</p>
              </div>
            </div>
          </div>
        </FadeIn>

        <TestimonialsSection />

        <FadeIn>
          <div className="bg-white rounded-lg shadow-md p-6 mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-800">
                  How often should I schedule pest control service in Nandanam?
                </h3>
                <p className="text-gray-700">
                  For most homes and offices in Nandanam, we recommend quarterly pest control treatments to maintain a
                  pest-free environment. However, this can vary based on your specific situation and the types of pests
                  in your area.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Do you offer emergency pest control services in Nandanam?
                </h3>
                <p className="text-gray-700">
                  Yes, we offer same-day emergency pest control services throughout Nandanam and surrounding areas.
                  Contact us immediately for urgent pest issues.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">Are your treatments safe for pets and children?</h3>
                <p className="text-gray-700">
                  Yes, we use government-approved chemicals that are safe for families and pets when applied correctly.
                  We'll provide specific safety instructions for each treatment.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  Do you offer commercial pest control for offices in Nandanam?
                </h3>
                <p className="text-gray-700">
                  Yes, we provide specialized commercial pest control services for offices, retail spaces, and other
                  businesses in Nandanam with flexible scheduling to minimize disruption.
                </p>
              </div>
            </div>
          </div>
        </FadeIn>

        <ContactForm />
      </div>
    </>
  )
}
