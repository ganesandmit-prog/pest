import { NandanamPestControlClient } from "./NandanamPestControlClient"

export const metadata = {
  title: "Trusted Pest Control in Nandanam, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Nandanam, Chennai. Effective & affordable solutions for cockroach, termite, rodent control & more. Book now!",
}

export default function NandanamPage() {
  return <NandanamPestControlClient />
}
