"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { FadeIn, FadeInStagger } from "@/components/framer-animations"
import { ContactForm } from "@/components/contact-form"
import { ProcessSection } from "@/components/process-section"
import { BenefitsSection } from "@/components/benefits-section"
import { CheckCircle } from "lucide-react"

export function MinjurPestControlClient() {
  const [formSubmitted, setFormSubmitted] = useState(false)

  const handleFormSubmit = () => {
    setFormSubmitted(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader title="Pest Control in Minjur" subtitle="Say Goodbye to Pests with Trusted Experts!" />

      <main className="flex-grow">
        <section className="bg-white py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <FadeIn className="max-w-3xl mx-auto text-center mb-8 md:mb-12">
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                Looking for top-rated pest control in Minjur? Look no further! At No.1 Quality Pest Control, we bring
                you the most reliable, eco-friendly, and affordable pest control services in Minjur, Chennai.
              </p>
              <p className="text-lg md:text-xl text-gray-700 mb-6">
                Whether it's a creepy cockroach in the kitchen or termites chewing up your woodwork, our expert team is
                just one call away! 🧹✨
              </p>
            </FadeIn>

            <div className="max-w-3xl mx-auto">
              <FadeIn>
                <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
                  🚫 Say NO to Pests, YES to Peace of Mind!
                </h2>
              </FadeIn>

              <FadeInStagger className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🪳 Cockroach Control Services in Minjur</h3>
                  <p className="text-gray-700">
                    Professional elimination of all cockroach species with guaranteed results.
                  </p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐜 Termite Control Solutions</h3>
                  <p className="text-gray-700">Comprehensive termite treatment to protect your property from damage.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🕷️ Spider & Ant Removal</h3>
                  <p className="text-gray-700">
                    Safe and effective elimination of spiders, ants, and other crawling insects.
                  </p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🐀 Rodent Control & Prevention</h3>
                  <p className="text-gray-700">Complete rodent management solutions to keep your space rodent-free.</p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🦟 Mosquito Treatment</h3>
                  <p className="text-gray-700">
                    Effective mosquito control to protect your family from disease carriers.
                  </p>
                </FadeIn>
                <FadeIn className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-3">🌿 Organic Pest Control with Safe Solutions</h3>
                  <p className="text-gray-700">
                    Eco-friendly options that are safe for your family, pets, and the environment.
                  </p>
                </FadeIn>
              </FadeInStagger>

              <FadeIn>
                <p className="text-center text-lg italic mb-12">
                  Every solution is customized to your home or office — no one-size-fits-all nonsense here!
                </p>
              </FadeIn>

              <FadeIn>
                <div className="bg-blue-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">📍 Why Minjur Residents Trust Us:</h2>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>10+ Years of Pest Control Expertise</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Trained & Background-Checked Professionals</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Safe for Kids & Pets – Only Govt. Approved Chemicals</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Affordable Pricing + Free Quotes</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Emergency Pest Control Available in Minjur & Nearby</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>Listed on Sulekha Chennai, Trusted by 1000+ Clients</span>
                    </li>
                  </ul>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-gray-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">💬 What Minjur Locals Are Saying:</h2>
                  <div className="space-y-6">
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "They helped us with a cockroach outbreak — the team arrived in just 1 hour! Super service!"
                      <footer className="text-right font-medium mt-2">— Harini R., Minjur</footer>
                    </blockquote>
                    <blockquote className="italic border-l-4 border-blue-500 pl-4 py-2">
                      "Best termite treatment I've ever had. They really know their stuff!"
                      <footer className="text-right font-medium mt-2">— Ashok K., Business Owner, Minjur</footer>
                    </blockquote>
                  </div>
                </div>
              </FadeIn>

              <FadeIn>
                <div className="bg-green-50 p-6 rounded-lg shadow-md mb-12">
                  <h2 className="text-2xl font-bold text-center mb-6">📞 Book Your Service Today!</h2>
                  <div className="space-y-2 text-center">
                    <p>
                      <strong>📍 Location:</strong> Minjur, Chennai, Tamil Nadu
                    </p>
                    <p>
                      <strong>📞 Call Now:</strong> +91 75581 08600
                    </p>
                    <p>
                      <strong>📧 Email:</strong> no1qualitypestcontrol@gmail.com
                    </p>
                    <p>
                      <strong>🌐 Website:</strong> www.no1qualitypestcontrol.com
                    </p>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        <ProcessSection />
        <BenefitsSection />

        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <FadeIn>
              <h2 className="text-3xl font-bold text-center mb-12">Contact Us for Pest Control in Minjur</h2>
            </FadeIn>
            <div className="max-w-xl mx-auto">
              <ContactForm onSubmitSuccess={handleFormSubmit} />
              {formSubmitted && (
                <div className="mt-6 p-4 bg-green-100 text-green-700 rounded-md text-center">
                  Thank you for contacting us! We'll get back to you shortly about our pest control services in Minjur.
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
