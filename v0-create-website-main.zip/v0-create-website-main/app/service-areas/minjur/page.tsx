import type { Metadata } from "next"
import { MinjurPestControlClient } from "./MinjurPestControlClient"

export const metadata: Metadata = {
  title: "Pest Control Services in Minjur, Chennai | No.1 Quality Pest Control",
  description:
    "Professional pest control services in Minjur, Chennai. Safe, affordable solutions for cockroaches, termites, rodents & more. Call +91 75581 08600 for free quotes!",
  keywords:
    "pest control Minjur, Minjur pest services, cockroach control Minjur, termite treatment Minjur, rodent control Minjur, pest control services Chennai, affordable pest control Minjur",
}

export default function MinjurPestControlPage() {
  return <MinjurPestControlClient />
}
