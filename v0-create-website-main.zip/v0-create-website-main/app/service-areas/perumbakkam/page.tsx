import type { Metadata } from "next"
import PageHeader from "@/components/page-header"
import PerumbakkamPestControlClient from "./PerumbakkamPestControlClient"

export const metadata: Metadata = {
  title: "Best Pest Control in Perumbakkam Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control in Perumbakkam? No.1 Quality Pest Control offers reliable, safe, and affordable pest control services in Perumbakkam Chennai, ensuring your home or office stays 100% pest-free.",
}

export default function PerumbakkamPestControl() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <PageHeader
        title="Best Pest Control in Perumbakkam Chennai"
        subtitle="Professional & Affordable Pest Control Services in Perumbakkam"
      />
      <PerumbakkamPestControlClient />
    </main>
  )
}
