import type { Metadata } from "next"
import PestControlServicesInChennaiClient from "./PestControlServicesInChennaiClient"

export const metadata: Metadata = {
  title: "Professional Pest Control Services in Chennai | No.1 Quality Pest Control",
  description:
    "No.1 Quality Pest Control offers comprehensive pest management solutions in Chennai. Our services include cockroach control, termite treatment, bed bug elimination, rodent control, and more. 100% safe and eco-friendly treatments with 45+ years of experience.",
  keywords:
    "pest control services, pest control services Chennai, professional pest control, pest management Chennai, cockroach control services, termite treatment Chennai, bed bug control, rodent control services, mosquito control Chennai, No.1 Quality Pest Control services",
  alternates: {
    canonical: "https://www.no1qualitypestcontrol.com/pest-control-services-in-chennai",
  },
}

export default function PestControlServicesInChennaiPage() {
  return <PestControlServicesInChennaiClient />
}
