"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Check, Phone } from "lucide-react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"
import CTA from "@/components/cta"

export default function PestControlServicesInChennaiClient() {
  // Add schema markup for better SEO
  useEffect(() => {
    const script = document.createElement("script")
    script.type = "application/ld+json"
    script.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "PestControlService",
      name: "No.1 Quality Pest Control Services",
      url: "https://www.no1qualitypestcontrol.com/pest-control-services-in-chennai",
      logo: "https://www.no1qualitypestcontrol.com/images/logo.png",
      description:
        "Comprehensive pest control services in Chennai including cockroach, termite, bed bug, and rodent control.",
      address: {
        "@type": "PostalAddress",
        streetAddress: "123 Main Street",
        addressLocality: "Chennai",
        addressRegion: "Tamil Nadu",
        postalCode: "600001",
        addressCountry: "IN",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: "13.0827",
        longitude: "80.2707",
      },
      telephone: "+91-9876543210",
      openingHoursSpecification: {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        opens: "08:00",
        closes: "20:00",
      },
      sameAs: [
        "https://www.facebook.com/no1qualitypestcontrol",
        "https://www.instagram.com/no1qualitypestcontrol",
        "https://twitter.com/no1pestcontrol",
      ],
      priceRange: "₹₹",
      areaServed: "Chennai",
      serviceType: ["Cockroach Control", "Termite Control", "Bed Bug Treatment", "Rodent Control", "Mosquito Control"],
      offers: {
        "@type": "Offer",
        description: "Professional pest control services",
        price: "999",
        priceCurrency: "INR",
      },
    })
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  return (
    <>
      <PageHeader
        title="Comprehensive Pest Control Services in Chennai"
        description="No.1 Quality Pest Control offers a wide range of pest management solutions tailored to your specific needs. Our services are safe, effective, and affordable."
        bgImage="/images/pest-services-header.jpg"
      />
      <main className="min-h-screen">
        {/* <PageHeader title="Pest Control Services in Chennai" subtitle="Safe, Herbal & Affordable Solutions" /> */}

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl md:text-4xl font-bold text-dark-green mb-6">
                  Trusted Pest Control Services in Chennai – 100% Safe, Herbal & Affordable
                </h1>

                <p className="text-lg mb-6">
                  Welcome to No.1 Quality Pest Control, the most reliable and effective pest control service in Chennai.
                  Whether you're facing cockroaches, termites, bed bugs, mosquitoes, or rodents – we offer guaranteed
                  pest solutions that are safe, odourless, and eco-friendly.
                </p>

                <p className="text-lg mb-8">
                  We specialize in both residential and commercial pest control services in Chennai, offering custom
                  treatment plans to suit your home, office, warehouse, or villa.
                </p>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h2 className="text-2xl font-bold text-dark-green mb-4">
                    ✅ Why Choose Our Pest Control Services in Chennai?
                  </h2>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">🏆</span>
                      <span>Government-Approved & ISO-Certified Pest Experts</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">🌿</span>
                      <span>100% Herbal Pest Control Options Available</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">👷‍♂️</span>
                      <span>Trained & Verified Technicians</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">💯</span>
                      <span>Odourless, Hassle-Free & Long-Lasting Treatment</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">💸</span>
                      <span>Transparent Pricing with FREE Site Inspection</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">📍</span>
                      <span>Coverage across all of Chennai & Tamil Nadu</span>
                    </li>
                  </ul>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🐜 Our Top Pest Control Services in Chennai Include:
                </h2>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🦟</span> Mosquito Control Chennai
                    </h3>
                    <p>Effective mosquito fogging and breeding site elimination.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Targets adult mosquitoes and larvae</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Prevents dengue, malaria, and other diseases</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Safe for children and pets</span>
                      </li>
                    </ul>
                    <Link
                      href="/services/mosquito-control"
                      className="text-light-green font-medium mt-3 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🐜</span> Termite Control Services in Chennai
                    </h3>
                    <p>Advanced termite treatments with 5-year warranty protection.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Chemical barrier and soil treatment</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Wood and furniture protection</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Pre and post-construction treatments</span>
                      </li>
                    </ul>
                    <Link
                      href="/services/termite-control"
                      className="text-light-green font-medium mt-3 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🛏️</span> Bed Bugs Treatment in Chennai
                    </h3>
                    <p>Complete bed bug elimination with specialized treatments.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Heat treatment and chemical applications</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Mattress and furniture treatment</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Preventive measures and follow-up visits</span>
                      </li>
                    </ul>
                    <Link
                      href="/services/bed-bug-control"
                      className="text-light-green font-medium mt-3 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🐀</span> Rodent/Rat Control Chennai
                    </h3>
                    <p>Complete rat and mice elimination with preventive measures.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Trapping and baiting systems</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Entry point sealing</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Sanitation recommendations</span>
                      </li>
                    </ul>
                    <Link
                      href="/services/rodent-control"
                      className="text-light-green font-medium mt-3 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🪳</span> Cockroach Control Services Chennai
                    </h3>
                    <p>Professional cockroach elimination with long-lasting protection.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Gel baiting and spray treatments</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Kitchen and bathroom focus</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Preventive measures and monitoring</span>
                      </li>
                    </ul>
                    <Link
                      href="/services/cockroach-control"
                      className="text-light-green font-medium mt-3 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🏢</span> Commercial Pest Solutions
                    </h3>
                    <p>Customized pest management for businesses and commercial spaces.</p>
                    <ul className="mt-3 space-y-1">
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>HACCP and FSSAI compliant treatments</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Discreet service during business hours</span>
                      </li>
                      <li className="flex items-start text-sm">
                        <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                        <span>Regular maintenance programs</span>
                      </li>
                    </ul>
                    <Link href="/commercial" className="text-light-green font-medium mt-3 inline-block hover:underline">
                      View Details →
                    </Link>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h2 className="text-xl font-bold text-dark-green mb-4">📈 SEO Keywords Covered:</h2>
                  <p className="text-gray-700 mb-2">
                    pest control, pest control services, pest control chennai, control services, services chennai,
                    general pest control, cockroach control, chennai india, pest control company, pests, solutions,
                    control service, herbal pest control
                  </p>
                  <p className="text-sm text-gray-600 italic">
                    This content is designed to rank your page in top search results when users look for "Pest Control
                    Services in Chennai" or related terms.
                  </p>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  📞 Contact Us Today for a FREE Pest Inspection
                </h2>

                <div className="bg-white shadow-md rounded-lg p-6 mb-8">
                  <h3 className="text-xl font-bold text-dark-green mb-4">No.1 Quality Pest Control</h3>
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <Phone className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <div>
                        <p className="font-semibold">Call Now:</p>
                        <p>+91 75581 08600</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-light-green mr-3 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      <div>
                        <p className="font-semibold">Website:</p>
                        <p>https://www.no1qualitypestcontrol.com</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-light-green mr-3 mt-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <div>
                        <p className="font-semibold">Serving all areas of Chennai:</p>
                        <p>
                          Including Anna Nagar, Nungambakkam, Tambaram, Porur, Velachery, Mylapore, Adyar, T. Nagar, and
                          more.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold text-dark-green mb-4">💥 Special Offers</h3>
                  <p className="mb-4">Get up to 20% OFF on your first booking!</p>
                  <p className="font-medium">
                    Quick response, verified professionals, and long-term protection – that's our promise!
                  </p>
                  <div className="flex justify-center mt-6">
                    <Link
                      href="/contact-us"
                      className="bg-light-green hover:bg-dark-green text-white font-bold py-3 px-6 rounded-lg transition-colors"
                    >
                      Book Free Inspection
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <CTA />

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center text-dark-green mb-8">
              Contact Us For Professional Pest Control
            </h2>
            <div className="max-w-3xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}
