"use client"

import Image from "next/image"
import Link from "next/link"
import PageHeader from "@/components/page-header"
import { AnimatedSection, StaggeredContainer } from "@/components/framer-animations"
import { motion } from "framer-motion"
import { Calendar, ArrowRight, Check } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function BlogPage() {
  const blogPosts = [
    {
      title: "How to Get Rid of Ants in Your Chennai Home",
      date: "2024-05-08",
      image: "https://images.unsplash.com/photo-1566407528571-63834aae2dd1",
      slug: "get-rid-of-ants-chennai-home",
      excerpt:
        "Ant infestations can quickly become a nightmare! Learn how to identify different types of ants in Chennai and the best eco-friendly solutions to keep them away for good.",
    },
    {
      title: "Why Professional Spider Control is Essential in Chennai",
      date: "2024-04-30",
      image: "https://images.unsplash.com/photo-1557800636-894a64c1696f",
      slug: "professional-spider-control-chennai",
      excerpt:
        "Chennai's climate makes it a breeding ground for dangerous spiders like the Black Widow and Brown Recluse. Find out why professional spider control is necessary for a safe home.",
    },
    {
      title: "Bed Bug Infestation? Here's What You Should Do",
      date: "2024-04-15",
      image: "https://images.unsplash.com/photo-1634731452032-ddd4161226f9",
      slug: "bed-bug-infestation-what-to-do",
      excerpt:
        "Bed bugs are one of the most stubborn pests to eliminate. Learn about the signs of an infestation and effective treatment options to restore your peace of mind.",
    },
    {
      title: "How to Keep Rats and Mice Out of Your Home",
      date: "2024-04-01",
      image: "https://images.unsplash.com/photo-1548767797-d8c844163c4c",
      slug: "keep-rats-mice-out-of-home",
      excerpt:
        "Rodents not only damage property but also carry harmful diseases. Discover the best rodent prevention methods and how professional pest control can help.",
    },
    {
      title: "The Ultimate Guide to Mosquito Prevention in Chennai",
      date: "2024-03-15",
      image: "https://images.unsplash.com/photo-1584551882459-38dd83e1fef0",
      slug: "ultimate-guide-mosquito-prevention-chennai",
      excerpt:
        "Mosquitoes are a year-round problem in Chennai, spreading diseases like dengue and malaria. Learn the best ways to protect your family with expert mosquito control.",
    },
  ]

  return (
    <>
      <PageHeader
        title="RAM'S Pest Control Blog – Expert Tips & Solutions"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
        subtitle="Stay Informed & Pest-Free with Chennai's Leading Pest Control Experts"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              Welcome to the RAM'S Pest Control Blog, where we share expert tips, industry insights, and proven
              solutions to help keep your home and business pest-free. Whether you're dealing with termites,
              cockroaches, bed bugs, rodents, or mosquitoes, our articles provide the best prevention and control
              strategies tailored for Chennai's climate.
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fadeIn" delay={0.2}>
            <h2 className="text-2xl font-bold mb-8">📝 Latest Blog Posts</h2>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post, index) => (
                <motion.div
                  key={post.slug}
                  className="bg-white rounded-lg shadow-md overflow-hidden"
                  whileHover={{ y: -10 }}
                >
                  <Link href={`/blog/${post.slug}`}>
                    <div className="relative h-48 overflow-hidden">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        fill
                        className="object-cover transition-transform duration-300 hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                      <div className="flex items-center text-gray-500 text-sm mb-2">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>📅 Published on: {post.date}</span>
                      </div>
                      <h3 className="font-bold text-xl mb-2 hover:text-light-green transition-colors">{post.title}</h3>
                      <p className="text-gray-600 mb-4">{post.excerpt}</p>
                      <div className="flex items-center text-light-green font-medium">
                        <span>🔗 Read More</span>
                        <ArrowRight className="h-4 w-4 ml-1" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </StaggeredContainer>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <AnimatedSection animation="fadeIn">
              <h2 className="text-3xl font-bold mb-6">📩 Subscribe to Our Newsletter</h2>
              <p className="mb-8">
                Stay updated with seasonal pest control tips, exclusive offers, and latest trends in pest management.
              </p>
            </AnimatedSection>
            <AnimatedSection animation="slideUp" delay={0.2}>
              <form className="flex flex-col sm:flex-row gap-4 justify-center">
                <input
                  type="email"
                  placeholder="📧 Enter Your Email Address"
                  className="px-4 py-2 border border-gray-300 rounded-md flex-grow max-w-md"
                />
                <motion.button
                  type="submit"
                  className="btn-dark"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  🔘 Subscribe Now
                </motion.button>
              </form>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Why Trust Us Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Trust RAM'S Pest Control Chennai?</h2>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                title: "Over 10+ Years of Experience",
                description: "Trusted by thousands across Chennai",
              },
              {
                title: "Eco-Friendly & Safe Solutions",
                description: "Family and pet-friendly treatments",
              },
              {
                title: "Certified & Trained Experts",
                description: "Professional pest control specialists",
              },
              {
                title: "Affordable Pricing",
                description: "High-quality service at competitive rates",
              },
              {
                title: "Guaranteed Results",
                description: "Effective solutions for long-term pest control",
              },
            ].map((item, index) => (
              <AnimatedSection key={index} animation="slideUp" delay={index * 0.1}>
                <motion.div className="bg-white p-6 rounded-lg shadow-md h-full" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection animation="fadeIn" delay={0.5}>
            <div className="text-center mt-8">
              <div className="inline-flex items-center">
                <span className="font-medium">📞 Need Professional Pest Control? Call Us Today at +91 94444 20367</span>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>
    </>
  )
}
