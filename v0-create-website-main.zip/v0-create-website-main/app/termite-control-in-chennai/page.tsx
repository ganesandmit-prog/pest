import type { Metadata } from "next"
import TermiteControlInChennaiClient from "./TermiteControlInChennaiClient"

export const metadata: Metadata = {
  title: "Expert Termite Control Services in Chennai | No.1 Quality Pest Control",
  description:
    "Protect your property from termite damage with No.1 Quality Pest Control's specialized termite control services in Chennai. We offer pre-construction anti-termite treatment, post-construction termite control, and termite piping with long-term warranty. 45+ years of experience in termite elimination.",
  keywords:
    "termite control, termite control Chennai, termite treatment, anti-termite treatment, termite pest control, wood borer treatment, termite inspection, termite piping, pre-construction termite treatment, post-construction termite control, No.1 Quality termite services",
  alternates: {
    canonical: "https://www.no1qualitypestcontrol.com/termite-control-in-chennai",
  },
}

export default function TermiteControlInChennaiPage() {
  return <TermiteControlInChennaiClient />
}
