"use client"

import { useEffect } from "react"
import PageHeader from "@/components/page-header"
import CTA from "@/components/cta"
import Link from "next/link"
import { Check, Phone, Shield } from "lucide-react"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export default function TermiteControlInChennaiClient() {
  // Add schema markup for better SEO
  useEffect(() => {
    const script = document.createElement("script")
    script.type = "application/ld+json"
    script.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      serviceType: "Termite Control",
      provider: {
        "@type": "PestControlService",
        name: "No.1 Quality Pest Control",
        url: "https://www.no1qualitypestcontrol.com",
        logo: "https://www.no1qualitypestcontrol.com/images/logo.png",
        telephone: "+91-9876543210",
        address: {
          "@type": "PostalAddress",
          streetAddress: "123 Main Street",
          addressLocality: "Chennai",
          addressRegion: "Tamil Nadu",
          postalCode: "600001",
          addressCountry: "IN",
        },
      },
      areaServed: "Chennai",
      description:
        "Professional termite control services in Chennai including pre-construction anti-termite treatment, post-construction termite control, and termite piping with long-term warranty.",
      offers: {
        "@type": "Offer",
        description: "Termite control services",
        price: "2999",
        priceCurrency: "INR",
      },
      url: "https://www.no1qualitypestcontrol.com/termite-control-in-chennai",
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Termite Control Services",
        itemListElement: [
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Pre-Construction Anti-Termite Treatment",
            },
          },
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Post-Construction Termite Control",
            },
          },
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Termite Piping",
            },
          },
        ],
      },
    })
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  return (
    <>
      <PageHeader
        title="Expert Termite Control Services in Chennai"
        description="Protect your property from termite damage with No.1 Quality Pest Control's specialized termite control services. We offer pre-construction anti-termite treatment, post-construction termite control, and termite piping with long-term warranty."
        bgImage="/images/termite-control-header.jpg"
      />

      <main className="min-h-screen">
        {/* <PageHeader title="Termite Control in Chennai" subtitle="Get Rid of Termites Today!" /> */}

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl md:text-4xl font-bold text-dark-green mb-6">
                  Termite Control in Chennai – Get Rid of Termites Today!
                </h1>

                <p className="text-lg mb-6">
                  Are termites silently damaging your property? Don't wait until it's too late. Our Termite Control
                  Services in Chennai are trusted by 10,000+ homeowners and businesses across Tamil Nadu. Whether you
                  need pre-construction anti-termite treatment or post-construction termite removal, we provide fast,
                  affordable, and eco-friendly solutions with long-term protection.
                </p>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h2 className="text-2xl font-bold text-dark-green mb-4">
                    📈 Why Choose Our Termite Control Services in Chennai?
                  </h2>
                  <p className="mb-4">
                    We use advanced Anti-Termite Treatments including drilling, chemical barrier creation, and herbal
                    solutions to completely eliminate termites. Here's why we're the top choice:
                  </p>

                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <span>ISO Certified Pest Control Company</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <span>Odourless & Safe Chemicals</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <span>5-Year Warranty for Termite Treatment</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <span>Trained, Background-Verified Technicians</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                      <span>24/7 Emergency Response Across Chennai</span>
                    </li>
                  </ul>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-6">
                  💰 Termite Control Chennai – Price List (Starting at ₹2900)
                </h2>

                <div className="overflow-x-auto mb-8">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-dark-green text-white">
                        <th className="border border-gray-300 px-4 py-3 text-left">Home Type</th>
                        <th className="border border-gray-300 px-4 py-3 text-center">Termite Control Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">1 BHK</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹2900</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">2 BHK</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4400</td>
                      </tr>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">3 BHK</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4900</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">4 BHK</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹5900</td>
                      </tr>
                      <tr className="bg-white hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3 font-medium">5 BHK</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹5999</td>
                      </tr>
                      <tr className="bg-gray-50 hover:bg-gray-100">
                        <td className="border border-gray-300 px-4 py-3 font-medium">Piping Method</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">₹4000 to ₹7099</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <Shield className="h-6 w-6 text-light-green mr-3" />
                      <h3 className="text-xl font-bold text-dark-green">Pre-Construction Treatment</h3>
                    </div>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Chemical soil treatment before construction</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Foundation and basement protection</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Preventive barrier against termite invasion</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Long-term structural protection</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <Shield className="h-6 w-6 text-light-green mr-3" />
                      <h3 className="text-xl font-bold text-dark-green">Post-Construction Treatment</h3>
                    </div>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Targeted treatment for active infestations</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Drilling and injection method</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Wood and furniture treatment</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-light-green mr-2 mt-0.5" />
                        <span>Comprehensive termite colony elimination</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h2 className="text-xl font-bold text-dark-green mb-4">
                    SEO Keywords for Termite Control in Chennai
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-1">One Word:</h3>
                      <p className="text-gray-700">control, termite, chennai, treatment, service, services, termites</p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-1">Two Words:</h3>
                      <p className="text-gray-700">
                        termite control, pest control, control services, termite treatment, services chennai
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-1">Three Words:</h3>
                      <p className="text-gray-700">
                        termite control services, termite control chennai, pest control services, control service
                      </p>
                    </div>
                  </div>

                  <p className="mt-4 text-sm text-gray-600 italic">
                    We also include regional SEO like Tamil Nadu termite service and Chennai pest control to rank in
                    local searches.
                  </p>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  📞 Contact the Best Pest Control Experts in Chennai
                </h2>

                <div className="bg-white shadow-md rounded-lg p-6 mb-8">
                  <div className="flex items-center mb-4">
                    <Phone className="h-6 w-6 text-light-green mr-3" />
                    <h3 className="text-xl font-bold">Call Us</h3>
                  </div>
                  <p className="text-lg font-bold text-dark-green">+91 75581 08600</p>

                  <div className="flex items-center mt-6 mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-light-green mr-3"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                      />
                    </svg>
                    <h3 className="text-xl font-bold">Website</h3>
                  </div>
                  <p className="text-gray-700">https://www.no1qualitypestcontrol.com</p>

                  <div className="flex items-center mt-6 mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-light-green mr-3"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                    <h3 className="text-xl font-bold">Service Areas</h3>
                  </div>
                  <p className="text-gray-700">
                    Serving all pin codes: Anna Nagar, T. Nagar, Velachery, Tambaram, Porur, Mylapore, and 50+ more.
                  </p>
                </div>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold text-dark-green mb-4">Book Your Termite Inspection Now</h3>
                  <p className="mb-4">
                    Say goodbye to hidden damage. Protect your walls, woodwork, and furniture with Chennai's most
                    trusted Termite Control Specialists.
                  </p>
                  <div className="flex justify-center">
                    <Link
                      href="/contact-us"
                      className="bg-light-green hover:bg-dark-green text-white font-bold py-3 px-6 rounded-lg transition-colors"
                    >
                      Book Free Inspection
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <CTA />

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center text-dark-green mb-8">
              Contact Us For Professional Termite Control
            </h2>
            <div className="max-w-3xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}
