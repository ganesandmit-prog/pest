import PageHeader from "@/components/page-header"
import ContactForm from "@/components/contact-form"

export default function ContactPage() {
  return (
    <>
      <PageHeader
        title="Contact No.1 Quality Pest Control Chennai Today!"
        backgroundImage="https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
      />

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <p className="mb-6 text-center">
              A member of our team will be in touch shortly to confirm your contact details or address questions about
              our pest control services Chennai. We offer termite control, cockroaches control, and commercial pest
              control at affordable price.
            </p>
            <ContactForm />

            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-4 text-center">Our Pest Control Service Chennai Location</h2>
              <div style={{ position: "relative" }}>
                <div style={{ position: "relative", paddingBottom: "75%", height: 0, overflow: "hidden" }}>
                  <iframe
                    style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: 0 }}
                    loading="lazy"
                    allowFullScreen
                    src="https://maps.google.com/maps?q=Brodway+chennai&output=embed"
                  ></iframe>
                </div>
                <a
                  href="https://mapembeds.com/"
                  rel="noreferrer noopener"
                  target="_blank"
                  style={{
                    position: "absolute",
                    width: "1px",
                    height: "1px",
                    padding: 0,
                    margin: "-1px",
                    overflow: "hidden",
                    clip: "rect(0,0,0,0)",
                    whiteSpace: "nowrap",
                    border: 0,
                  }}
                >
                  embed google maps
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
