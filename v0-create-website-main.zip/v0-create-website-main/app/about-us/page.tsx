"use client"

import Image from "next/image"
import PageHeader from "@/components/page-header"
import { AnimatedSection, StaggeredContainer } from "@/components/framer-animations"
import { motion } from "framer-motion"
import Link from "next/link"
import { Check, MapPin, Star, Phone, MessageSquare, Mail } from "lucide-react"
import TestimonialCard from "@/components/testimonial-card"
import ContactForm from "@/components/contact-form"

export default function AboutUsPage() {
  return (
    <>
      <PageHeader
        title="About No.1 Quality Pest Control Chennai"
        backgroundImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Af1vLFMiN7WrLTq6JzeGod8qTxyNAg.png"
      />

      {/* Hero Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideLeft">
              <div>
                <h2 className="text-3xl font-bold mb-6 flex items-center">
                  <span className="text-4xl mr-2">🚀</span> Trusted Pest Control Experts in Chennai for Over 45 Years!
                </h2>
                <p className="mb-6">
                  At No.1 Quality Pest Control Chennai, we are committed to keeping your home and business pest-free
                  with safe, effective, and eco-friendly pest control solutions. With 45+ years of experience in pest
                  control services Chennai, our team has successfully helped thousands of customers across Chennai
                  eliminate termites, cockroaches, rodents, bed bugs, mosquitoes, and more with our professional pest
                  control services at affordable price.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <motion.a
                    href="tel:+917558108600"
                    className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Phone size={20} />
                    <span>Call for Pest Control Services Chennai: +91 7558108600</span>
                  </motion.a>
                  <motion.a
                    href="https://wa.me/917558108600"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-green-500 text-white px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <MessageSquare size={20} />
                    <span>WhatsApp for Pest Control Chennai</span>
                  </motion.a>
                </div>
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideRight">
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png"
                  alt="No.1 Quality Pest Control Professional in Chennai"
                  fill
                  className="object-cover"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose No.1 Quality Pest Control Chennai?</h2>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "45+ Years of Pest Control Expertise in Chennai",
                  description: "We know Chennai's unique pest challenges.",
                },
                {
                  title: "Safe Pest Control for Families & Pets",
                  description: "Eco-friendly & non-toxic pest treatments at affordable price.",
                },
                {
                  title: "Fast & Effective Pest Control Services Chennai",
                  description: "Quick response, thorough inspection & targeted pest treatment.",
                },
                {
                  title: "Locally Owned & Operated Pest Control",
                  description: "Serving homes & businesses across Chennai.",
                },
                {
                  title: "Affordable Pest Control Price",
                  description: "Quality pest control service Chennai at competitive prices.",
                },
                {
                  title: "100% Customer Satisfaction",
                  description: "We ensure complete pest eradication with our control services Chennai.",
                },
              ].map((item, index) => (
                <motion.div key={index} className="bg-white p-6 rounded-lg shadow-md" whileHover={{ y: -5 }}>
                  <div className="flex items-start">
                    <div className="bg-light-green rounded-full p-2 mr-4 mt-1">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </StaggeredContainer>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="flex items-center justify-center mb-8">
              <MapPin className="h-8 w-8 text-dark-green mr-2" />
              <h2 className="text-3xl font-bold">We provide professional pest control services in:</h2>
            </div>
            <div className="bg-gray-100 p-6 rounded-lg max-w-4xl mx-auto">
              <div className="flex flex-wrap justify-center gap-x-6 gap-y-3">
                {[
                  "Adyar",
                  "Anna Nagar",
                  "T. Nagar",
                  "Velachery",
                  "Mylapore",
                  "Porur",
                  "Tambaram",
                  "OMR",
                  "Kodambakkam",
                  "& More!",
                ].map((area, index) => (
                  <motion.span
                    key={index}
                    className="inline-block"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    {index > 0 && <span className="text-gray-400 mr-2">|</span>}
                    <span className="font-medium">{area} Pest Control Services Chennai</span>
                  </motion.span>
                ))}
              </div>
            </div>
          </AnimatedSection>

          <div className="text-center mt-8">
            <AnimatedSection animation="fadeIn" delay={0.3}>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.a
                  href="tel:+917558108600"
                  className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Phone size={20} />
                  <span>Call Now for Pest Control Services Chennai: +91 7558108600</span>
                </motion.a>
                <Link href="/contact-us">
                  <motion.button
                    className="flex items-center justify-center gap-2 bg-light-green text-white px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Mail size={20} />
                    <span>Get a Free Pest Control Quote</span>
                  </motion.button>
                </Link>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-16 bg-dark-green text-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Our Mission – Safe & Reliable Pest Control for Chennai</h2>
              <p className="text-lg max-w-4xl mx-auto">
                Our mission is to provide the best pest control services in Chennai with safe, eco-friendly, and
                effective pest control solutions. Whether it's your home, office, hotel, restaurant, or commercial
                space, we have the right pest treatment plan for you at affordable price!
              </p>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <AnimatedSection animation="slideLeft">
              <div className="bg-white/10 p-6 rounded-lg">
                <ul className="space-y-4">
                  {[
                    {
                      emoji: "🔹",
                      text: "Residential Pest Control – Safe & effective pest control solutions for homes in Chennai.",
                    },
                    {
                      emoji: "🔹",
                      text: "Commercial Pest Control – Protecting businesses from pests in Chennai.",
                    },
                    {
                      emoji: "🔹",
                      text: "Termite Control – Prevent structural damage from termites in Chennai properties.",
                    },
                    {
                      emoji: "🔹",
                      text: "Bed Bug Control – Get rid of bed bugs & enjoy a peaceful sleep with our pest control services Chennai.",
                    },
                  ].map((item, index) => (
                    <li key={index} className="flex">
                      <span className="text-2xl mr-2">{item.emoji}</span>
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideRight">
              <div className="bg-white/10 p-6 rounded-lg">
                <ul className="space-y-4">
                  {[
                    {
                      emoji: "🔹",
                      text: "Cockroaches Control – Stop cockroach infestations before they spread in Chennai.",
                    },
                    {
                      emoji: "🔹",
                      text: "Rodent Control – Prevent rats & mice from damaging your property in Chennai.",
                    },
                    {
                      emoji: "🔹",
                      text: "Mosquito Control – Reduce the risk of dengue, malaria & other diseases in Chennai.",
                    },
                    {
                      emoji: "🔹",
                      text: "Pipe Pest Control – Specialized pest treatments for plumbing systems in Chennai.",
                    },
                  ].map((item, index) => (
                    <li key={index} className="flex">
                      <span className="text-2xl mr-2">{item.emoji}</span>
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </AnimatedSection>
          </div>

          <AnimatedSection animation="fadeIn" delay={0.4}>
            <div className="text-center mt-12">
              <div className="inline-flex items-center bg-white/20 px-6 py-3 rounded-lg">
                <span className="text-2xl mr-2">💡</span>
                <span className="font-medium">Need immediate pest control services Chennai?</span>
                <a href="tel:+917558108600" className="ml-2 font-bold hover:underline">
                  📞 Call Now: +91 7558108600
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <h2 className="text-3xl font-bold text-center mb-12">
              What Our Happy Customers Say About Our Pest Control Services Chennai
            </h2>
          </AnimatedSection>

          <StaggeredContainer staggerDelay={0.1} animation="slideUp">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              <TestimonialCard
                quote="No.1 Quality Pest Control saved my home from termites! The best pest control service Chennai!"
                author="Karthik S., Anna Nagar"
                rating={5}
              />
              <TestimonialCard
                quote="Very professional & effective cockroaches control treatment. Highly recommended pest control services Chennai!"
                author="Priya R., Velachery"
                rating={5}
              />
              <TestimonialCard
                quote="Safe and affordable pest control service in Chennai. The team is highly knowledgeable about termite control."
                author="Vinoth K., T. Nagar"
                rating={5}
              />
            </div>
          </StaggeredContainer>

          <AnimatedSection animation="fadeIn" delay={0.4}>
            <div className="text-center mt-8">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/reviews">
                  <motion.button
                    className="flex items-center justify-center gap-2 bg-gray-200 text-gray-800 px-6 py-3 rounded-md"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Star className="h-5 w-5" />
                    <span>Check More Pest Control Reviews</span>
                  </motion.button>
                </Link>
                <motion.a
                  href="tel:+917558108600"
                  className="flex items-center justify-center gap-2 bg-dark-green text-white px-6 py-3 rounded-md"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Phone size={20} />
                  <span>Call Now for Pest Control Services Chennai: +91 7558108600</span>
                </motion.a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Contact No.1 Quality Pest Control Chennai Today!</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                <motion.a
                  href="tel:+917558108600"
                  className="flex flex-col items-center p-4 bg-white rounded-lg shadow-md"
                  whileHover={{ y: -5 }}
                >
                  <Phone size={24} className="text-dark-green mb-2" />
                  <span className="font-medium">Call for Pest Control Services Chennai:</span>
                  <span className="font-bold">+91 7558108600</span>
                </motion.a>
                <motion.a
                  href="https://wa.me/917558108600"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex flex-col items-center p-4 bg-white rounded-lg shadow-md"
                  whileHover={{ y: -5 }}
                >
                  <MessageSquare size={24} className="text-dark-green mb-2" />
                  <span className="font-medium">WhatsApp for Pest Control Chennai:</span>
                  <span className="font-bold">Click Here to Chat</span>
                </motion.a>
                <motion.div
                  className="flex flex-col items-center p-4 bg-white rounded-lg shadow-md"
                  whileHover={{ y: -5 }}
                >
                  <MapPin size={24} className="text-dark-green mb-2" />
                  <span className="font-medium">Pest Control Service Chennai Location:</span>
                  <span className="font-bold">Chennai, Tamil Nadu</span>
                </motion.div>
                <motion.div
                  className="flex flex-col items-center p-4 bg-white rounded-lg shadow-md"
                  whileHover={{ y: -5 }}
                >
                  <Mail size={24} className="text-dark-green mb-2" />
                  <span className="font-medium">Email for Pest Control Services Chennai:</span>
                  <span className="font-bold">no1qualitypestcontrol@gmail.com</span>
                </motion.div>
              </div>
            </div>
          </AnimatedSection>

          <div className="max-w-4xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  )
}
