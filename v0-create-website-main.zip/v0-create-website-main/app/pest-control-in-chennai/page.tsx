import type { Metadata } from "next"
import PestControlInChennaiClient from "./PestControlInChennaiClient"

export const metadata: Metadata = {
  title: "Best Pest Control Services in Chennai | No.1 Quality Pest Control",
  description:
    "Looking for professional pest control services in Chennai? No.1 Quality Pest Control offers 100% safe, trusted & affordable pest control solutions with 45+ years of experience. Get a free inspection today!",
  keywords:
    "pest control, pest control Chennai, pest control services in Chennai, best pest control in Chennai, affordable pest control Chennai, professional pest control, No.1 Quality Pest Control, cockroach control, termite control, bed bug treatment, rodent control, mosquito control, Chennai pest services",
  alternates: {
    canonical: "https://www.no1qualitypestcontrol.com/pest-control-in-chennai",
  },
}

export default function PestControlInChennaiPage() {
  return <PestControlInChennaiClient />
}
