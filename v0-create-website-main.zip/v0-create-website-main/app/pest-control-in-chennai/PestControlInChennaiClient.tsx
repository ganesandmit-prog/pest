"use client"

import { useEffect } from "react"
import PageHeader from "@/components/page-header"
import CTA from "@/components/cta"
import Link from "next/link"
import { Phone } from "lucide-react"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"

export default function PestControlInChennaiClient() {
  // Add schema markup for better SEO
  useEffect(() => {
    const script = document.createElement("script")
    script.type = "application/ld+json"
    script.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "PestControlService",
      name: "No.1 Quality Pest Control",
      url: "https://www.no1qualitypestcontrol.com/pest-control-in-chennai",
      logo: "https://www.no1qualitypestcontrol.com/images/logo.png",
      description: "Professional pest control services in Chennai with 45+ years of experience.",
      address: {
        "@type": "PostalAddress",
        streetAddress: "123 Main Street",
        addressLocality: "Chennai",
        addressRegion: "Tamil Nadu",
        postalCode: "600001",
        addressCountry: "IN",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: "13.0827",
        longitude: "80.2707",
      },
      telephone: "+91-9876543210",
      openingHoursSpecification: {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        opens: "08:00",
        closes: "20:00",
      },
      sameAs: [
        "https://www.facebook.com/no1qualitypestcontrol",
        "https://www.instagram.com/no1qualitypestcontrol",
        "https://twitter.com/no1pestcontrol",
      ],
      priceRange: "₹₹",
      servesCuisine: "Pest Control",
      areaServed: "Chennai",
      serviceType: ["Cockroach Control", "Termite Control", "Bed Bug Treatment", "Rodent Control", "Mosquito Control"],
    })
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  return (
    <>
      <PageHeader
        title="Professional Pest Control Services in Chennai"
        description="No.1 Quality Pest Control offers comprehensive pest management solutions with 45+ years of experience. Our services are safe, effective, and affordable."
        bgImage="/images/pest-control-header.jpg"
      />

      <main className="min-h-screen">
        {/* <PageHeader title="Pest Control in Chennai" subtitle="Professional & Affordable Pest Control Services" /> */}

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <AnimatedSection animation="fadeIn">
              <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl md:text-4xl font-bold text-dark-green mb-6">
                  #1 Pest Control Services in Chennai | 100% Safe, Trusted & Affordable
                </h1>

                <p className="text-lg mb-6">
                  Looking for pest control services in Chennai? You've found the best! At No.1 Quality Pest Control, we
                  deliver top-rated, eco-friendly, and government-approved pest control solutions across
                  Chennai—residential, commercial, warehouse, and villas.
                </p>

                <p className="text-lg mb-8">
                  From cockroach control to termite treatment, we handle everything—ensuring your space is clean, safe,
                  and pest-free.
                </p>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h2 className="text-2xl font-bold text-dark-green mb-4">
                    ✅ Why We're Chennai's Top Pest Control Company
                  </h2>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">🏆</span>
                      <span>ISO-Certified & Government-Approved Services</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">👨‍🔧</span>
                      <span>Highly Trained & Verified Technicians</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">🌱</span>
                      <span>100% Herbal & Odourless Treatments Available</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">🏠</span>
                      <span>Specialized for Homes, Villas, Apartments, Offices, Restaurants</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">💸</span>
                      <span>Affordable Prices & Transparent Quotes</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-dark-green font-bold mr-2">📍</span>
                      <span>Service Areas: All over Chennai, Tamil Nadu, India</span>
                    </li>
                  </ul>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  🚫 Our Most Popular Pest Control Services in Chennai
                </h2>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🐜</span> Cockroach Control in Chennai
                    </h3>
                    <p>Professional cockroach elimination with long-lasting protection.</p>
                    <Link
                      href="/services/cockroach-control"
                      className="text-light-green font-medium mt-2 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🐀</span> Rodent Control in Chennai
                    </h3>
                    <p>Complete rat and mice elimination with preventive measures.</p>
                    <Link
                      href="/services/rodent-control"
                      className="text-light-green font-medium mt-2 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🐛</span> Termite Control Services in Chennai
                    </h3>
                    <p>Advanced termite treatments with 5-year warranty protection.</p>
                    <Link
                      href="/services/termite-control"
                      className="text-light-green font-medium mt-2 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🦟</span> Mosquito Control Chennai
                    </h3>
                    <p>Effective mosquito fogging and breeding site elimination.</p>
                    <Link
                      href="/services/mosquito-control"
                      className="text-light-green font-medium mt-2 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🛌</span> Bed Bugs Treatment Chennai
                    </h3>
                    <p>Complete bed bug elimination with specialized treatments.</p>
                    <Link
                      href="/services/bed-bug-control"
                      className="text-light-green font-medium mt-2 inline-block hover:underline"
                    >
                      View Details →
                    </Link>
                  </div>

                  <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                    <h3 className="text-xl font-bold text-dark-green mb-2 flex items-center">
                      <span className="mr-2">🌿</span> Eco-Friendly & Herbal Pest Control Chennai
                    </h3>
                    <p>Safe, odorless treatments suitable for homes with children and pets.</p>
                    <Link href="/services" className="text-light-green font-medium mt-2 inline-block hover:underline">
                      View Details →
                    </Link>
                  </div>
                </div>

                <p className="text-lg mb-8">
                  We are known for pest control in Chennai, general pest control, and cockroach removal, with highly
                  competitive service prices.
                </p>

                <div className="bg-gray-50 p-6 rounded-lg mb-8">
                  <h2 className="text-2xl font-bold text-dark-green mb-4">
                    🌟 Featured on Sulekha Chennai | 5000+ Happy Customers | Google Rated 4.9★
                  </h2>
                  <p className="mb-4">
                    No.1 Quality Pest Control is listed on top platforms like Sulekha Chennai, JustDial, and Google My
                    Business. Our verified reviews speak volumes about our quality pest control services in Chennai.
                  </p>

                  <div className="flex flex-wrap gap-4 justify-center">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center text-yellow-500 mb-2">★★★★★</div>
                      <p className="text-sm italic">
                        "Excellent service! They completely eliminated our cockroach problem."
                      </p>
                      <p className="text-sm font-semibold mt-2">- Ramesh K., Anna Nagar</p>
                    </div>

                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center text-yellow-500 mb-2">★★★★★</div>
                      <p className="text-sm italic">
                        "Very professional team. Termite problem solved with their treatment."
                      </p>
                      <p className="text-sm font-semibold mt-2">- Priya S., T. Nagar</p>
                    </div>

                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center text-yellow-500 mb-2">★★★★★</div>
                      <p className="text-sm italic">"Affordable and effective pest control. Highly recommended!"</p>
                      <p className="text-sm font-semibold mt-2">- Vijay M., Velachery</p>
                    </div>
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  📞 Contact the Best Pest Control Experts in Chennai
                </h2>

                <div className="flex flex-col md:flex-row gap-6 mb-8">
                  <div className="flex-1 bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <Phone className="h-6 w-6 text-light-green mr-2" />
                      <h3 className="text-xl font-bold">Call Us</h3>
                    </div>
                    <p className="text-lg font-bold text-dark-green">+91 75581 08600</p>
                    <p className="text-sm text-gray-600 mt-2">Available 24/7 for emergency pest control</p>
                  </div>

                  <div className="flex-1 bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      <h3 className="text-xl font-bold">Email Us</h3>
                    </div>
                    <p className="text-lg font-bold text-dark-green">no1qualitypestcontrol@gmail.com</p>
                    <p className="text-sm text-gray-600 mt-2">We'll respond within 2 hours</p>
                  </div>

                  <div className="flex-1 bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-light-green mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <h3 className="text-xl font-bold">Service Areas</h3>
                    </div>
                    <p className="text-gray-700">
                      Serving all pin codes: Anna Nagar, T. Nagar, Velachery, Tambaram, Porur, Mylapore, and 50+ more.
                    </p>
                  </div>
                </div>

                <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                  <h3 className="text-xl font-bold text-dark-green mb-4">
                    🚀 Get Instant Quote – Best Price Guarantee!
                  </h3>
                  <p className="mb-4">
                    Whether you're facing cockroaches, termites, bed bugs, rats, or any pests, we are your trusted
                    partner for 24x7 emergency pest control services in Chennai. Book your service now to get a FREE
                    inspection + discount up to 20%.
                  </p>
                  <div className="flex justify-center">
                    <Link
                      href="/contact-us"
                      className="bg-light-green hover:bg-dark-green text-white font-bold py-3 px-6 rounded-lg transition-colors"
                    >
                      Get Free Inspection
                    </Link>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <CTA />

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center text-dark-green mb-8">
              Contact Us For Professional Pest Control
            </h2>
            <div className="max-w-3xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
    </>
  )
}
