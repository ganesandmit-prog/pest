import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import FloatingActionButton from "@/components/floating-action-button"
import ScrollToTop from "@/components/scroll-to-top"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "No.1 Pest Control Chennai | Termite & Commercial Control",
  description:
    "Best pest control services in Chennai for termite, cockroach & commercial control. Top-rated service with 45+ years experience. Affordable rates.",
  keywords:
    "pest control chennai, termite control, cockroach control, commercial pest control, pest control services, pest control company chennai",
  openGraph: {
    title: "No.1 Pest Control Chennai | Termite & Commercial Control",
    description:
      "Best pest control services in Chennai for termite, cockroach & commercial control. Top-rated service with 45+ years experience.",
    url: "https://no1qualitypestcontrol.com",
    siteName: "No.1 Quality Pest Control Chennai",
    locale: "en_IN",
    type: "website",
    images: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png",
        width: 1200,
        height: 630,
        alt: "No.1 Pest Control Chennai Services",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "No.1 Pest Control Chennai | Termite & Commercial Control",
    description:
      "Best pest control services in Chennai for termite, cockroach & commercial control. Top-rated service with 45+ years experience.",
    images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="canonical" href="https://no1qualitypestcontrol.com" />
        <meta name="robots" content="index, follow" />
        <meta name="author" content="No.1 Quality Pest Control Chennai" />
        <meta name="geo.region" content="IN-TN" />
        <meta name="geo.placename" content="Chennai" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "No.1 Quality Pest Control",
              description: "Best pest control services in Chennai for termite, cockroach and commercial pest control",
              url: "https://www.no1qualitypestcontrol.com",
              image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2tmoMACKok9uKHvXYaaYkbEfZ4RXZi.png",
              telephone: "+917558108600",
              address: {
                "@type": "PostalAddress",
                streetAddress: "202 Broadway Parrys",
                addressLocality: "Chennai",
                postalCode: "600001",
                addressRegion: "Tamil Nadu",
                addressCountry: "IN",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: 13.0827,
                longitude: 80.2707,
              },
              openingHoursSpecification: {
                "@type": "OpeningHoursSpecification",
                dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                opens: "08:00",
                closes: "20:00",
              },
              priceRange: "$$",
              serviceType: ["Pest Control Services", "Termite Control", "Cockroach Control", "Commercial Pest Control"],
              areaServed: "Chennai",
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ScrollToTop />
        <Navbar />
        <main>{children}</main>
        <Footer />
        <FloatingActionButton />
      </body>
    </html>
  )
}
