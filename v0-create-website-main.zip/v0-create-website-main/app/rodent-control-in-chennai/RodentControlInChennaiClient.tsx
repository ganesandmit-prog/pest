"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Check, Phone } from "lucide-react"
import PageHeader from "@/components/page-header"
import { AnimatedSection } from "@/components/framer-animations"
import ContactForm from "@/components/contact-form"
import CTA from "@/components/cta"

export default function RodentControlInChennaiClient() {
  // Add schema markup for better SEO
  useEffect(() => {
    const script = document.createElement("script")
    script.type = "application/ld+json"
    script.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      serviceType: "Rodent Control",
      provider: {
        "@type": "PestControlService",
        name: "No.1 Quality Pest Control",
        url: "https://www.no1qualitypestcontrol.com",
        logo: "https://www.no1qualitypestcontrol.com/images/logo.png",
        telephone: "+91-9876543210",
        address: {
          "@type": "PostalAddress",
          streetAddress: "123 Main Street",
          addressLocality: "Chennai",
          addressRegion: "Tamil Nadu",
          postalCode: "600001",
          addressCountry: "IN",
        },
      },
      areaServed: "Chennai",
      description:
        "Professional rodent control services in Chennai including inspection, exclusion, trapping, and prevention strategies.",
      offers: {
        "@type": "Offer",
        description: "Rodent control services",
        price: "1999",
        priceCurrency: "INR",
      },
      url: "https://www.no1qualitypestcontrol.com/rodent-control-in-chennai",
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Rodent Control Services",
        itemListElement: [
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Rodent Inspection",
            },
          },
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Rodent Exclusion",
            },
          },
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Rodent Trapping",
            },
          },
          {
            "@type": "Offer",
            itemOffered: {
              "@type": "Service",
              name: "Rodent Prevention",
            },
          },
        ],
      },
    })
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  return (
    <main className="min-h-screen">
      <PageHeader
        title="Effective Rodent Control Services in Chennai"
        description="Get rid of rats and mice with No.1 Quality Pest Control's professional rodent control services. Our comprehensive rodent elimination program includes inspection, exclusion, trapping, and prevention strategies."
        bgImage="/images/rodent-control-header.jpg"
      />

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection animation="fadeIn">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold text-dark-green mb-6">
                Rodent Control in Chennai – Trusted Rat Removal Services
              </h1>

              <p className="text-lg mb-6">
                Looking for effective rodent control in Chennai? You've come to the right place. At No.1 Quality Pest
                Control, we specialize in professional rat control services, helping homeowners and businesses eliminate
                rodents quickly and safely. Whether it's a minor issue or a full-blown infestation, we provide top-notch
                pest control services in Chennai at affordable prices.
              </p>

              <div className="bg-light-green/10 p-6 rounded-lg mb-8">
                <h2 className="text-2xl font-bold text-dark-green mb-4">
                  ✅ Why Choose No.1 Quality for Rodent Control?
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>100% Safe & Odourless Treatments</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>Eco-Friendly Rodent Control Solutions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>Quick Response & Same-Day Service</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>Expert Technicians with Years of Experience</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>Affordable AMC (Annual Maintenance Contracts)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-light-green mr-3 mt-0.5" />
                    <span>Reliable rodent control services in Chennai</span>
                  </li>
                </ul>
              </div>

              <h2 className="text-2xl font-bold text-dark-green mb-4">🐀 What We Offer in Our Rat Control Service:</h2>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold text-dark-green mb-3">Rodent Bait Stations & Snap Traps</h3>
                  <p className="text-gray-700 mb-3">
                    We use professional-grade bait stations and snap traps strategically placed to eliminate rodents
                    effectively without endangering children or pets.
                  </p>
                  <ul className="space-y-1">
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Tamper-resistant bait stations</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Humane and effective snap traps</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Strategic placement for maximum effectiveness</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold text-dark-green mb-3">Entry Point Identification & Sealing</h3>
                  <p className="text-gray-700 mb-3">
                    Our experts thoroughly inspect your property to identify and seal all potential entry points,
                    preventing future rodent invasions.
                  </p>
                  <ul className="space-y-1">
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Comprehensive property inspection</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Sealing of cracks, gaps, and holes</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Installation of door sweeps and mesh screens</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold text-dark-green mb-3">Control for House Rats, Bandicoots & Mice</h3>
                  <p className="text-gray-700 mb-3">
                    We target all types of rodents common in Chennai, including house rats, bandicoots, and mice, with
                    specialized treatment methods for each species.
                  </p>
                  <ul className="space-y-1">
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Species-specific treatment approaches</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Targeted solutions for different infestation levels</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Complete elimination guarantee</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold text-dark-green mb-3">Post-Treatment Sanitization</h3>
                  <p className="text-gray-700 mb-3">
                    After rodent removal, we thoroughly sanitize affected areas to eliminate disease-causing pathogens
                    and prevent health risks.
                  </p>
                  <ul className="space-y-1">
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Disinfection of contaminated areas</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Removal of droppings and nesting materials</span>
                    </li>
                    <li className="flex items-start text-sm">
                      <Check className="h-4 w-4 text-light-green mr-2 mt-0.5" />
                      <span>Deodorization to eliminate odors</span>
                    </li>
                  </ul>
                </div>
              </div>

              <p className="text-lg mb-8">
                We deliver rodent control services in Chennai that are designed to remove existing rodents and prevent
                future infestations.
              </p>

              <div className="bg-gray-50 p-6 rounded-lg mb-8">
                <h2 className="text-xl font-bold text-dark-green mb-4">
                  🔍 Keywords We Target for Top SEO Performance
                </h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-1">One Word:</h3>
                    <p className="text-gray-700">control, chennai, services, rodent, service, rodents</p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-1">Two Words:</h3>
                    <p className="text-gray-700">
                      pest control, rodent control, control services, services chennai, rat control, control service
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-1">Three Words:</h3>
                    <p className="text-gray-700">pest control services, rodent control services, rat control chennai</p>
                  </div>
                </div>

                <p className="mt-4 text-sm text-gray-600 italic">
                  These keywords are strategically placed across the page to boost your search engine visibility.
                </p>
              </div>

              <h2 className="text-2xl font-bold text-dark-green mb-4">🏠 Who We Serve</h2>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-white shadow-sm rounded-lg p-4 text-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 mx-auto text-light-green mb-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                    />
                  </svg>
                  <p className="font-medium">Residential Homes</p>
                  <p className="text-sm text-gray-600">(1BHK, 2BHK, 3BHK, Villas)</p>
                </div>

                <div className="bg-white shadow-sm rounded-lg p-4 text-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 mx-auto text-light-green mb-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                    />
                  </svg>
                  <p className="font-medium">Commercial Spaces</p>
                  <p className="text-sm text-gray-600">(Shops, Offices, Godowns)</p>
                </div>

                <div className="bg-white shadow-sm rounded-lg p-4 text-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 mx-auto text-light-green mb-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 15.546c-.523 0-1.046.151-1.5.454a2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.701 2.701 0 00-1.5-.454M9 6v2m3-2v2m3-2v2M9 3h.01M12 3h.01M15 3h.01M21 21v-7a2 2 0 00-2-2H5a2 2 0 00-2 2v7h18zm-3-9v-2a2 2 0 00-2-2H8a2 2 0 00-2 2v2h12z"
                    />
                  </svg>
                  <p className="font-medium">Restaurants</p>
                  <p className="text-sm text-gray-600">(Cafes, Hotels, Food Outlets)</p>
                </div>

                <div className="bg-white shadow-sm rounded-lg p-4 text-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 mx-auto text-light-green mb-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                    />
                  </svg>
                  <p className="font-medium">Institutions</p>
                  <p className="text-sm text-gray-600">(Schools, Hospitals, More)</p>
                </div>
              </div>

              <div className="bg-white shadow-md rounded-lg p-6 mb-8">
                <h2 className="text-xl font-bold text-dark-green mb-4">📈 SEO-Focused Rodent Control Content</h2>
                <p className="mb-4">If you're searching for:</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-light-green mr-2" />
                    <span>"Rodent Control Chennai"</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-light-green mr-2" />
                    <span>"Rat Control in Chennai"</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-light-green mr-2" />
                    <span>"Pest Control Services Chennai"</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="h-5 w-5 text-light-green mr-2" />
                    <span>"Best Rodent Control Company Near Me"</span>
                  </li>
                </ul>
                <p className="font-medium">You'll find No.1 Quality Pest Control ranking at the top!</p>
              </div>

              <h2 className="text-2xl font-bold text-dark-green mb-6">💰 Rodent Control Service Rates in Chennai</h2>

              <div className="overflow-x-auto mb-8">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-dark-green text-white">
                      <th className="border border-gray-300 px-4 py-3 text-left">Home Type</th>
                      <th className="border border-gray-300 px-4 py-3 text-center">Price (INR)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-white hover:bg-gray-50">
                      <td className="border border-gray-300 px-4 py-3 font-medium">1 BHK</td>
                      <td className="border border-gray-300 px-4 py-3 text-center">₹800</td>
                    </tr>
                    <tr className="bg-gray-50 hover:bg-gray-100">
                      <td className="border border-gray-300 px-4 py-3 font-medium">2 BHK</td>
                      <td className="border border-gray-300 px-4 py-3 text-center">₹900</td>
                    </tr>
                    <tr className="bg-white hover:bg-gray-50">
                      <td className="border border-gray-300 px-4 py-3 font-medium">3 BHK</td>
                      <td className="border border-gray-300 px-4 py-3 text-center">₹1000</td>
                    </tr>
                    <tr className="bg-gray-50 hover:bg-gray-100">
                      <td className="border border-gray-300 px-4 py-3 font-medium">4 BHK</td>
                      <td className="border border-gray-300 px-4 py-3 text-center">₹1100</td>
                    </tr>
                    <tr className="bg-white hover:bg-gray-50">
                      <td className="border border-gray-300 px-4 py-3 font-medium">5 BHK</td>
                      <td className="border border-gray-300 px-4 py-3 text-center">₹1199</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <p className="text-center font-bold text-lg mb-8">Best price, best service — guaranteed!</p>

              <h2 className="text-2xl font-bold text-dark-green mb-4">📞 Contact Us</h2>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-white shadow-md rounded-lg p-6">
                  <div className="flex items-start mb-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-light-green mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                    <div>
                      <p className="font-semibold">Location:</p>
                      <p>Chennai</p>
                    </div>
                  </div>

                  <div className="flex items-start mb-3">
                    <Phone className="h-6 w-6 text-light-green mr-3 mt-0.5" />
                    <div>
                      <p className="font-semibold">Call:</p>
                      <p>+91 75581 08600</p>
                    </div>
                  </div>

                  <div className="flex items-start mb-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-light-green mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    <div>
                      <p className="font-semibold">Email:</p>
                      <p>no1qualitypestcontrol@gmail.com</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-light-green mr-3 mt-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                      />
                    </svg>
                    <div>
                      <p className="font-semibold">Website:</p>
                      <p>www.no1qualitypestcontrol.com</p>
                    </div>
                  </div>
                </div>

                <div className="bg-light-green/10 p-6 rounded-lg">
                  <h3 className="text-xl font-bold text-dark-green mb-4">🕒 Book Your Rodent Control Service Today!</h3>
                  <p className="mb-4">
                    Rodents spread diseases, damage property, and contaminate food. Don't wait — call the best rodent
                    control experts in Chennai now for fast, safe, and effective service.
                  </p>
                  <div className="flex justify-center">
                    <Link
                      href="/contact-us"
                      className="bg-light-green hover:bg-dark-green text-white font-bold py-3 px-6 rounded-lg transition-colors"
                    >
                      Get Free Inspection
                    </Link>
                  </div>
                  <p className="text-center mt-4 font-medium">100% Satisfaction Guaranteed!</p>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      <CTA />

      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-dark-green mb-8">
            Contact Us For Professional Rodent Control
          </h2>
          <div className="max-w-3xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </main>
  )
}
