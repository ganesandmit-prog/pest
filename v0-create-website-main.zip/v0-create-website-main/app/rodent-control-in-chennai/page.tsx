import type { Metadata } from "next"
import RodentControlInChennaiClient from "./RodentControlInChennaiClient"

export const metadata: Metadata = {
  title: "Effective Rodent Control Services in Chennai | No.1 Quality Pest Control",
  description:
    "Get rid of rats and mice with No.1 Quality Pest Control's professional rodent control services in Chennai. Our comprehensive rodent elimination program includes inspection, exclusion, trapping, and prevention strategies. Safe for homes and businesses with 45+ years of experience.",
  keywords:
    "rodent control, rat control Chennai, mice control, rodent extermination, rat removal services, rodent pest control, rat infestation treatment, mice elimination, rodent prevention, rat exclusion services, No.1 Quality rodent control, professional rat control Chennai",
  alternates: {
    canonical: "https://www.no1qualitypestcontrol.com/rodent-control-in-chennai",
  },
}

export default function RodentControlInChennaiPage() {
  return <RodentControlInChennaiClient />
}
